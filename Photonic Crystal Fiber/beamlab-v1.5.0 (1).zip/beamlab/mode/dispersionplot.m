%DISPERSIONPLOT - Recreate output of a previous dispersionsolver simulation.
%
%   This BeamLab function recreates the same output as a previous
%   dispersionsolver calculation using the parameters given in
%   dispersionData. The parameter dispersionData has to be a structure
%   returned by dispersionsolver.
%
%   DISPERSIONPLOT(dispersionData)
%   DISPERSIONPLOT(___,options)
%   DISPERSIONPLOT(___,'param1',value1,'param2',value2,...)
%   figureHandles = DISPERSIONPLOT(___)
%
%   Reference list of all options with their default values:
%
%   options.DispersionGraphType = dispersionData.BeamProblem.Options.DispersionGraphType;
%   options.FigureBackgroundColor = dispersionData.BeamProblem.Options.FigureBackgroundColor;
%   options.FigureLabels = dispersionData.BeamProblem.Options.FigureLabels;
%   options.FontName = dispersionData.BeamProblem.Options.FontName;
%   options.FontSizeAxes = dispersionData.BeamProblem.Options.FontSizeAxes;
%   options.FontSizeLabels = dispersionData.BeamProblem.Options.FontSizeLabels;
%   options.FontSizeTitle = dispersionData.BeamProblem.Options.FontSizeTitle;
%
%   <a href="matlab:beamlabdoc dispersionplot">Reference page for dispersionplot</a>
%
%   See also DISPERSIONSOLVER, BEAMSET.

%   Copyright 2017-2018 CodeSeeder
