%MODESOLVER - Calculate the modes of a 2D refractive index distribution.
%
%   This BeamLab function calculates the modes and corresponding effective
%   refractive indices of a user-defined 2D refractive index distribution.
%
%   MODESOLVER(beamProblem)
%   [outputData,effectiveIndex,figureHandles] = MODESOLVER(___)
%
%   <a href="matlab:beamlabdoc modesolver">Reference page for modesolver</a>
%
%   See also BEAMSET, MODEPLOT, DISPERSIONSOLVER.

%   Copyright 2017-2018 CodeSeeder

