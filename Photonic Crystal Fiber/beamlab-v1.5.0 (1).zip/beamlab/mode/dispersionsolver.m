%DISPERSIONSOLVER - Calculate the dispersion characteristics of a 2D refractive index distribution.
%
%   This BeamLab function calculates the dispersion characteristics of a
%   user-defined 2D refractive index distribution.
%
%   DISPERSIONSOLVER(beamProblem)
%   [outputData,figureHandles] = DISPERSIONSOLVER(___)
%
%   <a href="matlab:beamlabdoc dispersionsolver">Reference page for dispersionsolver</a>
%
%   See also BEAMSET, MODESOLVER.

%   Copyright 2017-2018 CodeSeeder
