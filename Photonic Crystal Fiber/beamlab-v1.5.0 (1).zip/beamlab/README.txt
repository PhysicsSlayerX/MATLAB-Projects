
██████╗ ███████╗ █████╗ ███╗   ███╗██╗      █████╗ ██████╗ 
██╔══██╗██╔════╝██╔══██╗████╗ ████║██║     ██╔══██╗██╔══██╗
██████╔╝█████╗  ███████║██╔████╔██║██║     ███████║██████╔╝
██╔══██╗██╔══╝  ██╔══██║██║╚██╔╝██║██║     ██╔══██║██╔══██╗
██████╔╝███████╗██║  ██║██║ ╚═╝ ██║███████╗██║  ██║██████╔╝
╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝ 


BeamLab is a set of simulation tools for beam propagation through optical devices and waveguides in your familiar MATLAB® environment. Examples encompass a large variety of propagation scenarios for both bulk and waveguide optics including lenses, gratings, apertures, couplers, splitters, multiplexers, and modulators.


System Requirements
===================

BeamLab requires MATLAB® version 7.11 (R2010b) or later and has the same system requirements as MATLAB® (see www.mathworks.com/support/sysreq.html). For parallel computing using multicore processors and computer clusters, BeamLab supports the MATLAB® Parallel Computing Toolbox™ and Optimization Toolbox™. Usage of these external toolboxes is optional and not required for the use of the core functions of the BeamLab. Please note that some of our parallel computing and optimization examples require these external toolboxes to be installed.


Installation Instructions
=========================

(1) Download BeamLab from www.codeseeder.com/download/.

(2) Unzip the BeamLab archive to a directory of your choice, e.g., to "C:\beamlab\".

(3) Start MATLAB®, change the current folder to the BeamLab directory, and execute the installation script "install" by entering the following commands in the MATLAB® command-line interface:

cd C:\beamlab\
install

(4) The script "install" automatically checks if a valid license file "license_bpm.dat" for BeamLab's Beam Propagation Toolbox and/or "license_mode.dat" for BeamLab's Mode Solver Toolbox exists in the installation directory. If no such file is found, you are asked if you want to request a license. Please answer this question with "Y" - this will automatically open a new web browser window. Fill out all required fields and check if your email address is correct, since we will send you the license file(s) to this address. The "PC Identifier" is a unique string identifying your computer. This field is automatically filled out for your convenience. Once you have entered your data, submit the license request by clicking on the "REQUEST LICENSE" button.

If for some reason the browser window does not open automatically, please manually go to the website www.codeseeder.com/request-license-key/ and copy the "PC Identifier" string displayed in your MATLAB® command-line interface to the respective field on the website.

(5) You will receive your license file(s) within a couple of days by email. Copy the license file(s) to the "licenses" directory located in your BeamLab installation directory, e.g., to "C:\beamlab\licenses\license_bpm.dat" and/or "C:\beamlab\licenses\license_mode.dat".

(6) Congratulations, you are good to go! In order to get started check out our demonstration scripts in the "demos" subdirectory (e.g., "C:\beamlab\demos\"). You can open the BeamLab documentation by entering the command "beamlabdoc" in the MATLAB® command-line interface. If you want to directly open the documentation of a certain function, use the command "beamlabdoc <functionname>", e.g., "beamlabdoc beamset".


Release Notes
=============

v1.5.0 (August 26, 2018)
------------------------

New features:

* Add new function imageinput, which creates an input field distribution from an image file. It supports scaling, shifting, rotating, flipping (left-right or up-down), and inverting via the optional parameters Width, Shift, Rotation, FlipLeftRight, FlipUpDown, and Inverse, respectively.
* Add new parameter OutputParameters that allows one to define which parameters are saved in the output structure at the end of the simulation.
* Add new parameter PerformanceMode that allows one to turn off refractive index scan and field monitor functions all together and thus optimize the performance of a beam propagation simulation. This new parameter has been added to all relevant demo scripts.
* Add possibility to calculate a virtual bend in multicore, plc, customwaveguide2d, and customwaveguide3d waveguides.
* Add new parameter SlicesXYSectionEnd to all waveguide functions to plot and store the field distribution appearing immediately behind a waveguide section.
* Add new parameter TransmittanceSlicesXY to thin element functions to plot and store the transmittance of a thin element.
* Add new parameter ApertureInverse to thinaperture that allows one to quickly generate and use also the inverse of the aperture function.
* Add new parameter ModeIndex that allows one to define an effective index value in whose vicinity the modes should be calculated.
* Add new parameter Polarization to modeinput to allow the usage of a Stokes (polarization) vector also in conjunction with (semi-vectorial) modes as input field.
* Add SymmetryX and SymmetryY as optional parameters to modeinput.
* Add possibility to set the optional parameters SlicesXYGraphType, SlicesXYScale, SlicesXYRange, and SlicesXYView individually for inputplot.
* Add information on the effective mode area to the output data structure of modesolver.
* Add new optional parameters MonitorScale and MonitorRange for adjusting scale and range of monitor plots independently from x-y slice plots.
* Add the possibility to use different scale and range values for each subplot in x-y, x-z, and y-z slice plots and monitor plots.
* Add function beamlabdemos, which directly opens the examples pages of the BeamLab documentation in the Help browser.

New demos:

* Add demo imaging_single_lens, which simulates the imaging of an object through a single lens with magnification M.
* Add demo imaging_single_lens_aberration, which simulates the imaging of an object through a single lens with aberrations defined via a Zernike phase screen.
* Add demo imaging_4f_system, which simulates the imaging of an object through a 4f optical system with different filter types.
* Add demo imaging_phase_contrast, which simulates the imaging of a pure phase object through a 4f optical system using the principle of phase contrast microscopy.

Enhancements:

* Improve calculation speed for fundamental modes in modesolver.
* Improve automatic assignment of ModeNumber and ModeSelect parameters.
* Improve bpmsolver, indexplot, and stacked slices plots for propagation structures containing fasthomogeneous sections.
* Improve beamoverlap to allow for input fields with different number of field components.
* Improve parsing of input parameters in beamset, inputplot, and indexplot.
* Improve 2D graphs of 2D simulations.
* Improve install function.
* Improve output structures.
* Improve titles and axis labels.
* Improve error and warning messages.
* Improve command-line output of modesolver calculations.
* Improve demo scripts.
* Improve documentation.

Parameter changes:

* Rename parameter PowerTraceType to PowerTrace.
* Rename parameter ShiftType to ShiftTransition in singlecore, multicore, plc, and rib waveguide functions.
* Rename parameter ShiftFunction to ShiftTransitionFunction in singlecore, multicore, plc, and rib waveguide functions.
* Remove parameter Monitor from thin element functions. For plotting (and storing) the transmittance of a thin element, one can now use the new parameter TransmittanceSlicesXY instead.

Bug fixes:

* Fix bug when using a function handle for indexFunction2D or indexFunction3D in customwaveguide2d or customwaveguide3d, respectively.
* Fix bug with respect to Anisotropy parameter.
* Fix bug with respect to FontSizeAxes and FontName not working correctly for 3D index contour plots.
* Various minor bug fixes.

v1.4.0 (May 1, 2018)
--------------------

New features:

* Add the possibility to define the input polarization via a polarization vector (i.e., normalized Stokes vector) that allows one to work with arbitrary input polarizations. In this respect, the Polarization parameter has been moved from beamset to the input field functions. Both semi-vectorial and full-vectorial BPM calculations can be performed with arbitrary input polarizations. For semi-vectorial mode calculations the desired polarization can be set via the new parameter ModePolarization.
* Add information on the E-field's polarization state at the x-y slices and output plane to the output data structure of a BPM calculation.
* Add the possibility to calculate a virtual bend in singlecore and rib waveguides.
* Add possibility to define the anisotropy of waveguides by means of a 3- or 5-element vector representing the relative components [xx,yy,zz] or [xx,yy,zz,xy,yx] of the index tensor.
* Add new optional parameters AnisotropyCore, AnisotropySubstrate, and AnisotropyCladding to rib, replacing the single parameter Anisotropy. This allows one to define the refractive index anisotropy for core, substrate, and cladding individually.
* Add two new options 'DvsLambda' and 'DvsV' to the parameter DispersionGraphType for plotting the dispersion parameter D as a function of wavelength and normalized frequency, respectively.
* Add scale options 'lincustom' and 'logcustom' to parameters SlicesXYScale, SlicesXZScale, SlicesYZScale, and PowerTraceScale. The new scale options allow one to define a linear or logarithmic scale, respectively, normalized to a custom value. In case of SlicesXYScale, SlicesXZScale, and SlicesYZScale, this custom value is defined by the new optional parameter SlicesCustomNorm and in case of PowerTraceScale, the custom value is defined by the newly added parameter PowerCustomNorm.
* Add possibility to address simultaneously an arbitrary ensemble of cores with ModeCore and thus calculate the (super)modes defined by these cores.
* Add new optional parameter ModeSelect that allows one to select specific modes (either in form of a scalar or a vector) out of a larger mode ensemble.
* Add the possibility to define modesolver relevant parameters such as ModeCore, ModeNumber, ModePolarization, ModeSections, ModeSelect, and ModeSortingOrder directly as input parameters of modeinput. In addition, modeinput now also allows one to define an input distribution that consists of a linear combination of modes with different mode amplitudes by assigning a vector containing the relevant mode numbers to ModeSelect and a vector containing the appropriate mode amplitudes to ModeAmplitude.
* Add new optional parameter Phase to all input field functions for specifying the input field's phase in degrees.
* Add possibility to display phase and index distributions in x-z and y-z slices.
* Add possibility to display multiple x-z and y-z slice plots of different types.
* Add new optional parameter QuiverLength that allows one to adjust the length of the quiver arrows.
* Add new optional parameter ShowSectionTitles for displaying section titles inside the figure during monitor. The position inside the figure can be specified by the new parameter SectionTitlePosition.
* Add option to beamlabdoc for searching the documentation for pages with words matching a specified expression.
* Add demo fiber_loop, which simulates the propagation of the fundamental mode of a fiber through a fiber loop.
* Add demo fiber_bend_modes, which calculates the first three eigenmodes of a fiber with a bending radius of 10 cm.
* Add demo fiber_bend_loss, which calculates the bending loss of the first three eigenmodes of a fiber with a bending radius of 10 cm as a function of the wavelength.
* Add demo quarterwave_plate, which simulates the propagation of a Gaussian beam with circular polarization through a quarter-wave plate.
* Add demo noninterfering_beams, which simulates the propagation of two orthogonally polarized Gaussian beams that cross each other in free space.
* Add demo fiber_taper, which simulates the propagation of the fundamental mode of a fiber whose size is changed by means of a fiber taper.

Enhancements:

* Eliminate the need for the user-defined parameters FieldSymmetryX and FieldSymmetryY. Field symmetries are now set automatically according to the input field and index symmetries SymmetryX and SymmetryY.
* Extend full-vectorial bpmsolver to work also with anisotropic homogeneous and singlecore waveguides that are rotated by some arbitrary angle.
* Improve power area definition. The SmoothingLevel parameter is now also used for smoothing the rim of the power area.
* Improve display of quiver arrows in x-y slice plots.
* Improve performance of license manager.
* Improve demo scripts.
* Improve documentation.

Bug fixes:

* Fix bug in dispersionsolver when using cores with index trenches.
* Fix bug in indexplot when using fasthomogeneous sections.
* Fix bug when modeling a tapered rib waveguide.
* Fix license manager bug when using macOS or Linux.
* Various minor bug fixes.

v1.3.0 (February 25, 2018)
--------------------------

New features:

* Add waveguide function fasthomogeneous. This function calculates propagation through a homogeneous section in very short time. Furthermore, by using the optional parameter PhaseConjugation, one can also quickly obtain the outcome of a backward (phase-conjugate) propagation.
* Add new possibilities for defining input fields. Input fields of bpmsolver are now defined via function handles or cell arrays of function handles, which allows one to efficiently define now also multiple and superimposed input fields. For backward compatibility, it is still possible to use the old definition via field structures generated when directly calling an input field function.
* Add function inputplot, which displays the input field defined in a beamProblem. The input field to be displayed can also be specified as an input field function handle or cell array of input field function handles and passed to inputplot as second, optional parameter. Consequently, the Monitor parameters have been removed from all input field functions.
* Add possibility to define complex refractive indices with negative or positive imaginary parts to all waveguide functions for modeling optical attenuation or gain. Until now, only negative imaginary parts were allowed.
* Add parameter WideAngleOrder. This parameter allows one to specify the order of a Padé approximant up to order 3. A value of 0 corresponds to the Padé order (0,1) and represents paraxial approximation. Furthermore, the values 1, 2, and 3 correspond to the Padé orders (1,1), (2,2), and (3,3), respectively. The default value of WideAngleOrder is 0 except for homogeneous sections where BPM automatically adapts the algorithm for a WideAngleOrder of 1.
* Add parameter ProfileExponent to the waveguide functions plc and rib. This parameter allows one to specify the exponent of the core's permittivity distribution to simulate various types of graded-index profiles.
* Add possibility to specify VideoResolution in dots per inch (DPI). VideoResolution can now alternatively be defined as a string containing '-r' and an integer value indicating the resolution in DPI. For example, '-r300' sets the output resolution to 300 DPI.
* Add demo photonic_lantern, which simulates the beam propagation in a photonic lantern with vanishing cores.
* Add demo three_beam_interference. This demo shows how to define multiple input fields (three Gaussian beams with different Shift and Angle values) that propagate simultaneously in free space.

Enhancements:

* Improve performance of bpmsolver for full-vectorial calculations.
* Improve performance of gaussinput.
* Improve performance of license manager.
* Improve the definition of graded-index core profiles in conjunction with core shapes other than circular.
* Improve multicore waveguide code with respect to 2D BPM simulations.
* Improve figure titles.
* Improve demo scripts.
* Improve documentation.

Bug fixes:

* Fix license manager bug when using certain MATLAB® versions.
* Fix bug when displaying the phase distribution during a BPM calculation.
* Various minor bug fixes.

v1.2.1 (January 22, 2018)
-------------------------

New features:

* Add support for all video profiles supported by the MATLAB® function VideoWriter. For this purpose, the parameter VideoFileFormat has been replaced by the new parameter VideoProfile, which can be set to the values 'Archival', 'Motion JPEG AVI' (default), 'Motion JPEG 2000', 'MPEG-4', 'Uncompressed AVI', 'Indexed AVI', and 'Grayscale AVI'.

Enhancements:

* Improve titles and axis labels.
* Improve demo scripts.
* Improve documentation.

Bug fixes:

* Fix a bug that introduced an erroneous phase shift of the field at the boundary between two different media.
* Fix a bug that was causing wrong titles in figures generated by modesolver.
* Various minor bug fixes.

v1.2.0 (January 18, 2018)
-------------------------

New features:

* Add new class of path functions. These functions allow the definition of complex 3D trajectories with just a few lines of MATLAB® code, making the definition of complex waveguide structures both easy and flexible. They can be used anywhere in BeamLab, where custom functions define a lateral offset in x- and y-direction as a function of the longitudinal z-value. For example, path functions can be used as ShiftFunction in the waveguide functions singlecore, multicore, plc, and rib to define complex trajectories along which waveguide cores are shifted. Path functions can also be used as custom PowerCenterFunction and PowerAreaTransitionFunction in a large number of waveguide functions, offering a high flexibility in terms of defining power calculation trajectories and areas, respectively.
* Add path function linsinpath, which interpolates the lateral x- and y-values between transition points via sine functions, linear functions, or combinations thereof. The optional parameter TransitionType specifies the absolute length of the sinusoidal transition after a transition point and before the next one. A value of 0 corresponds to a purely linear shift between two transition points and a value of Inf (or greater than the transition length between two transition points) corresponds to a purely sinusoidal transition, respectively.
* Add path function splinepath, which uses the MATLAB® function spline for interpolating the lateral x- and y-values between transition points via a cubic spline interpolation.
* Add path function pchippath, which uses the MATLAB® function pchip for interpolating the lateral x- and y-values between transition points via a piecewise cubic Hermite interpolating polynomial (PCHIP).
* Add function modeinput. This function generates an input field for a BPM simulation based on the eigenmode number ModeNumber of the waveguide core specified in ModeCore of waveguide section specified in ModeSections instead of having to use a separate modesolver call in conjunction with custominput. The function modeinput uses the cached output from a previous call if the waveguide function and other relevant parameters have not changed. Since only the waveguide from the section specified in ModeSections is relevant for modeinput, other sections can be modified and/or additional sections can be added or sections can be removed without having to recalculate the input field.
* Add function getcommonvars. This new function automatically returns all common variables, which have been defined in a waveguide function up to the point where getcommonvars is executed. This eliminates the need to manually specify the common variables which should not be cleared in a subsequent execution of sectionclear.
* Add waveguide function thinprism. This function emulates an ideal prism of zero thickness that deflects an input beam by a specified angle.
* Add waveguide function thinzernike. This function creates a circular phase screen defined by a Zernike polynomial.
* Add demo rgb_beam_combiner, which simulates the beam propagation in an integrated silica RGB beam combiner using the new path function linsinpath for defining the waveguide structure.
* Add demo mach_zehnder_interferometer, which simulates the beam propagation through a Mach-Zehnder interferometer (MZI) with two input and two output arms.
* Add demo rib_splitter, which simulates the beam propagation in a polymer rib waveguide splitter using the new path function pchippath for defining the waveguide structure.
* Add demo freespace_deflection, which simulates the deflection of a Gaussian beam by several ideal prisms using the new waveguide function thinprism.
* Add demo directional_coupler_performance, which performs the same simulation much faster as the original demo directional_coupler by omitting the index scanner and live monitor functionalities.
* Add possibility to define SuperGaussDegree in gaussinput for x- and y-direction independently.
* Add parameters SlicesXZGraphType and SlicesYZGraphType. Similar to the parameter SlicesXYGraphType, these two new parameters specify the plot types of x-z and y-z slice plots. These parameters now allow also the generation of 2D or 3D slice plots of the real part, imaginary part, amplitude, or phase of the field distribution, besides the intensity distribution.
* Add parameter ModeCore. This parameter specifies a single core in a multi-core type waveguide function, such as multicore, plc, or rib, to be used for a mode evaluation. In conjunction with the input function modeinput, it can be used to select a specific core as the location of field input for BPM simulations, and thus eliminates the need for defining a separate dummy waveguide section that was hitherto used only for an input field specific mode evaluation.
* Add parameter NumericalAperture to gaussinput to take into account the numerical aperture of the optical system generating the Gaussian input beam. When set to Inf (which corresponds to the default value), also beam waists beyond the classical resolution limit can be generated, e.g., beam widths smaller than the wavelength. Note however that the use of such small beam waists cause the beam to strongly diverge shortly behind the location of the waist.
* Add new materials to material database.

Enhancements:

* Change parameter order in waveguide functions multicore, plc, and rib to improve consistency throughout all waveguide functions.
* Replace required parameter shift by optional parameter Shift in plc waveguide function.
* Improve dispersionsolver to work also with complex refractive indices.
* Improve input field functions.
* Improve waveguide functions with respect to 2D calculations.
* Improve memory efficiency in modesolver.
* Remove numerical noise in imaginary part of modes.
* Remove restriction of the video export functionality requiring MATLAB version 8.2 (R2013b) or later.
* Use IndexRange also for all monitor and x-y slice plots.
* Add possibility to define MonitorGraphType, SlicesXYGraphType, SlicesXZGraphType, SlicesYZGraphType, IndexSlicesXYGraphType, and DispersionGraphType as string.
* Add possibility to set SlicesXYGraphType, SlicesXZGraphType, SlicesYZGraphType in bpmplot independent of previous choices.
* Add possibility to set SlicesXYGraphType in modeplot independent of previous choices.
* Add possibility to define CoreShapeFactor, Shift, and ShiftEnd as cell arrays in rib.
* Add possibility to change the faceted shading line width via optional parameter LineWidth.
* Add general tips how to reduce the overall computation time of BeamLab simulations to documentation.
* Add subdirectories to demos directory.
* Improve titles and axis labels.
* Improve warning and error messages.
* Improve demo scripts.
* Improve documentation.

Bug fixes:

* Fix bug with respect to semi-vectorial calculations using y-polarization.
* Fix units of field and intensity distributions for 2D calculations.
* Fix bug in plc when using materials from the material database.
* Fix bug in rib waveguide function with respect to 2D calculations.
* Fix bug in stacked slices plots when plotting the field's phase.
* Various minor bug fixes.

v1.1.0 (September 27, 2017)
---------------------------

New features:

* Add BeamLab Material Database. This database contains important parameters such as the Sellmeier coefficients of some frequently used optical materials. Refractive indices of all waveguide functions can now be defined either as numerical scalars or material structures. The structures can be generated by the newly added function getmaterial. The input argument of the function can either be the name of a material from the material database or a vector with custom Sellmeier coefficients.
* Add function getindex for calculating the wavelength-depended refractive index of a material stored as structure in the material database or defined by custom Sellmeier coefficients.
* Add support for the MATLAB® Parallel Computing Toolbox™ to dispersionsolver.
* Add new parameter UseParallel, which enables BeamLab's internal Parallel Computing Toolbox™ functionalities.
* Add new demo script mmi_coupler_2d_sweep_parallel that demonstrates a parallelized parameter sweep using the MATLAB® Parallel Computing Toolbox™.
* Add new demo script mmi_coupler_2d_optim_parallel that demonstrates a parallelized optimization problem using the MATLAB® Parallel Computing Toolbox™ and Optimization Toolbox™.
* Add support for 2D calculations in the y-z plane.
* Add possibility to define a core consisting of multiple core zones with different core widths and core indices to singlecore and multicore. This allows, e.g., the simulation of an index trench around a core.
* Add new demo script multicore_index_trench that demonstrates beam propagation in a multicore fiber with cores surrounded by an index trench that are adiabatically tapered down to a multimode fiber with a core surrounded by an index trench.
* Add progress bar to bpmsolver displaying the following information during a BPM simulation: simulation progress in percent, graphical progress bar, estimation of remaining simulation time, current section number, and current z-value. The parameters CommandLineProgressMonitor and CommandLineProgressMonitorStep have been removed. The progress bar is displayed when CommandLineVerbosityLevel is greater than 0. If CommandLineVerbosityLevel is set to 0, all command-line output - including the progress bar - is disabled.
* Add possibility to adjust the PowerTraceScale parameter in bpmplot.

Enhancements:

* Improve stability of semi-vectorial BPM kernel.
* Improve symmetry checks in waveguide functions.
* Improve taper functionality in singlecore, multicore, and plc. In plc, the parameter TaperLength has been added and the parameters CoreTaperTransition and CoreTaperTransitionFunction have been renamed to TaperTransition and TaperTransitionFunction, respectively.
* Improve multicore with respect to overlapping cores.
* Improve dispersionsolver and dispersionplot.
* Rename the parameter CoreShape to CoreType in singlecore, multicore, plc, and rib as this parameter determines the type (e.g., step-index, graded-index, or user-defined core) rather than only the shape.
* Rename the parameter CoreShapeFunction to CoreFunction in singlecore, multicore, plc, and rib. CoreFunction must return a matrix containing the index distribution when CoreType is set to 'custom2D' or 'custom3D'.
* Remove the parameter SmoothingType from singlecore, multicore, plc, and rib. In these waveguide functions, the degree of smoothing is now determined solely by the values of the parameters SmoothingWidth and SmoothingLevel.
* Improve formatting of warning and error messages.
* Improve demo scripts.
* Improve documentation.

Bug fixes:

* Fix bug in dispersionsolver when singlecore parameters coreWidth and coreIndex contain cell arrays (e.g., for definitions with an index trench).
* Fix bug in sectionclear.
* Fix bugs in waveguide functions when used as 2D structures.
* Various minor bug fixes.

v1.0.1 (July 4, 2017)
---------------------

Enhancements:

* Improve indexplot.
* Improve dispersionsolver and dispersionplot.
* Improve documentation.

Bug fixes:

* Fix bug with respect to the calculation of the core and inner cladding shape.
* Various minor bug fixes.

v1.0.0 (July 3, 2017)
---------------------

Initial release


Contact
=======

Support tickets for questions, bug reports, and feedback can be submitted at www.codeseeder.com/submit-ticket/. If you have any general questions, please do not hesitate to contact us at support@codeseeder.com. 


Imprint
=======

CodeSeeder KG
Ketzergasse 354/1/3
1230 Vienna
Austria

Email: info@codeseeder.com
Web: www.codeseeder.com

Handelsgericht Wien
FN 463967 f
UID/VAT: ATU71903149

Copyright 2017-2018 CodeSeeder
