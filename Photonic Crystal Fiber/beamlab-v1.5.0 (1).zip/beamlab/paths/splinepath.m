%SPLINEPATH - Interpolate path via a cubic spline interpolation.
%
%   This BeamLab function uses the MATLAB(R) function spline for
%   interpolating the lateral x- and y-values between transition points
%   defined in the matrix points via a cubic spline interpolation.
%   
%   pos = SPLINEPATH(z,points)
%   pos = SPLINEPATH(___,options)
%   pos = SPLINEPATH(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Breakpoints = [];
%
%   <a href="matlab:beamlabdoc splinepath">Reference page for splinepath</a>
%
%   See also PCHIPPATH, LINSINPATH.

%   Copyright 2017-2018 CodeSeeder
