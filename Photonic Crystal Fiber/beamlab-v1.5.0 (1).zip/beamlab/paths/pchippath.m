%PCHIPPATH - Interpolate path via a piecewise cubic Hermite interpolating polynomial.
%
%   This BeamLab function uses the MATLAB(R) function pchip for
%   interpolating the lateral x- and y-values between transition points
%   defined in the matrix points via a piecewise cubic Hermite
%   interpolating polynomial (PCHIP).
%   
%   pos = PCHIPPATH(z,points)
%   pos = PCHIPPATH(___,options)
%   pos = PCHIPPATH(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Breakpoints = [];
%
%   <a href="matlab:beamlabdoc pchippath">Reference page for pchippath</a>
%
%   See also SPLINEPATH, LINSINPATH.

%   Copyright 2017-2018 CodeSeeder
