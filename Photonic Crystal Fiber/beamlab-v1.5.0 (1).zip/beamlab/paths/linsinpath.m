%LINSINPATH - Interpolate path via sine and linear functions.
%
%   This BeamLab function interpolates the lateral x- and y-values between
%   transition points defined in the matrix points via sine functions,
%   linear functions, or combinations thereof. The optional parameter
%   TransitionType specifies the absolute length of the sinusoidal
%   transition after a transition point and before the next one. A value of
%   0 corresponds to a purely linear shift between two transition points
%   and a value of Inf (or greater than the transition length between two
%   transition points) corresponds to a purely sinusoidal transition,
%   respectively.
%   
%   pos = LINSINPATH(z,points)
%   pos = LINSINPATH(___,options)
%   pos = LINSINPATH(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Breakpoints = [];
%   options.TransitionType = [];
%
%   <a href="matlab:beamlabdoc linsinpath">Reference page for linsinpath</a>
%
%   See also SPLINEPATH, PCHIPPATH.

%   Copyright 2017-2018 CodeSeeder
