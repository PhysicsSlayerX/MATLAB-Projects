%FASTHOMOGENEOUS - Create fast homogeneous section.
%
%   This BeamLab function emulates propagation through a homogeneous
%   section of length len.
%
%   output = @(beamProblem) FASTHOMOGENEOUS(beamProblem,len,index);
%   output = @(beamProblem) FASTHOMOGENEOUS(___,options);
%   output = @(beamProblem) FASTHOMOGENEOUS(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%
%   options.ExpansionFactor = 3;
%   options.PhaseConjugation = false;
%   options.SectionTitle = 'fasthomogeneous';
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.Step = beamProblem.Options.Step;
%
%   <a href="matlab:beamlabdoc fasthomogeneous">Reference page for fasthomogeneous</a>
%
%   See also BPMSOLVER, BEAMSET, HOMOGENEOUS.

%   Copyright 2017-2018 CodeSeeder
