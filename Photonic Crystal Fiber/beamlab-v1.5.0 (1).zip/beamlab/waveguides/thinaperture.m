%THINAPERTURE - Thin aperture.
%
%   This BeamLab function generates a medium of zero thickness with an 
%   aperture of arbitrary shape and location.
%
%   output = @(beamProblem) THINAPERTURE(beamProblem,apertureWidth);
%   output = @(beamProblem) THINAPERTURE(___,options);
%   output = @(beamProblem) THINAPERTURE(___,'param1',value1,'param2',value2,...);
%   [output,figureHandles] = @(beamProblem) THINAPERTURE(___);
%
%   Reference list of all options with their default values:
%
%   options.ApertureInverse = false;
%   options.ApertureNumber = [1 1];
%   options.ApertureRotation = 0;
%   options.ApertureShape = 'predefined';
%   options.ApertureShapeFactor = 2;
%   options.ApertureShapeFunction = [];
%   options.Period = 2*apertureWidth;
%   options.SectionTitle = 'thinaperture';
%   options.Shift = [0 0];
%   options.SlicesXYSectionEnd = false;
%   options.SmoothingLevel = 3;
%   options.SmoothingWidth = 1;
%   options.TransmittanceSlicesXY = false;
%
%   <a href="matlab:beamlabdoc thinaperture">Reference page for thinaperture</a>
%
%   See also BPMSOLVER, BEAMSET, THINCUSTOMMEDIUM, THINGAINMEDIUM, THINHELIX, THINLENS.

%   Copyright 2017-2018 CodeSeeder
