%CUSTOMWAVEGUIDE3D - Custom 3D waveguide defined by the user.
%
%   This BeamLab function creates a 3D refractive index distribution as
%   a function of x, y, and z representing a single waveguide whose shape
%   is defined by the user.
%   
%   output = @(beamProblem) CUSTOMWAVEGUIDE3D(beamProblem,len,indexFunction3D);
%   output = @(beamProblem) CUSTOMWAVEGUIDE3D(___,options);
%   output = @(beamProblem) CUSTOMWAVEGUIDE3D(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%
%   options.Anisotropy = [1 1 1];
%   options.BendPlaneAngle = 0;
%   options.BendRadius = Inf;
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'fixed';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.SectionTitle = 'customwaveguide3d';
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.SmoothingLevel = 1;
%   options.SmoothingWidth = 0;
%   options.Step = beamProblem.Options.Step;
%
%   <a href="matlab:beamlabdoc customwaveguide3d">Reference page for customwaveguide3d</a>
%
%   See also BPMSOLVER, MODESOLVER, BEAMSET, CUSTOMWAVEGUIDE2D, MULTICORE, PLC, RIB, SINGLECORE. 

%   Copyright 2017-2018 CodeSeeder
