%THINHELIX - Thin medium with custom helical phase function.
%
%   This BeamLab function imposes a helical phase distribution emulating a
%   beam with orbital angular momentum of a given order.
%
%   output = @(beamProblem) THINHELIX(beamProblem,order);
%   output = @(beamProblem) THINHELIX(___,options);
%   output = @(beamProblem) THINHELIX(___,'param1',value1,'param2',value2,...);
%   [output, figureHandles] = @(beamProblem) THINHELIX(___);
%
%   Reference list of all options with their default values:
%
%   options.Rotation = 0;
%   options.SectionTitle = 'thinhelix';
%   options.Shift = [0 0];
%   options.SlicesXYSectionEnd = false;
%   options.TransmittanceSlicesXY = false;
%
%   <a href="matlab:beamlabdoc thinhelix">Reference page for thinhelix</a>
%
%   See also BPMSOLVER, BEAMSET, THINAPERTURE, THINCUSTOMMEDIUM, THINGAINMEDIUM, THINHELIX, THINLENS.

%   Copyright 2017-2018 CodeSeeder
