%THINPRISM - Ideal thin prism.
%
%   This BeamLab function imposes a phase distribution that emulates an
%   ideal prism of zero thickness which deflects the input beam by a
%   specified angle.
%
%   output = @(beamProblem) THINPRISM(beamProblem,outputAngle);
%   output = @(beamProblem) THINPRISM(___,options);
%   output = @(beamProblem) THINPRISM(___,'param1',value1,'param2',value2,...);
%   [output, figureHandles] = @(beamProblem) THINPRISM(___);
%
%   Reference list of all options with their default values:
%
%   options.SectionTitle = 'thinprism';
%   options.SlicesXYSectionEnd = false;
%   options.TransmittanceSlicesXY = false;
%
%   <a href="matlab:beamlabdoc thinprism">Reference page for thinprism</a>
%
%   See also BPMSOLVER, BEAMSET, THINAPERTURE, THINCUSTOMMEDIUM, THINGAINMEDIUM, THINHELIX, THINLENS.

%   Copyright 2017-2018 CodeSeeder
