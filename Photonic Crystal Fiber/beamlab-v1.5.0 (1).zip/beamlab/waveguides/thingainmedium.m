%THINGAINMEDIUM - Thin medium with gain or loss.
%
%   This BeamLab function emulates a medium of zero thickness and arbitrary
%   gain. The gain can be positive (indicating amplification) or negative
%   (indicating loss).
%
%   output = @(beamProblem) THINGAINMEDIUM(beamProblem,width,gain);
%   output = @(beamProblem) THINGAINMEDIUM(___,options);
%   output = @(beamProblem) THINGAINMEDIUM(___,'param1',value1,'param2',value2,...);
%   [output, figureHandles] = @(beamProblem) THINGAINMEDIUM(___);
%
%   Reference list of all options with their default values:
%
%   options.SectionTitle = 'thingainmedium';
%   options.Shift = [0 0];
%   options.SlicesXYSectionEnd = false;
%   options.TransmittanceSlicesXY = false;
%   options.Type = 'tophat';
%
%   <a href="matlab:beamlabdoc thingainmedium">Reference page for thingainmedium</a>
%
%   See also BPMSOLVER, BEAMSET, THINAPERTURE, THINCUSTOMMEDIUM, THINHELIX, THINLENS.

%   Copyright 2017-2018 CodeSeeder
