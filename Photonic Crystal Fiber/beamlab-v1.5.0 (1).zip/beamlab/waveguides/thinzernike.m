%THINZERNIKE - Thin phase screen defined by a Zernike polynomial.
%
%   This BeamLab function imposes a phase distribution given by a Zernike
%   polynomial with specified coefficients.
%
%   output = @(beamProblem) THINZERNIKE(beamProblem,coefficients);
%   output = @(beamProblem) THINZERNIKE(___,options);
%   output = @(beamProblem) THINZERNIKE(___,'param1',value1,'param2',value2,...);
%   [output, figureHandles] = @(beamProblem) THINZERNIKE(___);
%
%   Reference list of all options with their default values:
%
%   options.ApertureDiameter = min(beamProblem.GridSize);
%   options.Normalization = false;
%   options.Rotation = 0;
%   options.SectionTitle = 'thinzernike';
%   options.Shift = [0 0];
%   options.SlicesXYSectionEnd = false;
%   options.TransmittanceSlicesXY = false;
%
%   <a href="matlab:beamlabdoc thinzernike">Reference page for thinzernike</a>
%
%   See also BPMSOLVER, BEAMSET, THINAPERTURE, THINCUSTOMMEDIUM, THINGAINMEDIUM, THINHELIX, THINLENS, THINPRISM

%   Copyright 2017-2018 CodeSeeder
