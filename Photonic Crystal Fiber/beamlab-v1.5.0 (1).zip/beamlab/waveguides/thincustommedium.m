%THINCUSTOMMEDIUM - Thin medium with custom transfer function.
%
%   This BeamLab function emulates a medium of zero thickness whose 
%   transfer function is given by a user-defined function.
%
%   output = @(beamProblem) THINCUSTOMMEDIUM(beamProblem,mediumFunction);
%   output = @(beamProblem) THINCUSTOMMEDIUM(___,options);
%   output = @(beamProblem) THINCUSTOMMEDIUM(___,'param1',value1,'param2',value2,...);
%   [output, figureHandles] = @(beamProblem) THINCUSTOMMEDIUM(___);
%
%   Reference list of all options with their default values:
%
%   options.SectionTitle = 'thincustommedium';
%   options.SlicesXYSectionEnd = false;
%   options.TransmittanceSlicesXY = false;
%
%   <a href="matlab:beamlabdoc thincustommedium">Reference page for thincustommedium</a>
%
%   See also BPMSOLVER, BEAMSET, THINAPERTURE, THINGAINMEDIUM, THINHELIX, THINLENS.

%   Copyright 2017-2018 CodeSeeder
