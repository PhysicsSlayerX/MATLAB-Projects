%THINLENS - Ideal thin lens.
%
%   This BeamLab function imposes a phase distribution that emulates an
%   ideal lens of zero thickness with focal length focalLength.
%
%   output = @(beamProblem) THINLENS(beamProblem,focalLength);
%   output = @(beamProblem) THINLENS(___,options);
%   output = @(beamProblem) THINLENS(___,'param1',value1,'param2',value2,...);
%   [output, figureHandles] = @(beamProblem) THINLENS(___);
%
%   Reference list of all options with their default values:
%
%   options.LensType = 'spherical';
%   options.SectionTitle = 'thinlens';
%   options.Shift = [0 0];
%   options.SlicesXYSectionEnd = false;
%   options.TransmittanceSlicesXY = false;
%
%   <a href="matlab:beamlabdoc thinlens">Reference page for thinlens</a>
%
%   See also BPMSOLVER, BEAMSET, THINAPERTURE, THINCUSTOMMEDIUM, THINGAINMEDIUM, THINHELIX.

%   Copyright 2017-2018 CodeSeeder
