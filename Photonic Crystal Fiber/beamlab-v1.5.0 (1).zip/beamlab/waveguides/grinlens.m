%GRINLENS - GRIN lens or GRIN lens array.
%
%   This BeamLab function emulates a single GRIN lens or a GRIN lens array
%   with an arbitrary number of lenses whose size, refractive index profile
%   and location can be manipulated in various ways.
%
%   output = @(beamProblem) GRINLENS(beamProblem,len,lensWidth,innerIndex,gradientConstant);
%   output = @(beamProblem) GRINLENS(___,options);
%   output = @(beamProblem) GRINLENS(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.LensNumber = 1;
%   options.LensType = 'spherical';
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.OuterIndex = [];
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'lens';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.RingAngleOffset = 0;
%   options.RingRadius = 0;
%   options.SectionTitle = 'grinlens';
%   options.Shift = [0 0];
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.Step = beamProblem.Options.Step;
%
%   <a href="matlab:beamlabdoc grinlens">Reference page for grinlens</a>
%
%   See also BPMSOLVER, MODESOLVER, BEAMSET.

%   Copyright 2017-2018 CodeSeeder
