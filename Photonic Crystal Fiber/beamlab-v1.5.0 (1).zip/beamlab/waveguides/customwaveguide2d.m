%CUSTOMWAVEGUIDE2D - Custom 2D waveguide defined by user.
%
%   This BeamLab function emulates a waveguide that is defined by the user.
%   It requires as input a 2D refractive index distribution as a function
%   of x and y representing a single or group of waveguides. The center and
%   rotation angle of the waveguide(s) can be varied along z.
%   
%   output = @(beamProblem) CUSTOMWAVEGUIDE2D(beamProblem,len,indexFunction2D);
%   output = @(beamProblem) CUSTOMWAVEGUIDE2D(___,options);
%   output = @(beamProblem) CUSTOMWAVEGUIDE2D(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%
%   options.Anisotropy = [1 1 1];
%   options.BendPlaneAngle = 0;
%   options.BendRadius = Inf;
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'fixed';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.SectionTitle = 'customwaveguide2d';
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.SmoothingLevel = 1;
%   options.SmoothingWidth = 0;
%   options.Step = beamProblem.Options.Step;
%   options.WaveguideCenter = [];
%   options.WaveguideRotation = [];
%   options.WaveguideRotationEnd = [];
%
%   <a href="matlab:beamlabdoc customwaveguide2d">Reference page for customwaveguide2d</a>
%
%   See also BPMSOLVER, MODESOLVER, BEAMSET, CUSTOMWAVEGUIDE3D, MULTICORE, PLC, RIB, SINGLECORE.

%   Copyright 2017-2018 CodeSeeder
