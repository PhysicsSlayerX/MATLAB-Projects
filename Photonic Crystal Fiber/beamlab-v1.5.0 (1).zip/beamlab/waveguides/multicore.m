%MULTICORE - multi-core waveguide
%
%   This BeamLab function emulates a straight or bent waveguide consisting
%   of multiple cores located on concentric rings of arbitrary radii. The
%   number, shape and location of the cores in each ring can be freely
%   adjusted.
%
%   output = @(beamProblem) MULTICORE(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius);
%   output = @(beamProblem) MULTICORE(___,options);
%   output = @(beamProblem) MULTICORE(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%   
%   options.Anisotropy = [1 1 1];
%   options.BendPlaneAngle = 0;
%   options.BendRadius = Inf;
%   options.CoreFunction = [];
%   options.CoreShapeFactor = 2;
%   options.CoreType = 'predefined';
%   options.CoreWidthEnd = coreWidth;
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.InnerCladdingIndex = claddingIndex;
%   options.InnerCladdingShapeFactor = 2;
%   options.InnerCladdingTaperTransition = 'sinusoidal';
%   options.InnerCladdingTaperTransitionFunction = [];
%   options.InnerCladdingWidth = beamProblem.GridSize;
%   options.InnerCladdingWidthEnd = options.InnerCladdingWidth;
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'core';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.ProfileExponent = Inf;
%   options.RingAngleOffset = 0;
%   options.RingAngleOffsetEnd = options.RingAngleOffset;
%   options.RingAngleTransition = 'sinusoidal';
%   options.RingAngleLength = len;
%   options.RingRadiusEnd = ringRadius;
%   options.RingRadiusTransition = 'sinusoidal';
%   options.RingRadiusTransitionFunction = [];
%   options.RingRadiusTransitionLength = len;
%   options.SectionTitle = 'multicore';
%   options.Shift = [0 0];
%   options.ShiftEnd = options.Shift;
%   options.ShiftLength = len;
%   options.ShiftTransition = 'sinusoidal';
%   options.ShiftTransitionFunction = [];
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.SmoothingLevel = 3;
%   options.SmoothingWidth = 1;
%   options.Step = beamProblem.Options.Step;
%   options.TaperTransition = 'sinusoidal';
%   options.TaperTransitionFunction = [];
%
%   <a href="matlab:beamlabdoc multicore">Reference page for multicore</a>
%
%   See also BPMSOLVER, MODESOLVER, BEAMSET, PLC, RIB, SINGLECORE.

%   Copyright 2017-2018 CodeSeeder
