%SINGLECORE - Single-core waveguide.
%
%   This BeamLab function emulates a straight or bent waveguide with a 
%   single core.
%
%   output = @(beamProblem) SINGLECORE(beamProblem,len,coreWidth,coreIndex,claddingIndex);
%   output = @(beamProblem) SINGLECORE(___,options);
%   output = @(beamProblem) SINGLECORE(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%
%   options.Anisotropy = [1 1 1];
%   options.BendPlaneAngle = 0;
%   options.BendRadius = Inf;
%   options.CoreFunction = [];
%   options.CoreRotation = 0;
%   options.CoreRotationEnd = options.CoreRotation;
%   options.CoreShapeFactor = 2;
%   options.CoreType = 'predefined';
%   options.CoreWidthEnd = coreWidth;
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.InnerCladdingIndex = claddingIndex;
%   options.InnerCladdingShapeFactor = 2;
%   options.InnerCladdingTaperTransition = 'sinusoidal';
%   options.InnerCladdingTaperTransitionFunction = [];
%   options.InnerCladdingWidth = beamProblem.GridSize;
%   options.InnerCladdingWidthEnd = options.InnerCladdingWidth;
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'core';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.ProfileExponent = Inf;
%   options.SectionTitle = 'singlecore';
%   options.Shift = [0 0];
%   options.ShiftEnd = options.Shift;
%   options.ShiftLength = len;
%   options.ShiftTransition = 'sinusoidal';
%   options.ShiftTransitionFunction = [];
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.SmoothingLevel = 3;
%   options.SmoothingWidth = 1;
%   options.Step = beamProblem.Options.Step;
%   options.TaperLength = len;
%   options.TaperTransition = 'sinusoidal';
%   options.TaperTransitionFunction = [];
%
%   <a href="matlab:beamlabdoc singlecore">Reference page for singlecore</a>
%
%   See also BPMSOLVER, MODESOLVER, BEAMSET, MULTICORE, PLC, RIB.

%   Copyright 2017-2018 CodeSeeder
