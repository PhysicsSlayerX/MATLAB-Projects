%HOMOGENEOUS - Create homogeneous section.
%
%   This BeamLab function emulates a layer without modulation.
%
%   output = @(beamProblem) HOMOGENEOUS(beamProblem,len,index);
%   output = @(beamProblem) HOMOGENEOUS(___,options);
%   output = @(beamProblem) HOMOGENEOUS(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
%
%   options.Anisotropy = [1 1 1];
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'fixed';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.Rotation = 0;
%   options.RotationEnd = options.Rotation;
%   options.SectionTitle = 'homogeneous';
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.Step = beamProblem.Options.Step;
%
%   <a href="matlab:beamlabdoc homogeneous">Reference page for homogeneous</a>
%
%   See also BPMSOLVER, BEAMSET, FASTHOMOGENEOUS.

%   Copyright 2017-2018 CodeSeeder
