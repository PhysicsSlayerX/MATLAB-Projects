%PLC - Planar lightwave circuit.
%
%   This BeamLab function emulates waveguides of a planar lightwave
%   circuit. The number, shape and location of each waveguide can be freely 
%   adjusted.
%
%   output = @(beamProblem) PLC(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex);
%   output = @(beamProblem) PLC(___,options);
%   output = @(beamProblem) PLC(___,'param1',value1,'param2',value2,...);
%
%   Reference list of all options with their default values:
% 
%   options.Anisotropy = [1 1 1];
%   options.BendPlaneAngle = 0;
%   options.BendRadius = Inf;
%   options.CoreFunction = [];
%   options.CoreShapeFactor = Inf;
%   options.CoreType = 'predefined';
%   options.CoreWidthEnd = coreWidth;
%   options.Index3DStep = beamProblem.Options.Index3DStep;
%   options.IndexScannerStep = beamProblem.Options.IndexScannerStep;
%   options.MonitorStep = beamProblem.Options.MonitorStep;
%   options.PowerAreaCenter = [0 0];
%   options.PowerAreaSize = 2*beamProblem.GridSize;
%   options.PowerAreaSizeEnd = options.PowerAreaSize;
%   options.PowerAreaTransition = 'sinusoidal';
%   options.PowerAreaTransitionFunction = [];
%   options.PowerAreaType = 'rectangular';
%   options.PowerCenter = 'core';
%   options.PowerCenterFunction = [];
%   options.PowerTrace = beamProblem.Options.PowerTrace;
%   options.ProfileExponent = Inf;
%   options.SectionTitle = 'plc';
%   options.Shift = [0 0];
%   options.ShiftEnd = options.Shift;
%   options.ShiftLength = len;
%   options.ShiftTransition = 'sinusoidal';
%   options.ShiftTransitionFunction = [];
%   options.SlicesXYSectionEnd = false;
%   options.SlicesXZYZStep = beamProblem.Options.SlicesXZYZStep;
%   options.SmoothingLevel = 3;
%   options.SmoothingWidth = 1;
%   options.Step = beamProblem.Options.Step;
%   options.TaperLength = len;
%   options.TaperTransition = 'sinusoidal';
%   options.TaperTransitionFunction = [];
%
%   <a href="matlab:beamlabdoc plc">Reference page for plc</a>
%
%   See also BPMSOLVER, MODESOLVER, BEAMSET, MULTICORE, RIB, SINGLECORE.

%   Copyright 2017-2018 CodeSeeder
