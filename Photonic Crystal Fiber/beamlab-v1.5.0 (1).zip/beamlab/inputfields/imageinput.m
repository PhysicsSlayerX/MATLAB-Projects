%IMAGEINPUT - Generate input field distribution from image file.
%
%   This BeamLab function generates an input field distribution from an
%   image file. By default, one pixel of the image corresponds to one grid
%   point, e.g., when gridPoints is set to [1000 1000] and the image's size
%   is 1000 x 1000 pixels, the calculation area of the simulation is
%   completely filled by the image. By using the optional parameter Width,
%   the image can be resized to any desired size in LengthUnit. To improve
%   performance, this function uses the cached output from a previous call
%   if none of the parameters that affect the distribution has changed.
%
%   inputField = @(beamProblem) IMAGEINPUT(beamProblem,filename)
%   inputField = @(beamProblem) IMAGEINPUT(___,options)
%   inputField = @(beamProblem) IMAGEINPUT(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.FlipLeftRight = false;
%   options.FlipUpDown = false;
%   options.Inverse = false;
%   options.Rotation = 0;
%   options.Shift = [0 0];
%   options.Width = [];
%
%   <a href="matlab:beamlabdoc imageinput">Reference page for imageinput</a>
%
%   See also BEAMSET, BPMSOLVER, MODEINPUT, GAUSSINPUT, UNIFORMINPUT, CUSTOMINPUT.

%   Copyright 2017-2018 CodeSeeder
