%UNIFORMINPUT - Generate uniform input field distribution.
%
%   This BeamLab function generates an input field distribution of uniform
%   amplitude and phase within the transparent area of a single aperture or
%   aperture array. To improve performance, it uses the  cached output from
%   a previous call if none of the parameters that affect the distribution
%   has changed.
%
%   inputField = @(beamProblem) UNIFORMINPUT(beamProblem,width)
%   inputField = @(beamProblem) UNIFORMINPUT(___,options)
%   inputField = @(beamProblem) UNIFORMINPUT(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.ApertureNumber = [1 1];
%   options.ApertureRotation = 0;
%   options.ApertureShapeFunction = [];
%   options.ApertureType = 'elliptical';
%   options.Period = [];
%   options.Phase = 0;
%   options.Polarization = [1 0 0];
%   options.Power = 1;
%   options.Shift = [0 0];
%   options.SmoothingLevel = 3;
%   options.SmoothingWidth = 1;
%
%   <a href="matlab:beamlabdoc uniforminput">Reference page for uniforminput</a>
%
%   See also BEAMSET, BPMSOLVER, MODEINPUT, GAUSSINPUT, IMAGEINPUT, CUSTOMINPUT.

%   Copyright 2017-2018 CodeSeeder
