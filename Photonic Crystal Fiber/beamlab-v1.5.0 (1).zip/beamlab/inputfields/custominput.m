%CUSTOMINPUT - Check and adapt user-defined input field distribution.
%
%   This BeamLab function generates an input field distribution according
%   to an input field defined by the user.
%
%   inputField = @(beamProblem) CUSTOMINPUT(beamProblem,field)
%   inputField = @(beamProblem) CUSTOMINPUT(___,options)
%   inputField = @(beamProblem) CUSTOMINPUT(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Phase = 0;
%   options.Polarization = [];
%   options.Power = 1;
%
%   <a href="matlab:beamlabdoc custominput">Reference page for custominput</a>
%
%   See also BEAMSET, BPMSOLVER, MODEINPUT, GAUSSINPUT, UNIFORMINPUT, IMAGEINPUT.

%   Copyright 2017-2018 CodeSeeder
