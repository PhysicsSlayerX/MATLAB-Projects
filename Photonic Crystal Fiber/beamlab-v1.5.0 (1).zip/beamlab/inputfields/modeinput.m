%MODEINPUT - Generate input field distribution based on a waveguide eigenmode.
%
%   This BeamLab function generates an input field distribution based on
%   one eigenmode or a linear combination of eigenmodes of a waveguide 
%   calculated with modesolver. Waveguide section, waveguide core, number
%   of mode, mode polarization (in case of a semi-vectorial mode
%   calculation) can be specified either as optional beamProblem parameters
%   ModeSections, ModeCore, ModeSelect and ModePolarization, or directly as
%   input options to this function. To improve performance, modeinput uses
%   the cached output from a previous call if the waveguide function and
%   other relevant parameters have not changed. Since only the waveguide
%   from the section specified in ModeSections is relevant for modeinput,
%   other sections can be modified, added or removed without having to
%   recalculate the input field.
%   
%   inputField = @(beamProblem) MODEINPUT(beamProblem)
%   inputField = @(beamProblem) MODEINPUT(___,options)
%   inputField = @(beamProblem) MODEINPUT(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.ModeAmplitude = [];
%   options.ModeCore = [];
%   options.ModeNumber = [];
%   options.ModePolarization = [];
%   options.ModeSections = [];
%   options.ModeSelect = [];
%   options.ModeSortingOrder = [];
%   options.Polarization = [];
%   options.Phase = 0;
%   options.Power = 1;
%   options.SymmetryX = [];
%   options.SymmetryY = [];
%
%   <a href="matlab:beamlabdoc modeinput">Reference page for modeinput</a>
%
%   See also BEAMSET, BPMSOLVER, GAUSSINPUT, UNIFORMINPUT, IMAGEINPUT, CUSTOMINPUT.

%   Copyright 2017-2018 CodeSeeder
