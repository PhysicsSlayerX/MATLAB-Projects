%GAUSSINPUT - Generate Gaussian input field distribution.
%
%   This BeamLab function generates a Gaussian input field distribution. To
%   improve performance, it uses the  cached output from a previous call if
%   none of the parameters that affect the distribution has changed.
%
%   inputField = @(beamProblem) GAUSSINPUT(beamProblem,width)
%   inputField = @(beamProblem) GAUSSINPUT(___,options)
%   inputField = @(beamProblem) GAUSSINPUT(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Angle = [0 0];
%   options.HermiteGaussX = 0;
%   options.HermiteGaussY = 0;
%   options.LaguerreGaussPhi = 0;
%   options.LaguerreGaussR = 0;
%   options.LaguerreGaussType = 'nondegenerate';
%   options.ModeDegeneracy = 'even';
%   options.NumericalAperture = Inf;
%   options.Phase = 0;
%   options.Polarization = [1 0 0];
%   options.Power = 1;
%   options.Rotation = 0;
%   options.Shift = [0 0 0];
%   options.SuperGaussDegree = [2 2];
%
%   <a href="matlab:beamlabdoc gaussinput">Reference page for gaussinput</a>
%
%   See also BEAMSET, BPMSOLVER, MODEINPUT, UNIFORMINPUT, IMAGEINPUT, CUSTOMINPUT.

%   Copyright 2017-2018 CodeSeeder
