%INDEXPLOT - Plot 2D and/or 3D refractive index distributions.
%
%   This BeamLab function displays the refractive index distribution
%   defined in a beamProblem by scanning its cross-section in z-direction
%   and/or generating a 3D refractive index contour plot.
%
%   INDEXPLOT(beamProblem)
%   INDEXPLOT(___,options)
%   INDEXPLOT(___,'param1',value1,'param2',value2,...)
%   [index2D,index3D,figureHandles] = INDEXPLOT(___)
%
%   Reference list of all options with their default values:
%
%   options.Format = 2;
%   options.Index3D = true;
%   options.Index3DAspectRatio = [];
%   options.Index3DStep = [];
%   options.Index3DValues = [];
%   options.IndexRange = [];
%   options.IndexScanner = true;
%   options.IndexScannerStep = [];
%   options.IndexScannerStepTime = 0;
%   options.IndexSlicesXY = [];
%   options.IndexSlicesXYGraphType = '2D';
%   options.IndexSlicesXYStacked = 0;
%
%   <a href="matlab:beamlabdoc indexplot">Reference page for indexplot</a>

%   Copyright 2017-2018 CodeSeeder
