%SECTIONCLEAR - Clear variables between definitions of waveguide sections.
%
%   This BeamLab function clears variables such as an options structure
%   between the definition of multiple waveguide sections in order to avoid
%   passing unwanted parameters from a previous section to a waveguide
%   function.
%
%   SECTIONCLEAR
%   SECTIONCLEAR('KeepVariables','varname')
%   SECTIONCLEAR('KeepVariables','options.Varname')
%   SECTIONCLEAR('KeepVariables',{'varname1','varname2','options.Varname3'})
%
%   <a href="matlab:beamlabdoc sectionclear">Reference page for sectionclear</a>
%
%   See also GETCOMMONVARS, BEAMSET.

%   Copyright 2017-2018 CodeSeeder
