%BEAMGRID - Rectangular grid of a beamProblem in the x-y plane.
%
%   This BeamLab function returns output coordinate matrices X and Y of a
%   beamProblem.
%
%   [X,Y] = BEAMGRID(beamProblem)
%
%   <a href="matlab:beamlabdoc beamgrid">Reference page for beamgrid</a>
%
%   See also NDGRID.

%   Copyright 2017-2018 CodeSeeder
