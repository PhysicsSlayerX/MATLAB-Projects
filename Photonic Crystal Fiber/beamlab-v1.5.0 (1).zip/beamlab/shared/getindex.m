%GETINDEX - Calculate refractive index data.
%
%   This BeamLab function calculates the refractive index of a specified
%   material at a specified wavelength.
%
%   index = GETINDEX(material,lambda)
%   index = GETINDEX(___,options)
%   index = GETINDEX(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Delta = 0;
%   options.FormulaType = 1;
%
%   <a href="matlab:beamlabdoc getindex">Reference page for getindex</a>
%
%   See also GETMATERIAL.

%   Copyright 2017-2018 CodeSeeder
