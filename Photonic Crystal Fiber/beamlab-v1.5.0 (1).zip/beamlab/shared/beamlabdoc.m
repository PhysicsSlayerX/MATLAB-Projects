%BEAMLABDOC - BeamLab reference page in Help browser.
%
%   This BeamLab function opens the Help browser. If the Help browser is
%   already open, but not visible, then BEAMLABDOC brings it to the
%   foreground and opens a new tab.
%
%   BEAMLABDOC
%   BEAMLABDOC name
%   BEAMLABDOC expression
%
%   <a href="matlab:beamlabdoc beamlabdoc">Reference page for beamlabdoc</a>
%
%   See also HELP, DOC, DOCSEARCH.

%   Copyright 2017-2018 CodeSeeder
