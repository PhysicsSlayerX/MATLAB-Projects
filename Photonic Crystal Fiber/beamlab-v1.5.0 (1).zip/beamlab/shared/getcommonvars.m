%GETCOMMONVARS - Get all common variables in workspace.
%
%   This BeamLab function automatically returns all common variables, which
%   have been defined in a waveguide function up to the point where
%   GETCOMMONVARS is executed.
%   
%   vars = GETCOMMONVARS
%
%   <a href="matlab:beamlabdoc getcommonvars">Reference page for getcommonvars</a>
%
%   See also SECTIONCLEAR.

%   Copyright 2017-2018 CodeSeeder
