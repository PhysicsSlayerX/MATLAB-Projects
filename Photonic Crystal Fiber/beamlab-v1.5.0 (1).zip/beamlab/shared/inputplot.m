%INPUTPLOT - Plot input field distribution.
%
%   This BeamLab function displays the input field distribution defined in
%   beamProblem. Alternatively, the input field can also be specified as an
%   input field function handle or cell array of input field function
%   handles and passed to INPUTPLOT as second, optional parameter
%   inputField.
%
%   INPUTPLOT(beamProblem)
%   INPUTPLOT(beamProblem,inputField)
%   INPUTPLOT(___,options)
%   INPUTPLOT(___,'param1',value1,'param2',value2,...)
%   figureHandles = INPUTPLOT(___)
%
%   Reference list of all options with their default values:
% 
%   options.SlicesXYGraphType = 'Int2D';
%   options.SlicesXYRange = [];
%   options.SlicesXYScale = 'loginput';
%   options.SlicesXYView = [-37.5 30];
%
%   <a href="matlab:beamlabdoc inputplot">Reference page for inputplot</a>
%
%   See also BEAMSET, MODEINPUT, GAUSSINPUT, UNIFORMINPUT, CUSTOMINPUT.

%   Copyright 2017-2018 CodeSeeder
