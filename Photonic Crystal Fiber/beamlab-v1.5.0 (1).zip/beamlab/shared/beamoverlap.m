%BEAMOVERLAP - Calculate the normalized overlap integral.
%
%   This BeamLab function calculates the normalized overlap integral of the
%   two field distributions field1 and field2. The input arguments can be
%   either matrices containing only one field component (e.g., the x-component)
%   or structures containing any two or all three field components.
%
%   outputData = BEAMOVERLAP(field1,field2)
%
%   <a href="matlab:beamlabdoc beamoverlap">Reference page for beamoverlap</a>
%
%   See also BEAMSET, BPMSOLVER.

%   Copyright 2017-2018 CodeSeeder
