%GETMATERIAL - Create material structure.
%
%   This BeamLab function creates a material structure which contains
%   important parameters of the specified material.
%   
%   GETMATERIAL
%   materialStruct = GETMATERIAL(material)
%   materialStruct = GETMATERIAL(___,options)
%   materialStruct = GETMATERIAL(___,'param1',value1,'param2',value2,...)
%
%   Reference list of all options with their default values:
%
%   options.Delta = 0;
%   options.FormulaType = 1;
%   options.LambdaRange = [];
%   options.Plot = false;
%
%   <a href="matlab:beamlabdoc getmaterial">Reference page for getmaterial</a>
%
%   See also GETINDEX.

%   Copyright 2017-2018 CodeSeeder
