%BEAMLABDEMOS - BeamLab examples reference page in Help browser.
%
%   This BeamLab function opens the examples pages of the BeamLab
%   documentation in the Help browser. If the Help browser is already open,
%   but not visible, then BEAMLABDEMOS brings it to the foreground and
%   opens a new tab.
%
%   BEAMLABDEMOS
%
%   <a href="matlab:beamlabdoc beamlabdoc">Reference page for beamlabdemos</a>
%
%   See also BEAMLABDOC, HELP, DOC.

%   Copyright 2017-2018 CodeSeeder
