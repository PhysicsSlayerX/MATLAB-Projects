function bpmData = freespace_multislit_2d
%FREESPACE_MULTISLIT_2D - Propagation of a Gaussian beam through multiple slits.
%
%   This BeamLab demo shows a 2D Gaussian beam in free space normally
%   incident on a multi-slit with 3 openings.
%
%   FREESPACE_MULTISLIT_2D
%   bpmData = FREESPACE_MULTISLIT_2D

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [8000 1]; % resolution in x- and y-direction (for a 2D calculation the resolution in y-direction is set to 1)
gridSize = [2000 1]; % width of calculation area in x- and y-direction (for a 2D calculation the width in y-direction is set to 1)
lambda = 1.55; % wavelength in um
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [1000 1]; % width of beam waist in x- and y-direction (only first element is relevant)
inputOptions.Power = 1e-3; % use 1 mW of total input power
inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions); % create Gaussian beam

%% Optional parameters
options.Sections = 1:5; % use as propagation space the propagation sections in the order of 1 -> 2 -> 3 -> 4 -> 5
options.Step = 1; % step size in z-direction is 1 um
options.VectorType = 'semi'; % use the semi-vectorial BPM solver (default)
options.BoundaryX = 'pml2'; % use a 2nd order PML boundary in x-direction
options.BoundaryY = 'pml2'; % use a 2nd order PML boundary in y-direction
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SlicesXYScale = 'lininput'; % use a linear scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [0 2]; % use a range from 0 to 2 for all x-y plots
options.SlicesXZ = 0; % display the intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized with respect to the maximum intensity (default, but inserted here for clarity)
options.SlicesXZRange = 20; % use a range of 20 dB for the logarithmic scale
options.SlicesXZYZStep = 20; % to generate intensity distribution in the xz or yz plane use intensity samples taken at every 20 Steps
options.SlicesXZYZPlotXYStep = 9; % reduce the resolution in x-direction of the x-z plots by a factor of 9 (the original resolution is kept in bpmData).
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = 'Int1Dx0'; % monitor the 1D intensity distribution at x = 0
options.MonitorScale = 'lininput'; % use a linear scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [0 2]; % use a range from 0 to 2 for all monitor plots
options.IndexContour = 'slices'; % display index contours in slice plots
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
len = 200; % section length
index = 1; % refractive index

waveguide{1} = @(beamProblem) homogeneous(beamProblem,len,index); % homogeneous layer

%% Section 2
apertureWidth = [40 1]; % aperture width in x-direction is 40 um (only the first entry is relevant)

options.ApertureNumber = [3 1]; % create 3 slits in x-direction (only the first entry is relevant)
options.Period = [150 1]; % the center-to-center spacing of the slits in x-direction is 150 um
options.SmoothingWidth = 4; % smooth the aperture edges over a width of 4 pixels (i.e., 1 um) to avoid diffractive stray effects at large angles from the slit edges

waveguide{2} = @(beamProblem) thinaperture(beamProblem,apertureWidth,options); % aperture of zero thickness
clear options;

%% Section 3
len = 800; % section length
index = 1; % refractive index

options.Step = 0.2; % use finer Step size to calculate the diffracted field with higher precision

waveguide{3} = @(beamProblem) homogeneous(beamProblem,len,index,options); % homogeneous layer with smaller Step size to calculate diffractive effects near the aperture with higher precision

%% Section 4
len = 9000; % section length
index = 1; % refractive index

options.Step = 2; % use larger Step size in this section for faster calculation

waveguide{4} = @(beamProblem) homogeneous(beamProblem,len,index,options); % homogeneous layer with larger Step size

%% Section 5
len = 60000; % section length
index = 1; % refractive index

options.Step = 20; % use larger Step size in this section for faster calculation

waveguide{5} = @(beamProblem) homogeneous(beamProblem,len,index,options); % homogeneous layer with larger Step size

end
