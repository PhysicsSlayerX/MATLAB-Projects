function bpmData = quarterwave_plate
%QUARTERWAVE_PLATE - Propagation of a Gaussian beam with circular polarization through a quarter-wave plate.
%
%   This BeamLab demo shows a how the circular polarization state a 
%   Gaussian input beam propagated through a quarter-wave plate is 
%   transformed into a linear polarization state.
%
%   QUARTERWAVE_PLATE
%   bpmData = QUARTERWAVE_PLATE

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [100 100]; % resolution in x- and y-direction
gridSize = [100 100]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 0.6; % wavelength
indexFunction{1} = @(beamProblem) homogeneous(beamProblem,2,1,'SectionTitle','free space'); % homogeneous section
indexFunction{2} = @(beamProblem) homogeneous(beamProblem,10,1.5,'Anisotropy',[1 1.01 1],'SectionTitle','quarter-wave plate');
indexFunction{3} = @(beamProblem) homogeneous(beamProblem,2,1,'SectionTitle','free space'); % homogeneous section

%% Input field for bpmsolver
% Generate a circularly polarized Gaussian beam with a beam waist of 40 um
inputField = @(beamProblem) gaussinput(beamProblem,[40 40],'Polarization',[0 0 1]);

%% Optional parameters
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.Step = .025; % step size in z-direction (0.025 um)
options.Monitor = true; % monitor propagating field
options.MonitorStep = 1; % monitor every step
options.MonitorGraphType = 'Int2D'; % monitor the 2D intensity distribution
options.SlicesXY = Inf; % display x-y distributions of the last slice
options.Quiver = 'all'; % display quivers during monitor and in output slices
options.QuiverLength = 1.2; % increase the default length of the quiver arrows by 20%
options.QuiverColor = [0 0 0]; % use black quivers
options.Format = 1; % display the distance z with deicimal after the coma
options.ShowSectionTitles = true; % show section titles in monitor plots
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end
