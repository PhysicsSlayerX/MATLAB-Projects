function bpmData = spatial_filter
%SPATIAL_FILTER - Beam propagation through a spatial filter.
%
%   This BeamLab demo shows how a spatial filter consisting of a lens and
%   pinhole removes fluctuations in the intensity profile of a Gaussian
%   beam. An unperturbed Gaussian beam picks up phase fluctuations
%   by passing through a thin screen where small particles are distributed 
%   over a finite area approximately within the beam width and aberrate the
%   beam's wavefront. The beam is then focused by a (thin) lens and
%   spatially filtered at the lens' focal plane by a metal pinhole with a
%   diameter of 25 um and a thickness of 50 um. Finally, the filtered beam
%   is collimated by another (thin) lens.
%
%   SPATIAL_FILTER
%   bpmData = SPATIAL_FILTER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = 400*[1 1]; % resolution in x- and y-direction
gridSize = 200*[1 1]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength in um
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = 100*[1 1]; % width of beam waist in x- and y-direction
inputOptions.Power = 1e-3; % input power
inputOptions.Polarization = [1 0 0]; % use linear polarization in x-direction (default)

inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions);

%% Optional parameters
% General optional parameters
options.Sections = [2 11 2 12 3 1 21 22 1 3 12 2]; % use sections between 1 and 22 as propagation structure in the order of 2 -> 11 -> 2 -> 12 -> 3 -> 1 -> 21 -> 22 -> 1 -> 3 -> 12 -> 2
options.VectorType = 'semi'; % use a semi-vectorial mode- and bpmsolver (default)
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distribution
options.SlicesXY = [0 Inf]; % display the x-y distributions at z = O and of the last slice
options.SlicesXZ = 0; % display x-z slice intensity distribution at y = 0
options.SlicesXZRange = 40; % use a range of 40 dB for all x-z plots
options.FigureBackgroundColor = [1 1 1]; % use white as figure background color

% Optional parameters for bpmsolver
options.Step = 2; % set step size in z-direction to 2 um (the unit is defined by the parameter LengthUnit which is um by default)
options.Monitor = true; % monitor propagating field
options.MonitorStep = 10; % refresh the monitor every 10 Steps
options.MonitorGraphType = 'Int2D'; % display the 2D intensity distribution
options.IndexContour = 'all'; % display index contours in all monitor and slice plots
options.IndexContourValues = 1.01; % display contour lines where the refractive index is 1.01.
options.PowerTrace = 'continuous'; % trace power continuously
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScanner = true; % switch on the index scanner (i.e., waveguide monitor before an actual BPM or mode solver calculation)
options.IndexScannerStep = 25; % display the index distribution every 25 Steps
options.Index3D = false; % do not display the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

% similar waveguide sections can be grouped together as exemplified below for the groups 1-4, 11-12, and 21-22.

%% Section 1 - homogeneous
% thin homogeneous layer with a small step size to be placed near transition regions immediately in front and behind the pinhole
waveguide{1} = @(beamProblem) homogeneous(beamProblem,1,1,'Step',0.1,'IndexScannerStep',5);

%% Section 2 - homogeneous
waveguide{2} = @(beamProblem) homogeneous(beamProblem,100,1);

%% Section 3 - homogeneous
waveguide{3} = @(beamProblem) homogeneous(beamProblem,474,1);

%% Section 11 - thincustommedium
% create a customized medium of zero thickness acting as phase disturbance
rng('shuffle'); % seed the random number generator based on the current time
randomSeed = rng; % return the current settings of the random number generator
mediumFunction = @(x,y) phasedisturber(x,y,randomSeed); % function containing the two-dimensional phase distribution

waveguide{11} = @(beamProblem) thincustommedium(beamProblem,mediumFunction);

%% Section 12 - thinlens
waveguide{12} = @(beamProblem) thinlens(beamProblem,500);

%% Section 21 - pinhole (singlecore waveguide with air core and metal cladding)
% first pinhole layer where a small step size is used to properly simulate the abrupt transition from a non-absorbing to a strongly absorbing medium

index = 0.4 - 10i;

options.CoreShapeFactor = 2; % use a cicular core
options.Step = 0.1; % use a finer Step size (overrides the Step defined in beamset)
options.IndexScannerStep = 50; % use a larger index scanner step size (due to the finer Step size a larger IndexScannerStep value is required to improve the performance of the IndexScanner)
options.MonitorStep = 50; % refresh the monitor only every 50 Steps

waveguide{21} = @(beamProblem) singlecore(beamProblem,10,25*[1 1],1,index,options);

%% Section 22 - pinhole (singlecore waveguide with air core and metal cladding)
% second pinhole layer with the default step size

index = 0.4 - 10i;

options.CoreShapeFactor = 2;
options.Step = 2;
options.IndexScannerStep = 10;
options.MonitorStep = 10;

waveguide{22} = @(beamProblem) singlecore(beamProblem,40,25*[1 1],1,index,options);

end

%% Function defining phase disturbance
function output = phasedisturber(x,y,randomSeed) 

rng(randomSeed); % seed the random number generator using randomSeed
particleNumber = 10;
particleLocationMax = 50; % distribute particles within an area of 50 um x 50 um (note that the particles are randomly distributed only in the first quadrant due to the symmetry conditions)
particleLocation = particleLocationMax*[rand(1,particleNumber);rand(1,particleNumber)];
particleSize = 2 + 0.2*randn(1,particleNumber); % particles have random radii with an average of 2 um and a standard deviation of 0.2 um
particlePhase = pi/2 + pi/8*randn(1,particleNumber); % particles cause random phase shifts with an average of pi/2 and a standard deviation of pi/8

pha = zeros(size(x));
for k = 1:particleNumber
    pha(((x - particleLocation(1,k))/particleSize(k)).^2 + ((y - particleLocation(2,k))/particleSize(k)).^2 <= 1) = particlePhase(k);
end
output = exp(1i*pha);

end
