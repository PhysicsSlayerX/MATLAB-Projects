function bpmData = freespace_grating_2d
%FREESPACE_GRATING_2D - Propagation of Gaussian beam through a sinusoidal grating.
%
%   This BeamLab demo shows a 2D Gaussian beam in free space normally
%   incident on a custom (sinusoidal) grating.
%
%   FREESPACE_GRATING_2D
%   bpmData = FREESPACE_GRATING_2D

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [16000 1]; % resolution in x- and y-direction (for a 2D calculation the resolution in y-direction is set to 1)
gridSize = [4000 1]; % width of calculation area in x- and y-direction (for a 2D calculation the width in y-direction is set to 1)
lambda = 1.55; % wavelength in um
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [1000 1]; % width of beam waist in x- and y-direction (only first element is relevant)
inputOptions.Power = 1e-3; % use 1 mW of total input power
inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions); % Gaussian beam 

%% Optional parameters
options.Sections = 1:4; % use sections 1 to 4 as propagation structure (1 -> 2 -> 3 -> 4)
options.Step = 2; % set step size in z-direction to 2 um
options.VectorType = 'semi'; % use the semi-vectorial BPM solver (default)
options.BoundaryX = 'pml2'; % use a 2nd order PML boundary in x-direction
options.BoundaryY = 'pml2'; % use a 2nd order PML boundary in y-direction
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 5]; % use a range from -20 to 5 dB for all x-y plots
options.SlicesXZ = 0; % display the intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized with respect to the maximum intensity (default, but inserted here for clarity)
options.SlicesXZYZStep = 10; % for the x-z plot take intensity samples every 10 Steps
options.SlicesXZYZPlotXYStep = 9; % reduce the resolution in x-direction of the x-z plot by a factor of 9 (for display purposes only, bpmData will contain the original resolution).
options.Monitor = true; % monitor propagating field
options.MonitorStep = 20; % refresh the monitor every 20 Steps
options.MonitorGraphType = 'Int1Dx0'; % monitor the 1D intensity distribution at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to maximum input intensity for all monitor plots
options.MonitorRange = [-20 5]; % use a range from -20 to 5 dB for all montor plots
options.IndexContour = 'slices'; % display index contours in slice plots
options.Format = 1; % display distance z with 1 digit after the decimal point
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
len = 1000; % section length
index = 1; % refractive index

options.Step = 5; % use larger Step size in this section for faster calculation

waveguide{1} = @(beamProblem) homogeneous(beamProblem,len,index,options); % create homogeneous section

%% Section 2
mediumFunction = @(x,y) my_grating(x); % define a one-dimensional function in x

waveguide{2} = @(beamProblem) thincustommedium(beamProblem,mediumFunction); % create a customized thin medium with zero thickness

%% Section 3
len = 1000; % section length
index = 1; % refractive index (free space)

waveguide{3} = @(beamProblem) homogeneous(beamProblem,len,index); % create homogeneous section

%% Section 4
len = 30000; % section length
index = 1; % refractive index (free space)

options.Step = 10; % use larger Step size in this section for faster calculation

waveguide{4} = @(beamProblem) homogeneous(beamProblem,len,index,options); % create homogeneous section

end

%% Function defining the phase distribution of a sinusoidal grating
function output = my_grating(x) 

gratingPeriod = 40;
pha = 8*pi/18*cos(2*pi*x/gratingPeriod); % use cos function to make the grating symmetric in x-direction
output = exp(1i*pha); % prepare output matrix

end
