function bpmData = freespace_deflection
%FREESPACE_DEFLECTION - Deflection of a Gaussian beam by several ideal prisms.
%
%   This BeamLab function is a BPM demo showing a Gaussian beam in free
%   space that is deflected such that its field/intensity distribution in 
%   the x-y plane looks as if it moves from the center to one corner of a 
%   equilateral triangle, then along the outline of that triangle and
%   finally back to the center, where the beam is set back to its original
%   orientation, i.e., parallel to the z-axis.
%
%   The deflectionAngle parameter for each prism is found by subtracting
%   the deflection vector of the input beam from the deflection vector of
%   the output beam with a desired new orientation. The length and
%   orientation of each deflection vector is given by the beam's deflection
%   angle from the z-axis and azimuth angle of the deflection plane, e.g.,
%   [5 -30] stands for a deflection vector of length 5 and orientation of
%   -30 deg in the x-y plane, similar to the polar coordinates, i.e.,
%   length 5 and angle of -30 deg. For example, if the input beam is
%   deflected in the x-z plane with an angle of 5 deg from the z-axis, its
%   deflection vector is given by [5 0]. To generate an output beam of the
%   prism that is deflected in the y-z plane at an angle of 2 deg from the
%   z-axis, i.e., a beam with a deflection vector of [2 90], the prism's
%   deflectionAngle parameter is found by subtracting the vector [5 0] from
%   the vector [2 90] resulting in [sqrt(5^2 + 2^2) atan2d(2,-5)].
%
%   Finally, also note that in this demo the phase is displayed only in an
%   area where the intensity is higher than 1/100th of the peak intensity.
%
%   FREESPACE_DEFLECTION
%   bpmData = FREESPACE_DEFLECTION

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

len0 = 265;
triangleCorners = [
    30+len0/sqrt(3) ... % z-coordinate of first triangle corner
    30+len0/sqrt(3)+len0 ... % z-coordinate of second triangle corner
    30+len0/sqrt(3)+2*len0]; % z-coordinate of third triangle corner

%% Required parameters
gridPoints = [280 280]; % resolution in x- and y-direction
gridSize = [140 140]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct(len0); % define propagation structure

%% Input field for bpmsolver
width = [50 50]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputField = @(beamProblem) gaussinput(beamProblem,width); % create Gaussian beam

%% Optional parameters
% General optional parameters
options.Sections = 1:13; % use as propagation structure all sections
options.VectorType = 'semi'; % use the semi-vectorial BPM solver

% Optional parameters for bpmsolver
options.Step = 3; % set step size in z-direction to 3 LengthUnits
options.Monitor = true; % monitor propagating field
options.MonitorStep = 10; % refresh the monitor every 10 Steps
options.MonitorGraphType = {'Int2D','Phase(Ex)2D'}; % monitor the intensity distribution and phase of the propagating field
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = 20; % display intensity over a range of 20 dB in all monitor plots
options.SlicesXY = [triangleCorners Inf]; % display the x-y distributions at the z-coordinates of all three triangle corners and at the end of the propagation structure
options.SlicesXYGraphType = {'Int2D','Phase(Ex)2D'}; % display the 2D intensity and phase distributions of the propagating field
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = 20; % display intensity over a range of 20 dB in all x-y plots
options.Format = 2; % display distance z with 2 digits after the decimal point (default)
options.PhaseDisplayThreshold = 1e-2; % display phase within the area where intensity is higher that 1/100 of the peak intensity (adapted to SlicesXYRange)
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.Index3D = false; % do not generate 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct(len0)

%% Section 1
waveguide{1} = @(beamProblem) homogeneous(beamProblem,30,1); % create homogeneous section

%% Section 2
deflectionAngle = [5 -30]; % deflect the input beam such that the output beam is deflected by 5 deg at an azimuth angle of -30 deg
waveguide{2} = @(beamProblem) thinprism(beamProblem,deflectionAngle); % create prism of zero thickness

%% Section 3
waveguide{3} = @(beamProblem) homogeneous(beamProblem,len0/sqrt(3),1); % create homogeneous section

%% Section 4
deflectionAngle = [2*5*cos(15*pi/180) 165]; % deflect the input beam such that the output beam is deflected by 5 deg at an azimuth angle of 180 deg
waveguide{4} = @(beamProblem) thinprism(beamProblem,deflectionAngle); % create prism of zero thickness

%% Section 5
waveguide{5} = @(beamProblem) homogeneous(beamProblem,len0,1); % create homogeneous section

%% Section 6
deflectionAngle = [2*5*cos(30*pi/180) 30]; % deflect the input beam such that the output beam is deflected by 5 deg at an azimuth angle of 60 deg
waveguide{6} = @(beamProblem) thinprism(beamProblem,deflectionAngle); % create prism of zero thickness

%% Section 7
waveguide{7} = @(beamProblem) homogeneous(beamProblem,len0,1); % create homogeneous section

%% Section 8
deflectionAngle = [2*5*cos(30*pi/180) -90]; % deflect the input beam such that the output beam is deflected by 5 deg at an azimuth angle of -60 deg
waveguide{8} = @(beamProblem) thinprism(beamProblem,deflectionAngle); % create prism of zero thickness

%% Section 9
waveguide{9} = @(beamProblem) homogeneous(beamProblem,len0,1); % create homogeneous section

%% Section 10
deflectionAngle = [2*5*cos(15*pi/180) 135]; % deflect the input beam such that the output beam is deflected by 5 deg at an azimuth angle of 150 deg
waveguide{10} = @(beamProblem) thinprism(beamProblem,deflectionAngle); % create prism of zero thickness

%% Section 11
waveguide{11} = @(beamProblem) homogeneous(beamProblem,len0/sqrt(3),1); % create homogeneous section

%% Section 12
deflectionAngle = [5 -30]; % deflect the input beam such that the output beam is deflected by 0 deg at an azimuth angle of 0 deg
waveguide{12} = @(beamProblem) thinprism(beamProblem,deflectionAngle); % create prism of zero thickness

%% Section 13
waveguide{13} = @(beamProblem) homogeneous(beamProblem,30,1); % create homogeneous section

end
