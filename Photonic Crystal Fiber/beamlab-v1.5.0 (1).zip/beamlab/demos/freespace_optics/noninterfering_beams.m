function bpmData = noninterfering_beams
%NONINTERFERING_BEAMS - Propagation of two orthogonally polarized Gaussian beams in free space.
%
%   This BeamLab demo the behavior of two orthogonally polarized Gaussian 
%   beams when they cross each other.
%
%   NONINTERFERING_BEAMS
%   bpmData = NONINTERFERING_BEAMS

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [130 100]; % resolution in x- and y-direction
gridSize = [130 100]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.064; % wavelength
indexFunction = @(beamProblem) homogeneous(beamProblem,900,1); % homogeneous free-space section with a length of 900 um

%% Input field for bpmsolver
% Generate a clockwise and counterclockwise circularly polarized Gaussian
% beam, each with a beam waist of 30 um and shifted in x-direction by 30 um
% in opposite directions
inputField{1} = @(beamProblem) gaussinput(beamProblem,[30 30],'Shift',[ 30 0 0],'Angle',[-5 0],'Polarization',[0 0 1]);
inputField{2} = @(beamProblem) gaussinput(beamProblem,[30 30],'Shift',[-30 0 0],'Angle',[ 5 0],'Polarization',[0 0 -1]);

%% Optional parameters
options.Step = 1.1; % step size in z-direction (1.1 um)
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit)
options.Monitor = true; % monitor propagating field
options.MonitorStep = 2; % monitor every step
options.MonitorGraphType = 'Int2D'; % monitor the 2D intensity distribution
options.Quiver = 'monitor'; % display quivers during monitor
options.QuiverLength = 2; % set quiver length to 2 times the default length
options.QuiverPeriod = 10; % display quivers every 10 pixels
options.QuiverColor = [0 0 0]; % use black quivers
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end
