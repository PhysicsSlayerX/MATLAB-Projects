function bpmData = freespace_vortex
%FREESPACE_VORTEX - Transformation of a Gaussian beam to a helically phased beam and back to a Gaussian beam.
%
%   This BeamLab function is a BPM demo showing a Gaussian beam transformed
%   to a helically phased beam of order 1 and back to a Gaussian beam.
%
%   FREESPACE_VORTEX
%   bpmData = FREESPACE_VORTEX

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [300 300]; % resolution in x- and y-direction
gridSize = [150 150]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 0.633; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [40 40]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputOptions.Power = 1e-3; % set input power to 1 mW

inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions); % Gaussian beam

%% Optional parameters
options.Sections = 1:5; % use sections 1 to 5 as propagation structure
options.Step = 5; % set step size in z-direction (unit is defined by optional parameter LengthUnit)
options.VectorType = 'semi'; % use the semi-vectorial BPM solver
options.BoundaryX = 'pml1'; % use a 1st order PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a 1st order PML boundary in y-direction
options.SlicesXY = [250 700]; % display the x-y distributions at z = 250 and 700 um and save it in bpmData
options.SlicesXYScale = 'linear'; % use a (non-normalized) linear scale for all x-y plots
options.SlicesXZ = 0; % display the intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized with respect to the maximum intensity for all x-z plots
options.Monitor = true; % monitor propagating field
options.MonitorStep = 10; % refresh the monitor every 10 Steps
options.MonitorGraphType = {'Int2D','Phase(Ex)2D','Int1Dx','Phase(Ex)1Dx'}; % monitor the intensity and phase distribution of the propagating field both as a 2D plot and 1D graph of the cross-section 
options.MonitorScale = 'linear'; % use a (non-normalized) linear scale for all monitor plots
options.DisplaySize = [100 100]; % display all output distributions within an x-y area of 100 um x 100 um (unit is defined by optional parameter LengthUnit)
options.Output = true; % save the output data of the BPM calculation in a file
options.OutputFilename = 'freespace_vortex_output'; % name of the file to which all input and output parameters are saved to
options.IndexContour = 'slices'; % display index contours in slice plots
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
len = 100; % section length
index = 1; % refractive index

waveguide{1} = @(beamProblem) homogeneous(beamProblem,len,index); % create homogeneous section

%% Section 2
order = 1; % order of helix

waveguide{2} = @(beamProblem) thinhelix(beamProblem,order); % helical phase plate of zero thickness

%% Section 3
len = 300; % section length
index = 1; % refractive index

options.Step = 2; % use smaller step size for better resolution of diffraction effects behind the thinhelix phase modulation

waveguide{3} = @(beamProblem) homogeneous(beamProblem,len,index,options); % create homogeneous section
clear options;

%% Section 4
order = -1;

waveguide{4} = @(beamProblem) thinhelix(beamProblem,order); % helical phase plate of zero thickness

%% Section 5
len = 2000; % section length
index = 1; % refractive index

waveguide{5} = @(beamProblem) homogeneous(beamProblem,len,index); % create homogeneous section

end
