function bpmData = three_beam_interference
%THREE_BEAM_INTERFERENCE - Propagation of three Gaussian beams in free space.
%
%   This BeamLab demo shows how to define multiple input fields (three
%   Gaussian beams with different Shift and Angle values), which are
%   propagating simultaneously in free space.
%
%   THREE_BEAM_INTERFERENCE
%   bpmData = THREE_BEAM_INTERFERENCE

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [360 360]; % resolution in x- and y-direction
gridSize = [90 90]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.064; % wavelength
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [15 15]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputField{1} = @(beamProblem) gaussinput(beamProblem,width,'Shift',20*[0 1 0],'Angle',[-15 90]); % create Gaussian beam 1
inputField{2} = @(beamProblem) gaussinput(beamProblem,width,'Shift',20*[cosd(30) -sind(30) 0],'Angle',[15 150]); % create Gaussian beam 2
inputField{3} = @(beamProblem) gaussinput(beamProblem,width,'Shift',20*[-cosd(30) -sind(30) 0],'Angle',[15 30]); % create Gaussian beam 3

%% Optional parameters
options.Step = 1; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.Monitor = true; % monitor propagating field
options.MonitorGraphType = {'Int2D','Phase(Ex)2D'}; % monitor the intensity distribution and phase of the x-component of the propagating field
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SlicesXY = [0 75 Inf]; % display the x-y slice distribution at z = 0, z = 75 um, and at the end of the propagation structure
options.SlicesXYGraphType = {'Int2D','Phase(Ex)2D'}; % display the intensity distribution and phase of the x-component of the propagating field
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit)
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize input field
inputplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

len = 150; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide = @(beamProblem) homogeneous(beamProblem,len,index); % homogeneous section

end
