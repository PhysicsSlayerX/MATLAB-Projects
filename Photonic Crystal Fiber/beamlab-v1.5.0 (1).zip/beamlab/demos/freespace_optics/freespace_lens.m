function bpmData = freespace_lens
%FREESPACE_LENS - Collimation of a Gaussian beam by an ideal lens.
%
%   This BeamLab function is a BPM demo showing a diverging Gaussian beam
%   in free space that is collimated by an ideal lens.
%
%   FREESPACE_LENS
%   bpmData = FREESPACE_LENS

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [300 300]; % resolution in x- and y-direction
gridSize = [300 300]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.064; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [30 30]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputOptions.Power = 1e-3; % set input power to 1 mW 
inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions); % create Gaussian beam

%% Optional parameters
options.Sections = [1 2 1]; % use as propagation structure the sections in the order of 1 -> 2 -> 1
options.Step = 5; % set step size in z-direction to 5 LengthUnits
options.VectorType = 'semi'; % use the semi-vectorial BPM solver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.SlicesXY = [1000 3000]; % display the x-y distribution at z = 1000 and 3000 um and save it in bpmData
options.SlicesXYGraphType = 'Int2D'; % display the intensity distribution (default)
options.SlicesXYScale = 'linear'; % use a (non-normalized) linear scale of all x-y plots
options.SlicesXZ = 0; % display the intensity distribution at y = 0 and save it in bpmData
options.Monitor = true; % monitor propagating field
options.MonitorStep = 20; % refresh the monitor every 20 Steps
options.MonitorGraphType = {'Int2D','Phase(Ex)2D'}; % monitor the intensity distribution and phase of the propagating field
options.MonitorScale = 'linear'; % use a (non-normalized) linear scale  for all monitor plots
options.IndexContour = 'slices'; % display index contours in slice plots
options.Format = 1; % display distance z with 1 digit after the decimal point
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

%% Create an additional plot displaying only the contour lines
bpmplot(bpmData,'IntensityContour','slices','IntensityContourOnly',true,'IndexContourLineColor',[0 0 0]);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
len = 2500; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide{1} = @(beamProblem) homogeneous(beamProblem,len,index); % create homogeneous section

%% Section 2
focalLength = 2500; % focal length (unit is defined by optional parameter LengthUnit)

waveguide{2} = @(beamProblem) thinlens(beamProblem,focalLength); % create lens of zero thickness

end
