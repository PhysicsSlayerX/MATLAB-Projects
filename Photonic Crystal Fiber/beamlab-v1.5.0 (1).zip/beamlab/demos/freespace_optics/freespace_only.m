function bpmData = freespace_only
%FREESPACE_ONLY - Propagation of a Gaussian beam in free space.
%
%   This BeamLab demo shows a Gaussian beam propagating in free space.
%
%   FREESPACE_ONLY
%   bpmData = FREESPACE_ONLY

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [100 100]; % resolution in x- and y-direction
gridSize = [100 100]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.064; % wavelength
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [20 20]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputField = @(beamProblem) gaussinput(beamProblem,width); % create Gaussian beam

%% Optional parameters
options.Step = 5; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit)
options.Monitor = true; % monitor propagating field
options.SymmetryX = true;
options.SymmetryY = true;
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

len = 1000; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide = @(beamProblem) homogeneous(beamProblem,len,index); % homogeneous section

end
