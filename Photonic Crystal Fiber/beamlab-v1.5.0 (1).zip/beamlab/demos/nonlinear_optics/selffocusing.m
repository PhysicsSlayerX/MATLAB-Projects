function bpmData = selffocusing
%SELFFOCUSING - Propagation of a high-power Gaussian beam undergoing self-focusing in a nonlinear medium.
%
%   This BeamLab demo shows a high-power Gaussian beam incident on a block
%   of fused silica where it then converges to a small spot due to the
%   self-focusing effect by taking into account the nonlinear change of the
%   intensity-dependent refractive index.
%
%   SELFFOCUSING
%   bpmData = SELFFOCUSING

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [300 300]; % resolution in x- and y-direction
gridSize = [150 150]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.064; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [70 70]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputOptions.Power = 6.5e6; % unit is W; to observe the self-focusing effect the power needs to be higher than 3.9e6 W for the given nonlinear refractive index (see below)
inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions); % create Gaussian beam

%% Optional parameters
% General optional parameters
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis

% Optional parameters for bpmsolver
options.Step = 2; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.MonitorGraphType = {'Int2D','Index1Dx'}; % display the 2D intensity distribution and 1D index distribution in all monitor plots
options.MonitorScale = 'linear'; % use a linear scale for all monitor plots
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit) in all x-z plots
options.SlicesXZScale = 'logmax'; % use a logarithmic scale for the x-z slice plots
options.SlicesXZRange = 40; % use a range of 40 dB for all x-z plots
options.Monitor = true; % monitor propagating field
options.IndexContour = 'slices'; % display contour lines only in all output slice plots
options.IndexContourValues = 1.23; % display the contour line where the index is 1.23
options.MonitorStep = 25; % refresh the monitor every 25 Steps
options.Format = 2; % display distance z with 2 digits after the decimal point
options.NonlinearIterations = 1; % increase the calculation precision of the intensity dependent refractive index by iterating the field calculation once per Step (default)
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
options.Step = 10; % use a larger Step size in areas where the field distribution is not changing much to improve performance
waveguide{1} = @(beamProblem) homogeneous(beamProblem,500,1,options); % homogeneous section

%% Section
len = 5000; % section length (unit is defined by optional parameter LengthUnit which is um by default)
index = [1.46 3e-20]; % refractive index (the first element represents the linear refractive index and the second term the nonlinear refractive index)

waveguide{2} = @(beamProblem) homogeneous(beamProblem,len,index); % homogeneous section

end
