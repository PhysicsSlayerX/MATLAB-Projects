function bpmData = mach_zehnder_modulator(switchedOn)
%MACH_ZEHNDER_MODULATOR - Beam propagation in a Mach-Zehnder modulator.
%
%   This BeamLab demo shows the beam propagation through a Mach-Zehnder
%   waveguide modulator (MZM) while a pi phase shift is applied through a
%   refractive index change to one of its arms. If the input parameter
%   switchedOn is true the MZM throughput is maximum. If the input
%   parameter switchedOn is false the MZM throughput is minimum.
%
%   MACH_ZEHNDER_MODULATOR
%   MACH_ZEHNDER_MODULATOR(switchedOn)
%   bpmData = MACH_ZEHNDER_MODULATOR(___)

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

if nargin < 1
    switchedOn = false;
end

if switchedOn
    fprintf('\nThe Mach-Zehner Modulator is switched to maximum throughput. \nUse mach_zehnder_modulator(false) to switch to minimum throughput.\n\n');
else
    fprintf('\nThe Mach-Zehner Modulator is switched to minimum throughput. \nUse mach_zehnder_modulator(true) to switch to maximum throughput.\n\n');
end

%% Required parameters
gridPoints = [320 120]; % resolution in x- and y-direction
gridSize = [80 30]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_waveguide(switchedOn); % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.Sections = 1:7; % use sections 1 to 7 as propagation structure
options.VectorType = 'semi'; % use a semi-vectorial mode or BPM solver
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.BoundaryX = 'pml1'; % use a 1st order PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a 1st order PML boundary in y-direction
options.IndexContour = 'all'; % display index contours in all plots

% Optional parameters for bpmsolver
options.Step = 2; % step size in z-direction (2 um)
options.Monitor = true; % monitor propagating field
options.MonitorStep = 10; % refresh the monitor every 10 Steps
options.MonitorGraphType = {'Index2D','Int2D','Index1Dx0','Int1Dx0'}; % display the 2D index/intensity distribution and the 1D index/intensity distributions at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.SlicesXY = [1200 1800 3400]; % display the x-y distributions at z = 1900 and 2900 um
options.SlicesXYGraphType = {'Int2D','Phase(Ex)2D','Int1Dx0','Phase(Ex)1Dx0'}; % display the intensity/phase distribution and the 1D intensity/phase distributions at x = 0
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXZ = 0; % display x-z slice intensity distribution at y = 0
options.SlicesXZGraphType = {'Int2D','Index2D'};
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.SlicesXZYZStep = 2; % for the x-z distribution take intensity samples every 2 Steps
options.PowerTrace = 'continuous'; % continuously trace the power
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.LineWidth = 1; % use a line width of 1 for graphs
options.Output = true; % save output data to a mat file
options.OutputFilename = 'mach_zehnder_modulator_output'; % name of the file to which all input and output parameters are saved to
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScanner = false; % do not scan the index distribution (i.e., generate only 3D index contour)
options.Index3DStep = 10; % take index samples every 10 Steps for the 3D index contour
options.IndexRange = [1.45 1.455+1.55e-3]; % set index range to fixed values

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide(switchedOn)

%% Waveguide parameters common to all sections
coreWidthBase = [7 7]; % maximum core extensions in x- and y-direction
coreIndex = 1.455; % core index
claddingIndex = 1.45; % cladding index

options.CoreShapeFactor = 4; % core shape factor of all cores (square with round corners)
options.PowerAreaSize = coreWidthBase; % define integration area for power evaluation
options.PowerCenter = 'core'; % define center of integration area for power evaluation (default)

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 100; % section length
coreNumber = 1; % number of cores
coreWidth = coreWidthBase; % width of core 1

options.Shift = [0 0]; % lateral shift of core 1
options.Step = 5; % use larger step size for straight waveguide sections to improve calculation speed

waveguide{1} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 2
len = 1000; % section length
coreNumber = 2; % number of cores
coreWidth = coreWidthBase; % width of core 1 & 2

options.Shift{1} = [0 0]; % lateral shift of core 1 at section begin
options.Shift{2} = [0 0]; % lateral shift of core 2 at section begin
options.ShiftEnd{1} = [20 0]; % lateral shift of core 1 at section end
options.ShiftEnd{2} = [-20 0]; % lateral shift of core 2 at section end
options.Index3DStep = 5; % override corresponding beamProblem option and take index samples every 5 Steps for generating the 3D index contour of this section (finer resolution due to core bend)

waveguide{2} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 150;
coreNumber = 2;
coreWidth = coreWidthBase;

options.Shift{1} = [20 0];
options.Shift{2} = [-20 0];

waveguide{3} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 4
len = 500;
coreNumber = 2;
if switchedOn
    coreWidth = coreWidthBase; % maximum extensions for core 1 & 2
else
    coreWidth{1} = coreWidthBase; % maximum extensions for core 1
    coreWidth{2} = [30 30]; % maximum extensions for core 2
end

options.Shift{1} = [20 0];
options.Shift{2} = [-20 0];

options.CoreType{1} = 'predefined'; % core type of core 1
if switchedOn
    options.CoreType{2} = 'predefined'; % core type of core 2
else
    options.CoreType{2} = 'custom2D'; % core type of core 2
end
options.CoreFunction{1} = []; % core function of core 1 (not defined since core type is predefined. However this setting is needed to maintain the same cell array size as CoreType)
if switchedOn
    options.CoreFunction{2} = []; % core function of core 2 (not defined since core type is predefined. However this setting is needed to maintain the same cell array size as CoreType)
else
    options.CoreFunction{2} = @(x,y) my_core_function(x,y,coreWidthBase,coreIndex,claddingIndex); % user-defined core function of core 2 to emulate the change in refractive index inside and around the core due to an externally applied electric field
end
options.Step = 5;

waveguide{4} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 5
len = 150;
coreNumber = 2;
coreWidth = coreWidthBase;

options.Shift{1} = [20 0];
options.Shift{2} = [-20 0];

waveguide{5} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 6
len = 1000;
coreNumber = 2;
coreWidth = coreWidthBase;

options.Shift{1} = [20 0];
options.Shift{2} = [-20 0];
options.ShiftEnd{1} = [0 0];
options.ShiftEnd{2} = [0 0];
options.Index3DStep = 5;

waveguide{6} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 7
len = 800;
coreNumber = 1;
coreWidth = coreWidthBase;

options.Shift = [0 0];
options.CoreShapeFactor = 4;
options.Step = 5;
options.Index3DStep = 10;

waveguide{7} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);

end

%% For reference purposes, the most compact way of defining the same propagation structure is given below

% function waveguide = get_waveguide(switchedOn)
% 
% waveguide{1} = @(beamProblem) plc(beamProblem, 200,1,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',        [  0 0],'Step',5,'PowerAreaSize',[7 7]);
% waveguide{2} = @(beamProblem) plc(beamProblem,1000,2,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',{[ 0 0],[  0 0]},'ShiftEnd',{[20 0],[-20 0]},'Index3DStep',5,'PowerAreaSize',[7 7]);
% waveguide{3} = @(beamProblem) plc(beamProblem, 100,2,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',{[20 0],[-20 0]},'PowerAreaSize',[7 7]);
% if switchedOn
%     waveguide{4} = @(beamProblem) plc(beamProblem,500,2,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',{[20 0],[-20 0]},'Step',5,'PowerAreaSize',[7 7]);
% else
%     waveguide{4} = @(beamProblem) plc(beamProblem,500,2,{[7 7],[28 42]},1.455,1.45,'CoreType',{'predefined','custom2D'},'CoreShapeFactor',4,'Shift',{[20 0],[-20 0]},'CoreFunction',{[],@(x,y) my_core_function(x,y,[7 7],1.455,1.45)},'Step',5,'PowerAreaSize',[7 7]);
% end
% waveguide{5} = @(beamProblem) plc(beamProblem, 100,2,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',{[20 0],[-20 0]},'PowerAreaSize',[7 7]);
% waveguide{6} = @(beamProblem) plc(beamProblem,1000,2,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',{[20 0],[-20 0]},'ShiftEnd',{[0 0],[0 0]},'Index3DStep',5,'PowerAreaSize',[7 7]);
% waveguide{7} = @(beamProblem) plc(beamProblem, 800,1,[7 7],1.455,1.45,'CoreShapeFactor',4,'Shift',        [  0 0],'Step',5,'Index3DStep',50,'PowerAreaSize',[7 7]);
% 
% end

%% Custom core function generating custom index distribution
function nmat = my_core_function(x,y,width,coreIndexBase,claddingIndexBase)

nmat = claddingIndexBase*ones(size(x));

indexDelta = 1.55e-3; % define necessary index difference to produce phase shift of pi over section length

% Generate index modulated inner cladding of rectangular shape 4 times wider and 6 times higher than core
innerCladdingWidth = [4 6].*width;
nmat(abs(x/(innerCladdingWidth(1)/2)).^Inf + abs(y/(innerCladdingWidth(2)/2)).^Inf < 1) = claddingIndexBase + indexDelta;

% Generate index modulated core within inner cladding
nmat(abs(x/(width(1)/2)).^4 + abs(y/(width(2)/2)).^4 < 1) = coreIndexBase + indexDelta;

end
