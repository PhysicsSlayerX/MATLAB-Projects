function bpmData = rib_splitter
%RIB_SPLITTER - Beam propagation in a polymer rib waveguide splitter.
%
%   This BeamLab demo shows the beam propagation through a 1 to 4 beam
%   splitter implemented as rib waveguide. The substrate of the polymer
%   waveguide consists of a polymethylmethacrylate (PMMA) foil, suitable
%   for hot-embossing of waveguide structures. A co-monomer composition,
%   which can be applied via spin-coating and a subsequent UV
%   polymerization step, is used as core layer [1]. The LP01 mode of the
%   single-mode waveguide is calculated and used as input for the BPM
%   simulation. During the beam propagation, the LP01 mode of the
%   single-mode waveguide is adiabatically split two times to form 4 output
%   beams each down in power by about 6dB compared to the input.
%
%   RIB_SPLITTER
%   bpmData = RIB_SPLITTER
%
%   References:
%
%   [1] Y. Xiao et al., "Temperature characterization of integrated optical
%   all-polymer Mach-Zehnder interferometers," Proc. SPIE 9888,
%   Micro-Optics 2016, 98880F, 2016.

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [40 10]*8; % resolution in x- and y-direction
gridSize = [40 10]; % width of calculation area in x- and y-direction
lambda = 0.852; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.VectorType = 'semi'; % use a semi-vectorial mode- and bpmsolver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.BoundaryX = 'pml1'; % use a 1st order PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a 1st order PML boundary in y-direction
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXYStacked = 5; % display 5 x-y distributions equidistantly spaced between z = 0 and waveguide end as stacked plots in a single figure
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = 1.5070; % generate index contour at specified index value

% Optional parameters for bpmsolver
options.Sections = 1; % use section 1 as propagation structure for the BPM calculation
options.Step = 5; % set step size in z-direction to 5 um
options.Monitor = true; % monitor propagating field
options.MonitorStep = 10; % refresh the monitor every 10 Steps, i.e., every 50 um
options.MonitorGraphType = 'Int2D'; % monitor the 3D intensity distribution and 1D intensity distribution at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.SlicesXZ = 0; % display x-z slice distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.PowerTrace = 'continuous'; % trace power continuously
options.PowerTraceScale = 'loginput'; % use a logarithmic scale normalized to the input power for displaying the power along the splitter
options.PowerTraceStep = 2; % take power samples every 2 Steps
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 10; % display the index distribution every 10 Steps
options.Index3DStep = 2; % take index samples every 2 Steps for the 3D index contour
options.Index3DValues = [1.5070 1.2650]; % display the index contours of core-substrate and core-cladding interfaces

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

len = 2250;
coreNumber = 4; % number of cores
coreWidth = [3.5 1]; % maximum core extensions in x- and y-direction
coreIndex = 1.53; % refractive index of core
claddingIndex = 1; % refractive index of cladding
substrateWidth{1} = [Inf 2]; % extension of substrate 1 in x- and y-direction
substrateWidth{2} = [Inf coreWidth(2)/2+5]; % extension of substrate 2 in x- and y-direction
substrateCenter{1} = [0 coreWidth(2)/2+substrateWidth{1}(2)/2]; % coordinates of the center of substrate 1
substrateCenter{2} = [0 coreWidth(2)/2-substrateWidth{2}(2)/2]; % coordinates of the center of substrate 2
substrateIndex{1} = 1.53; % refractive index of substrate 1
substrateIndex{2} = getmaterial('PMMA'); % refractive index of substrate 2

options.PowerAreaSize = 2*coreWidth; % define integration area for power evaluation
options.PowerAreaType = 'rectangular'; % use a rectangular area with twice the core diameter surrounding the core for power evaluation
options.PowerCenter = 'core'; % define center of integration area for power evaluation
options.ShiftTransition = 'custom'; % use custom shift functions

points = [...
    0 0 0;...
    0 0 250;...
    10 0 1000;...
    10 0 1250;...
    15 0 2000;...
    15 0 2250];
options.ShiftFunction{1} = @(z) pchippath(z,points);

points = [...
    0 0 0;...
    0 0 250;...
    10 0 1000;...
    10 0 1250;...
    5 0 2000;...
    5 0 2250];
options.ShiftFunction{2} = @(z) pchippath(z,points);

points = [...
    0 0 0;...
    0 0 250;...
    -10 0 1000;...
    -10 0 1250;...
    -5 0 2000;...
    -5 0 2250];
options.ShiftFunction{3} = @(z) pchippath(z,points);

points = [...
    0 0 0;...
    0 0 250;...
    -10 0 1000;...
    -10 0 1250;...
    -15 0 2000;...
    -15 0 2250];
options.ShiftFunction{4} = @(z) pchippath(z,points);

waveguide = @(beamProblem) rib(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,substrateWidth,substrateCenter,substrateIndex,options);

end
