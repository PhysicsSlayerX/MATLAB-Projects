function bpmData = rgb_beam_combiner(color)
%RGB_BEAM_COMBINER - Beam propagation in an integrated silica RGB beam combiner.
%
%   This BeamLab function simulates the beam propagation in an integrated
%   silica RGB beam combiner [1]. The waveguide structure has three input
%   channels - one each for red, green, and blue. By using three
%   directional couplers, the light from the three input channels is
%   combined into a single output channel. The optional parameter color,
%   which can either be 'red' (default), 'green', or 'blue', controls which
%   input channel is used for the simulation. The LP01 mode of the
%   respective single-mode input channel waveguide is calculated and used
%   as input for the BPM simulation.
%
%   RGB_BEAM_COMBINER
%   RGB_BEAM_COMBINER(color)
%   bpmData = RGB_BEAM_COMBINER(___)
%
%   References:
%
%   [1] A. Nakao et al., "Integrated waveguide-type red-green-blue beam
%   combiners for compact projection-type displays," Optics Communications,
%   vol. 330, pp. 45-48, 2014.

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

if nargin < 1
    color = 'red';
end

switch lower(color)
    case 'red'
        inputOptions.ModeCore = 1; % use waveguide core 1 for the eigenmode calculation
        lambda = 0.637; % wavelength
    case 'green'
        inputOptions.ModeCore = 2; % use waveguide core 2 for the eigenmode calculation
        lambda = 0.534; % wavelength
    case 'blue'
        inputOptions.ModeCore = 3; % use waveguide core 3 for the eigenmode calculation
        lambda = 0.471; % wavelength
end

%% Required parameters
gridPoints = [70 10]*8; % resolution in x- and y-direction
gridSize = [70 10]; % width of calculation area in x- and y-direction
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.VectorType = 'semi'; % use a semi-vectorial mode- and bpmsolver
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.BoundaryX = 'pml1'; % use a 1st order PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a 1st order PML boundary in y-direction
options.IndexContour = 'all'; % display index contours in all plots

% Optional parameters for bpmsolver
options.Step = 5; % set step size in z-direction to 5 um
options.Monitor = true; % monitor propagating field
options.MonitorStep = 20; % refresh the monitor every 20 Steps, i.e., every 100 um
options.MonitorGraphType = 'Int2D'; % monitor the 3D intensity distribution and 1D intensity distribution at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.SlicesXZ = 0; % display x-z slice distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.PowerTrace = 'continuous'; % trace power continuously
options.PowerTraceStep = 2; % take power samples every 2 Steps
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 20; % display the index distribution every 20 Steps
options.Index3DStep = 2; % take index samples every 2 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
[bpmData, ~, figureHandles] = bpmsolver(beamProblem);

titleString = sprintf('%s, %s input channel (\\lambda = %g nm)',get(get(figureHandles.SlicesXZ.Axes,'Title'),'String'),color,lambda*1e3);
title(figureHandles.SlicesXZ.Axes,titleString); % add color and wavelength information to x-z slice title
figureChildren = get(figureHandles.Power.Figure,'Children');
axesChildren = get(figureHandles.Power.Axes,'Children');
set(figureChildren(1),'Location','west'); % set position of legend in power trace plot to 'west'
set(axesChildren(3),'Color','red'); % set line color of red input channel to red
set(axesChildren(2),'Color','green'); % set line color of green input channel to green
set(axesChildren(1),'Color','blue'); % set line color of blue input channel to blue

couplingStrength = bpmData.Power.Values(2,end)/sum(bpmData.Power.Values(:,1));
fprintf('Coupling stength: %.2f%%\n',couplingStrength*100);

end

%% Propagation structure
function waveguide = get_waveguide

len = 7500;
coreNumber = 3; % number of cores
coreWidth = [2 2]; % maximum core extensions in x- and y-direction
coreIndex = getmaterial('SiO2','Delta',0.5); % refractive index of core
claddingIndex = getmaterial('SiO2'); % refractive index of cladding

options.PowerAreaSize = 2*coreWidth; % define integration area for power evaluation
options.PowerAreaType = 'elliptical'; % use a circular area with a diameter of twice the core diameter surrounding the core for power evaluation
options.PowerCenter = 'core'; % define center of integration area for power evaluation
options.ShiftTransition = 'custom'; % use custom shift functions

gap = 2.4; % gap between cores
d = gap+coreWidth(1); % distance between centers of cores
cb = 3620; % coupling length blue
sb = 770; % shift length blue
cr = 520; % coupling length red
sr = 1750; % shift length red
zr = sb+cb/2+sb-sr-cr/2; % z-offset red

% Red
points = [...
    25 0 0;...
    25 0 zr;...
    d  0 zr+sr;...
    d  0 zr+sr+cr;...
    25 0 zr+sr+cr+sr];
breakpoints = 6000;
options.ShiftFunction{1} = @(z) linsinpath(z,points,'Breakpoints',breakpoints);

% Green
points = [0 0 0];
options.ShiftFunction{2} = @(z) linsinpath(z,points);

% Blue
points = [...
    -25 0 0;...
    -d  0 sb;...
    -d  0 sb+cb/2;...
    -25 0 sb+cb/2+sb;...
    -d  0 sb+cb/2+sb+sb;...
    -d  0 sb+cb/2+sb+sb+cb/2;...
    -25 0 sb+cb/2+sb+sb+cb/2+sb];
breakpoints = 7000;
options.ShiftFunction{3} = @(z) linsinpath(z,points,'Breakpoints',breakpoints);

waveguide = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);

end
