function bpmData = mach_zehnder_interferometer
%MACH_ZEHNDER_INTERFEROMETER - Beam propagation in a Mach-Zehnder modulator.
%
%   This BeamLab demo shows the beam propagation through a Mach-Zehnder
%   interferometer (MZI) with two input and two output arms. The dimensions
%   are chosen such that the electric field's amplitude and phase can be
%   easily discerned along the propagation direction.
%
%   MACH_ZEHNDER_INTERFEROMETER
%   bpmData = MACH_ZEHNDER_INTERFEROMETER(___)

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [160 80]; % resolution in x- and y-direction
gridSize = [8 4]; % width of calculation area in x- and y-direction
lambda = 0.85; % wavelength
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputOptions.ModeNumber = 1; % calculate only the fundamental mode (default)
inputOptions.ModeSections = 1; % use section 1 as the section for mode evaluation (default)
inputOptions.ModeCore = 2; % use core 2 as input core
inputOptions.ModePolarization = 'y'; % use linear polarization in y-direction
inputField = @(beamProblem) modeinput(beamProblem,inputOptions);

%% Optional parameters
% General optional parameters
options.Sections = 1:6; % use sections 1 to 6 as propagation structure
options.VectorType = 'semi'; % use a semi-vectorial mode or BPM solver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.BoundaryX = 'pml1'; % use a 1st order PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a 1st order PML boundary in y-direction
options.IndexContour = 'all'; % display index contours in all plots

% Optional parameters for bpmsolver
options.Step = .02; % step size in z-direction
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = 'Int2D'; % display the 2D intensity distribution
options.MonitorScale = 'lininput'; % use a linear scale normalized to the maximum input intensity for all monitor plots
options.SlicesXZ = 0; % display x-z slice intensity distribution at y = 0 in all x-z plots
options.SlicesXZScale = 'lininput'; % use a linear scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZGraphType = 'Re(Ey)2D'; % display the real part of the electric field's y-component in x-z plots
options.SlicesXZYZStep = 1; % for the x-z distribution take intensity samples at every single Step (to properly resolve the field's real part)
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 100; % display 2D index distribution every 100 Steps
options.Index3DStep = 10; % take index samples every 10 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

detailXlim = [12 30]; % limits of detail plot in horizontal direction
detailYlim = [-3 3];  % limits of detail plot in vertical direction
pos = [detailXlim(1),detailYlim(1),diff(detailXlim),diff(detailYlim)];
rectangle('Position',pos,'LineWidth',1,'LineStyle','--');
text(mean(detailXlim),detailYlim(2)+0.3,'Detail plot','HorizontalAlignment','center');

%% Create additional detail plot using bpmplot
figureHandles = bpmplot(bpmData);

titleString = [get(get(figureHandles.SlicesXZ.Axes,'Title'),'String') ', detail plot'];
title(figureHandles.SlicesXZ.Axes,titleString);
axis(figureHandles.SlicesXZ.Axes,'equal');
xlim(figureHandles.SlicesXZ.Axes,detailXlim);
ylim(figureHandles.SlicesXZ.Axes,detailYlim);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to most sections
coreNumber = 2;
coreWidth = {[1 0.6],[1 0.6]};
coreIndex = getmaterial('SiO2','Delta',6); % core index
claddingIndex = getmaterial('SiO2'); % refractive index of cladding

shift1 = {[-1.6 0],[1.6 0]};
shift2 = {[-0.6 0],[0.6 0]};

commonVariables = getcommonvars(); % define variables which should not be cleared by sectionclear

%% Section 1
len = 1;
options.Shift = shift1;

waveguide{1} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 2
len = 20;
options.Shift = shift1;
options.ShiftEnd = shift2;

waveguide{2} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 3
len = 20;
options.Shift = shift2;
options.ShiftEnd = shift1;

waveguide{3} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 4
len = 20;
options.Shift = shift1;
options.ShiftEnd = shift2;

waveguide{4} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 5
len = 20;
options.Shift = shift2;
options.ShiftEnd = shift1;

waveguide{5} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 6
len = 1;
options.Shift = shift1;

waveguide{6} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);

end
