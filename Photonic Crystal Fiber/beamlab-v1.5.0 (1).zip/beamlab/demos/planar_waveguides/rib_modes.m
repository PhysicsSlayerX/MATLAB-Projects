function [modeData,effectiveIndex] = rib_modes
%RIB_MODES - Eigenmode calculation of a rib waveguide.
%
%   This BeamLab demo calculates the field distributions and effective
%   indices of the eigenmodes of a rib waveguide.
%
%   RIB_MODES
%   [modeData,effectiveIndex] = RIB_MODES

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [300 300]; % resolution in x- and y-direction
gridSize = [10 10]; % width in um of calculation area in x- and y-direction
lambda = 1.55; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Optional parameters
options.ModeNumber = 4; % calculate the first four modes of the waveguide defined by indexFunction
options.VectorType = 'full'; % use the full-vectorial mode solver
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = 'tbc'; % use a TBC boundary in y-direction (default)
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.ModeSlicesXY = 0; % display x-y distributions at z = 0
options.SlicesXYGraphType = {'Abs(Ex)2D','Abs(Ey)2D','Abs(Ez)2D'}; % display the the absolute values of the x-, y-, and z-components of the mode field
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized the maximum of the total intensity 
options.SlicesXYRange = 20; % use a 20 dB range for all x-y plots
options.IndexContour = 'all'; % display index contour lines in all slice plots
options.IndexContourLineColor = [1 1 1]; % set the color of the index contour lines to white (default)
options.IndexContourValues = 3.3; % generate index contour at the average index value between core and substrate index
options.Shading2D = 'flat'; % set the color shading of surface graphic objects to flat
options.ModeOutput = true; % save output data to a mat file
options.ModeOutputFilename = 'rib_modes_output'; % name of the file to which all input and output parameters are saved to

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,options);

%% Start mode solver calculation
[modeData,effectiveIndex] = modesolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

coreNumber = 1; % number of cores
coreWidth = [3 2]; % maximum core extensions in x- and y-direction
coreIndex = 3.5; % refractive index of core
claddingIndex = 2; % refractive index of cladding
substrateWidth{1} = [Inf 1]; % extension of substrate 1 in x- and y-direction
substrateWidth{2} = [Inf 3]; % extension of substrate 2 in x- and y-direction
substrateCenter{1} = [0 -1.5]; % coordinates of the center of substrate 1
substrateCenter{2} = [0 -3.5]; % coordinates of the center of substrate 2
substrateIndex{1} = 3.5; % refractive index of substrate 1
substrateIndex{2} = 3.1; % refractive index of substrate 2

waveguide = @(beamProblem) rib(beamProblem,1,coreNumber,coreWidth,coreIndex,claddingIndex,substrateWidth,substrateCenter,substrateIndex);

end
