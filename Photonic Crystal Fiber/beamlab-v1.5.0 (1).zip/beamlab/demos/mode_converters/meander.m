function bpmData = meander
%MEANDER - Beam propagation in a sinusoidally oscillating waveguide.
%
%   This BeamLab demo shows how to create a waveguide with a user-defined
%   cross-section and a sinusoidally oscillating waveguide center. The
%   fundamental mode is launched into the user-defined trapezoidal
%   multi-mode waveguide and then partly coupled to higher-order modes in
%   the meander section. After the meander section an adiabatic transition
%   to a low-index single-mode waveguide strips the excited higher-order
%   modes from the fundamental mode.
%
%   MEANDER
%   bpmData = MEANDER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [60 60]; % resolution in x- and y-direction
gridSize = [30 30]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.55; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.Sections = 1:7; % use as propagation structure the sections in the order of 1 to 7
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = 'tbc'; % use a TBC boundary in y-direction (default)
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = 1.452; % index value for index contour
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distribution (default)
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-10 0]; % use a range from -10 to 0 dB for all x-y plots

% Optional parameters for bpmsolver
options.Step = 2; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.SlicesXZ = 0; % display the x-z intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'logmax'; % use a logarithmic scale normalized to the maximum intensity for all x-z plots
options.SlicesXZRange = [-10 0]; % use a range from -10 to 0 dB for all x-z plots
options.SlicesYZ = 0; % display the y-z intensity distribution at x = 0 and save it in bpmData
options.SlicesYZScale = 'logmax'; % use a logarithmic scale normalized to the maximum intensity for all y-z plots
options.SlicesYZRange = [-10 0]; % use a range from -10 to 0 dB for all y-z plots
options.SlicesXZYZStep = 5; % for x-z and y-z plots take intensity samples every 5 Steps 
options.Monitor = true; % monitor propagating field
options.MonitorStep = 25; % refresh the monitor every 25 Steps
options.MonitorGraphType = 'Int2D'; % display the intensity distribution of the propagating field
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-10 0]; % use a range from -10 to 0 dB for all monitor plots
options.PowerTrace = 'continuous'; % continuously trace the power
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.LineWidth = 1; % use a line width of 1 for graphs
options.ShowSectionTitles = true; % show section titles in monitor plots
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 50; % display the index distribution every 50 Steps
options.IndexRange = [1.45 1.462]; % set index range to fixed values
options.Index3DStep = 5; % take index samples every 5 Steps for the 3D index contour
options.Index3DAspectRatio = [1 1 30];

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
width = [15 10]; % maximum core extensions in x- and y-direction
claddingIndex = 1.45; % cladding index

options.PowerAreaSize = [20 20]; % define integration area for power evaluation
options.SmoothingWidth = 1; % smooth index distribution at core-cladding boundary across 1 pixel
options.SmoothingLevel = 3; % use a 3-level gradation in the smoothing region

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 200; % section length
coreIndex = 1.462;
indexFunction2D{1} = @(x,y) my_waveguide2d(x,y,width,coreIndex,claddingIndex);

options.IndexScannerStep = 250; % override corresponding beamProblem option and display the index distribution every 250 Steps in this section
options.Index3DStep = 25; % override corresponding beamProblem option and take index samples every 25 Steps for the 3D index contour of this section
options.PowerCenter = 'fixed'; % define integration center for power evaluation
options.SectionTitle = 'straight waveguide';

waveguide{1} = @(beamProblem) customwaveguide2d(beamProblem,len,indexFunction2D,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 2
len = 1000;
coreIndex = 1.462;
indexFunction2D{1} = @(x,y) my_waveguide2d(x,y,width,coreIndex,claddingIndex); % defined custom waveguide index distribution

options.WaveguideCenter{1} = @(z) my_waveguide_center_1(z,[0 5],2000,0); % define custom waveguide center
options.PowerCenter = 'custom'; % define integration center for power evaluation
options.PowerCenterFunction = options.WaveguideCenter{1}; % define function of custom-defined integration center for power evaluation
options.SectionTitle = 'meander waveguide';

waveguide{2} = @(beamProblem) customwaveguide2d(beamProblem,len,indexFunction2D,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 2000;
coreIndex = 1.462;
indexFunction2D{1} = @(x,y) my_waveguide2d(x,y,width,coreIndex,claddingIndex);

options.WaveguideCenter{1} = @(z) my_waveguide_center_2(z,[0 5],800,pi/2);
options.PowerCenter = 'custom';
options.PowerCenterFunction = options.WaveguideCenter{1};
options.SectionTitle = 'meander waveguide';

waveguide{3} = @(beamProblem) customwaveguide2d(beamProblem,len,indexFunction2D,options);
sectionclear('KeepVariables',commonVariables);

%% Section 4
len = 1000;
coreIndex = 1.462;
indexFunction2D{1} = @(x,y) my_waveguide2d(x,y,width,coreIndex,claddingIndex);

options.WaveguideCenter{1} = @(z) my_waveguide_center_1(z,[0 -5],2000,pi/2);
options.PowerCenter = 'custom';
options.PowerCenterFunction = options.WaveguideCenter{1};
options.SectionTitle = 'meander waveguide';

waveguide{4} = @(beamProblem) customwaveguide2d(beamProblem,len,indexFunction2D,options);
sectionclear('KeepVariables',commonVariables);

%% Section 5
len = 1000;
coreIndex = 1.462;
indexFunction2D{1} = @(x,y) my_waveguide2d(x,y,width,coreIndex,claddingIndex);

options.IndexScannerStep = 250;
options.Index3DStep = 100;
options.PowerCenter = 'fixed';
options.SectionTitle = 'meander waveguide';

waveguide{5} = @(beamProblem) customwaveguide2d(beamProblem,len,indexFunction2D,options);
sectionclear('KeepVariables',commonVariables);

%% Section 6
len = 1000;
indexFunction3D{1} = @(x,y,z) my_waveguide3d(x,y,z,len,width,claddingIndex);

options.IndexScannerStep = 25;
options.Index3DStep = 100;
options.PowerCenter = 'fixed';
options.SectionTitle = 'adiabatic index transition';

waveguide{6} = @(beamProblem) customwaveguide3d(beamProblem,len,indexFunction3D,options);
sectionclear('KeepVariables',commonVariables);

%% Section 7
len = 2800;
coreIndex = 1.453;
indexFunction2D{1} = @(x,y) my_waveguide2d(x,y,width,coreIndex,claddingIndex);

options.IndexScannerStep = 250;
options.Index3DStep = 100;
options.PowerCenter = 'fixed';
options.SectionTitle = 'straight waveguide';

waveguide{7} = @(beamProblem) customwaveguide2d(beamProblem,len,indexFunction2D,options);
sectionclear('KeepVariables',commonVariables);

end

%% User-defined waveguide functions

function indexmat = my_waveguide2d(x,y,width,coreIndex,claddingIndex)
%   This function is a function of two variables (x,y) and generates a
%   matrix containing the 2D refractive index distribution of a custom
%   defined waveguide with trapezoidal core.

bw = width(1); % bottom width
he = width(2); % height
tw = 5; % top width

indexmat = claddingIndex*ones(size(x));
indexmat(y >= -he/2 & y <= he/2 & x/(bw/2)+(y+he/2)/((he*bw)/(bw-tw)) < 1 & -x/(bw/2)+(y+he/2)/((he*bw)/(bw-tw)) < 1) = coreIndex;

end

function indexmat = my_waveguide3d(x,y,z,len,width,claddingIndex)
%   This function is a function of three variables (x,y,z) and generates a
%   matrix containing the 2D refractive index distribution of a custom
%   defined waveguide with a trapezoidal core that furthermore changes its
%   core index in z-direction.

% core index that decreases with z to radiate the higher-order modes into the cladding
coreIndexBegin = 1.462;
coreIndexEnd = 1.453;
coreIndex = (coreIndexBegin + coreIndexEnd)/2 + (coreIndexBegin - coreIndexEnd)/2*(1 - 2*z/len);

bw = width(1); % bottom width
he = width(2); % height
tw = 5; % top width

indexmat = claddingIndex*ones(size(x));
indexmat(y >= -he/2 & y <= he/2 & x/(bw/2)+(y+he/2)/((he*bw)/(bw-tw)) < 1 & -x/(bw/2)+(y+he/2)/((he*bw)/(bw-tw)) < 1) = coreIndex;

end

function wace = my_waveguide_center_1(z,peak,period,phase)
%   This function generates a two-element vector wace containing the x-
%   and y-coordinates of a meander oscillating between 0 and PEAK in
%   z-direction.
%   
%   PEAK is a two-element vector describing the orientation in the
%   x-y plane and magnitude of the meander peak.
%   PERIOD is the meander period (for one oscillation cycle along the
%   waveguide PERIOD = LEN)
%   PHASE is a phase offset of the oscillation in z-direction

wace(1) = peak(1)*sin(pi/period*z + phase).^2;
wace(2) = peak(2)*sin(pi/period*z + phase).^2;

end

function wace = my_waveguide_center_2(z,peak,period,phase)
%   This function generates a two-element vector wace containing the x-
%   and y-coordinates of a meander oscillating between -PEAK and PEAK in
%   z-direction.
%   
%   PEAK is a two-element vector describing the orientation in the
%   x-y plane and magnitude of the meander peak.
%   PERIOD is the meander period (for one oscillation cycle along the
%   waveguide PERIOD = LEN)
%   PHASE is a phase offset of the oscillation in z-direction

wace(1) = peak(1)*sin(2*pi/period*z + phase);
wace(2) = peak(2)*sin(2*pi/period*z + phase);

end
