function bpmData = splitter
%SPLITTER - Beam propagation in a waveguide splitter.
%
%   This BeamLab demo shows a propagation model consisting of a straight
%   waveguide section followed by a multicore waveguide section that breaks
%   out the single core to a two-ring multicore structure consisting of
%   four inner cores regularly arranged on a circle of radius 17 um and
%   4 outer cores regularly arranged on a circle of radius 20*sqrt(2) um
%   but rotated by 45 degrees. 
%
%   SPLITTER
%   bpmData = SPLITTER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [160 160]; % resolution in x- and y-direction
gridSize = [80 80]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.VectorType = 'semi'; % use a semi-vectorial mode- and bpmsolver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.IndexContour = 'all'; % display index contours in all plots
options.LineWidth = 1; % use a line width of 1 for graphs

% Optional parameters for bpmsolver
options.Sections = 1:2; % use sections 1 and 2 as propagation structure for the BPM calculation
options.Step = 2; % set step size in z-direction to 2 um
options.Monitor = true; % monitor propagating field
options.MonitorStep = 20; % refresh the monitor every 10 Steps, i.e., every 20 um
options.MonitorGraphType = 'Int2D'; % monitor the 2D intensity distribution and 1D intensity distribution at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.SlicesXYStacked = 6; % display 6 x-y distributions equidistantly spaced between z = 0 and 3.1 mm as stacked plots in a separate figure
options.SlicesXYGraphType = 'Int2D'; % monitor the 2D intensity distribution
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXZ = 0; % display x-z slice distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.SlicesXZYZStep = 10; % for x-z and y-z plots take intensity samples every 10 Steps
options.PowerTrace = 'continuous'; % trace power continuously
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.PowerTraceScale = 'loginput';
options.PowerTraceRange = [-10 0];
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 40; % display the index distribution every 40 Steps
options.Index3DStep = 10; % take index samples every 10 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreWidth = [10 10]; % elliptical core by default
coreIndex = getmaterial('SiO2','Delta',0.7);
claddingIndex = getmaterial('SiO2');

options.PowerAreaType = 'elliptical';
options.PowerAreaSize = 1.5*coreWidth;

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

% Define waveguide parameters that are specific to each section

%% Section 1
len = 100;

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex);
sectionclear('KeepVariables',commonVariables);

%% Section 2
len = 3000;
coreNumber{1} = 4; % core number of ring 1
coreNumber{2} = 4; % core number of ring 2
ringRadius{1} = 0; % radius of ring 1 at section begin
ringRadius{2} = 0; % radius of ring 2 at section begin

options.RingAngleOffset{1} = 0; % angular offset of ring 1 cores from x-axis
options.RingAngleOffset{2} = 45; % angular offset of ring 2 cores from x-axis
options.RingRadiusEnd{1} = 17; % radius of ring 1 at section end
options.RingRadiusEnd{2} = 20*sqrt(2); % radius of ring 2 at section end

waveguide{2} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);

end
