function bpmData = photonic_lantern
%PHOTONIC LANTERN - Beam propagation in a photonic lantern with vanishing cores.
%
%   This BeamLab demo shows beam propagation in one core of a photonic
%   lantern which consists of 6 cores surrounded by an inner and outer
%   cladding tapered down to a multimode fiber where the inner and outer
%   cladding of the photonic lantern take over the role of the core and
%   cladding of the multimode fiber.
%
%   PHOTONIC_LANTERN
%   bpmData = PHOTONIC_LANTERN

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [160 160]; % resolution in x- and y-direction
gridSize = [80 80]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.55; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
inputOptions.ModeCore = 2; % use core #2 for the eigenmode calculation of the input field distribution
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the fundamental mode of core #2 as input

%% Optional parameters
% General optional parameters
options.Sections = [1 2]; % use sections 1 and 2
options.SymmetryX = true; % the index distribution is symmetric with respect to the y-axis
options.SymmetryY = false; % the index distribution is asymmetric with respect to the y-axis

% Optional parameters for bpmsolver
options.Step = 2; % set step size in z-direction to 2 um
options.SlicesXYStacked = 6; % display 6 x-y distributions equidistantly spaced between z = 0 and 6 mm as stacked plots in a separate figure
options.SlicesXYGraphType = {'Index2D','Int2D'}; % display the 2D index and intensity distributions in all x-y-slice plots
options.SlicesYZ = 0; % display the y-z intensity distribution at x = 0 and save it in bpmData
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = 'Int2D'; % monitor the 2D intensity distribution
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = [1.447 1.453]; % generate index contour at average values between core and cladding indices
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 50; % display the index distribution every 50 Steps
options.IndexRange = [1.444 1.456]; % set index range to fixed values
options.Index3DStep = 20; % take index samples every 20 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
% This section consists of one center core and five outer cores surrounded
% by an inner and outer cladding which are altogether tapered down to a
% multimode fiber.
len = 5000; % section length
coreWidth = [8 8]; % maximum core extensions in x- and y-direction
claddingIndex = getmaterial('SiO2'); % cladding index (outer cladding)
coreIndex = getmaterial('SiO2','Delta',0.8); % core index
coreNumber = {1,5}; % 1 center core and 5 outer cores
ringRadius = {0,20}; % radius of core rings (0 corresponds to the center core)

options.CoreWidthEnd = [0 0]; % all cores should vanish at the end of the section
options.RingRadiusEnd = {0,0}; % all cores should converge towards the center
options.InnerCladdingIndex = getmaterial('SiO2','Delta',0.4); % refractive index of inner cladding
options.InnerCladdingWidth = [70 70]; % diameter of inner cladding at section begin
options.InnerCladdingWidthEnd = [20 20]; % diameter of inner cladding at section end
options.RingAngleOffset = 90; % the first core in the outer ring should be oriented in y-direction

waveguide{1} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);

%% Section 2
% This section consists of a multimode fiber with the same dimensions and
% index as found at the end facet of the photonic lantern of section 1.
len = 1000;
coreWidth = options.InnerCladdingWidthEnd;
coreIndex = options.InnerCladdingIndex;

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex);

end
