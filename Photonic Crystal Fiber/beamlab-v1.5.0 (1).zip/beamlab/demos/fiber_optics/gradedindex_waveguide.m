function bpmData = gradedindex_waveguide
%GRADEDINDEX_WAVEGUIDE - Full-vectorial beam propagation in a multi-mode circular graded-index waveguide.
%
%   This BeamLab demo shows propagation through a multi-mode circular
%   graded-index waveguide. First, the true eigenmodes of the waveguide are
%   calculated with the full-vectorial modesolver. Then, a combination of
%   two eigenmodes corresponding to the distribution of a linearly
%   polarized (LP) mode are inserted at the input facet of the multi-mode
%   waveguide and propagated through the waveguide using the full-vectorial
%   bpmsolver. Since the eigenmodes have a slightly different propagation
%   constant the LP mode (being not a true eigenmode of the fiber) changes
%   its shape during propagation. This phenomenon can only be observed with
%   a full-vectorial propagation method taking into account the coupling
%   between the x- and y-components of the electric field. In this example
%   the core-cladding index difference is set to a much larger value than
%   that of typical fibers to keep the beat length of the two inserted
%   eigenmodes below 1 mm.
%
%   GRADEDINDEX_WAVEGUIDE
%   bpmData = GRADEDINDEX_WAVEGUIDE

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [200 200]; % resolution in x- and y-direction
gridSize = [10 10]; % width in um of calculation area in x- and y-direction
lambda = 1.55; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.ModeNumber = 6; % calculate the first 6 modes
inputOptions.ModeSortingOrder = 'real'; % sort the modes according to the real part of the effective refractive index in descending order (default)
inputOptions.ModeSelect = [3 6]; % use a linear combination of modes 3 and 6
inputOptions.ModeAmplitude = [1 -1]/sqrt(2); % amplitude of modes 3 and 6
inputField = @(beamProblem) modeinput(beamProblem,inputOptions);

%% Optional parameters
% General optional parameters
options.VectorType = 'full'; % use full-vectorial mode solver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.Sections = 1; % use section 1 of propagation structure
options.IndexContour = 'all'; % display index contour lines
options.IndexContourValues = 1.451; % index value where the index contour shall be generated

% Optional parameters for bpmsolver
options.Step = 2; % step size in z-direction
options.SlicesXY = [215 430 Inf]; % display x-y distributions at z = 0, 460 um and of the last slice
options.SlicesXYGraphType = 'Int2D';
options.SlicesXYScale = 'lininput'; % use a linear scale normalized to the maximum intensity for all x-y plots
options.SlicesXYRange = [0 1]; % use a range from 0 to 1 for all x-y plots
options.SlicesXZ = 0; % display intensity distribution in the x-z plane at y = 0
options.SlicesXZScale = 'lininput'; % use a linear scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [0 1]; % use a range from 0 to 1 for all x-z plots
options.SlicesYZ = 0; % display intensity distribution in the y-z plane at x = 0
options.SlicesYZScale = 'lininput';% use a linear scale normalized to the maximum input intensity for all y-z plots
options.SlicesYZRange = [0 1]; % use a range from 0 to 1 for all y-z plots
options.SlicesXZYZStep = 5; % for x-z and y-z plots take intensity samples every 5 Steps
options.Monitor = true; % monitor propagating field
options.MonitorStep = 5; % refresh the monitor every 5 Steps
options.MonitorGraphType = {'Int2D','Abs(Ex)2D','Empty','Abs(Ey)2D'}; % monitor the intensity distribution and absolute values of the x-, y-components of the propagating field
options.MonitorScale = 'lininput'; % use a linear scale normalized to the maximum intensity for all monitor plots
options.MonitorRange = [0 1]; % use a range from 0 to 1 for all monitor plots
options.DisplaySize = [6 6]; % display all output distributions within an x-y area of 6 um x 6 um
options.Quiver = 'slices'; % display quivers in intensity and field plots during monitor
options.Output = true; % save output data to a mat file
options.OutputFilename = 'gradedindex_waveguide_output'; % name of the file to which all input and output parameters are saved to
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexSlicesXY = 0; % display x-y index distribution at z = 0
options.IndexScanner = false; % do not scan the index distribution (i.e., generate only x-y index slice)
options.Index3D = false; % do not generate 3D index contour

options.PowerTrace = 'continuous'; % trace power continuously

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,options);

%% Visualize index distribution
indexplot(beamProblem); % display x-y index slice

%% Visualize input field
inputplot(beamProblem,inputField);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem,inputField);

end

%% Propagation structure
function waveguide = get_waveguide

coreWidth = [5 5]; % core width in x- and y-direction
claddingIndex = 1.45; % cladding index
coreIndex = 1.7; % core index

len = 860; % length of section
options.ProfileExponent = 2; % graded-index distribution in the core with a square profile of the permittivity

options.PowerAreaType = 'elliptical';
options.PowerAreaSize = {[3 3],[5 5],[7 7]}; % evaluate the power across three different circular areas whose centers are aligned with the core center

waveguide = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

end
