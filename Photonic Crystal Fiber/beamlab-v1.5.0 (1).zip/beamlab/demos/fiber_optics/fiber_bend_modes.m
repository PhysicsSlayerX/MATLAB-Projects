function [modeData,effectiveIndex] = fiber_bend_modes
%FIBER_BEND_MODES - Eigenmode calculation of an optical fiber with a bend.
%
%   This BeamLab demo calculates the field distributions and effective
%   indices of the first three eigenmodes propagating in an optical fiber 
%   with a bend radius of 4 cm near the LP11 cutoff wavelength.
%
%   FIBER_BEND_MODES
%   [modeData,effectiveIndex] = FIBER_BEND_MODES

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [400 400]; % resolution in x- and y-direction
gridSize = [80 80]; % width in um of calculation area in x- and y-direction
lambda = 1.2; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Optional parameters
options.VectorType = 'semi'; % use the full-vectorial mode solver
options.BoundaryX = 'pml1'; % use a PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a PML boundary in y-direction
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.ModeNumber = 25; % calculate the first 25 modes of the waveguide defined by indexFunction
options.ModeSelect = 1:3; % display only the first three modes
options.ModeSortingOrder = 'imag'; % order the modes according to increasing imaginary part of the effective
options.ModeSlicesXY = 0; % display x-y distributions at z = 0
options.SlicesXYGraphType = 'Int2D'; % display the the absolute values of the x-, y-, and z-components of the mode field
options.SlicesXYScale = 'lininput'; % use a logarithmic scale normalized the maximum of the total intensity 
options.IndexContour = 'all'; % display index contour lines in all slice plots
options.IndexContourLineColor = [0 0 0]; % set the color of the index contour lines to white (default)
options.IndexContourLineWidth = 2; % line width of the index contour overlay
options.IntensityContour = 'all'; % display intensity contour lines for all slice plots
options.IntensityContourOnly = true; % display only intensity contour lines
options.DisplaySize = [40 40]; % display all output distributions within an x-y area of 40 um x 40 um

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,options);

%% Start mode solver calculation
[modeData,effectiveIndex] = modesolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

len = 1;
coreWidth = [8 8]; % maximum core extensions in x- and y-direction
coreIndex = getmaterial('SiO2','Delta',0.35); % refractive index of core
claddingIndex = getmaterial('SiO2'); % refractive index of cladding

options.BendRadius = 40e3;

waveguide = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

end
