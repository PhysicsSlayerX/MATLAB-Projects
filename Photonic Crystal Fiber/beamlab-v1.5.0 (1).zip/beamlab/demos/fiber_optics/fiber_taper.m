function bpmData = fiber_taper
%FIBER_TAPER - Mode size conversion by means of a taper.
%
%   This BeamLab demo shows propagation of the fundamental mode of a fiber
%   whose size is changed by means of a fiber taper.
%
%   FIBER_TAPER
%   bpmData = FIBER_TAPER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [150 150]; % resolution in x- and y-direction
gridSize = [30 30]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.55; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
inputField = @(beamProblem) modeinput(beamProblem); % create fundamental mode at input

%% Optional parameters
% General optional parameters
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.IndexContour = 'all'; % display index contours in all plots

% Optional parameters for bpmsolver
options.Sections = 1:3; % use sections 1 to 3
options.Step = 1; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit)
options.Monitor = true; % monitor propagating field
options.SlicesXYStacked = 7; % display 7 x-y distributions equidistantly spaced between z = 0 and 1.2 mm as stacked plots in single figures
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem); % display both 2D and 3D index distributions

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

% parameters common to all sections
coreIndex = getmaterial('SiO2','Delta',0.7); % refractive index of the core
claddingIndex = getmaterial('SiO2'); % refractive index of the cladding

%% Section 1
len = 100; % section length
coreWidth = [15 15]; % core width

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex);

%% Section 2
len = 1000; % section length
coreWidth = [15 15]; % core width at section begin
options.CoreWidthEnd = [5 5]; % core width at section end

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

%% Section 3
len = 100; % section length
coreWidth = [5 5]; % core width

waveguide{3} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex);

end
