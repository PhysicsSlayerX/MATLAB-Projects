function [modeData,effectiveIndex] = fiber_modes
%FIBER_MODES - Eigenmode calculation of an optical fiber.
%
%   This BeamLab demo calculates the effective indices and field
%   distributions of the eigenmodes of a step-index fiber with a circular
%   core. After the calculation, the three field components of the first 4
%   low-order modes are displayed both as pseudocolor plots and as field
%   contour lines.
%
%   FIBER_MODES
%   [modeData,effectiveIndex] = FIBER_MODES

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [300 300]; % resolution in x- and y-direction
gridSize = [30 30]; % width in um of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.55; % wavelength in um (unit is defined by optional parameter LengthUnit)
indexFunction = get_waveguide; % define waveguide geometry

%% Optional parameters
% General optional parameters
options.VectorType = 'full'; % use the full-vectorial mode solver
options.BoundaryX = 'tbc'; % use a TBC boundary (default)
options.BoundaryY = 'tbc'; % use a TBC boundary (default)
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.SlicesXYGraphType = {'Abs(Ex)2D','Abs(Ey)2D','Abs(Ez)2D'}; % display the the absolute values of the x-, y-, and z-components of the mode field
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = 20; % use a 20 dB range for all x-y plots
options.IndexContour = 'all'; % display index contour lines in all slice plots
options.IndexContourLineColor = [1 1 1]; % set the color of the index contour lines to white (default)
options.DisplaySize = [20 20]; % display all output distributions within an x-y area of 20 um x 20 um
options.Shading2D = 'interp'; % set the color shading of surface graphic objects to interpolating (default)
options.ModeOutput = true; % save output data to a mat file
options.ModeOutputFilename = 'fiber_modes_output'; % name of the file to which outputData is saved to

% Optional parameters for modesolver
options.ModeNumber = 4; % calculate the first four modes of the waveguide defined by indexFunction
options.ModeSlicesXY = 0; % display x-y distributions at z = 0

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,options);

%% Start mode solver calculation
[modeData,effectiveIndex] = modesolver(beamProblem);

%% Create an additional plot displaying only the intensity contour lines
modeplotOptions.IndexContourLineColor = [0 0 0]; % use black index contour lines
modeplotOptions.IntensityContour = 'all'; % display intensity contour lines for all slice plots
modeplotOptions.IntensityContourOnly = true; % display only intensity contour lines

modeplot('fiber_modes_output',modeplotOptions); % replot output data using the modified parameters modeplotOptions

end

%% Propagation structure
function waveguide = get_waveguide

coreWidth = [10 10]; % maximum core extensions in x- and y-direction
coreIndex = getmaterial('SiO2','Delta',1); % refractive index of the core
claddingIndex = getmaterial('SiO2'); % refractive index of the cladding

options.SmoothingWidth = 1; % smooth index distribution at core-cladding boundary across 1 pixel
options.SmoothingLevel = 20; % use a 20-level gradation in the smoothing region

waveguide = @(beamProblem) singlecore(beamProblem,1,coreWidth,coreIndex,claddingIndex,options);

end
