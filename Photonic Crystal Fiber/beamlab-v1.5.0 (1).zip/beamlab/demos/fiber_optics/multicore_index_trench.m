function bpmData = multicore_index_trench
%MULTICORE_INDEX_TRENCH - Beam propagation in a multicore fiber surrounded by an index trench.
%
%   This BeamLab demo shows beam propagation in one core of a multicore
%   fiber where each core is surrounded by an index trench and the core
%   pitch slowly decreases in propagation direction to couple the light of 
%   all cores into a multimode fiber.
%
%   MULTICORE_INDEX_TRENCH
%   bpmData = MULTICORE_INDEX_TRENCH

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [150 150]; % resolution in x- and y-direction
gridSize = [100 100]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength

n1 = getindex('SiO2',lambda,'Delta',0.35);
n2 = getindex('SiO2',lambda);
n3 = getindex('SiO2',lambda,'Delta',-0.35);

indexFunction = get_waveguide(n1,n2,n3); % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set power of input mode to 1 mW
inputOptions.ModeCore = 2; % use waveguide core 2 for the eigenmode calculation of the input field distribution
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.SymmetryX = true; % the index distribution is symmetric in x-direction
options.SymmetryY = true; % the index distribution is symmetric in y-direction
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = options.BoundaryX; % use the same boundary in y-direction

% Optional parameters for bpmsolver
options.Sections = [1 2]; % use sections 1 and 2 for beam propagation
options.Step = 2; % step size in z-direction
options.SlicesXY = 0; % display x-y distributions at z = 0
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distribution (default)
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = 20; % use a range of 20 dB for all x-y plots
options.SlicesXZ = 0; % display the x-z intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = 20; % use a range of 20 dB for all x-z plots
options.SlicesYZ = 0; % display the y-z intensity distribution at x = 0 and save it in bpmData
options.SlicesYZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all y-z plots
options.SlicesYZRange = 20; % use a range of 20 dB for all y-z plots
options.SlicesXZYZStep = 10; % intensity samples are taken every 10 Steps for generating the intensity distribution of the x-z and y-z slices 
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = 'Int2D'; % display the intensity distribution of the propagating field
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = 20; % use a range of 20 dB for all monitor plots
options.IndexSlicesXY = [0 Inf]; % display x-y index distribution at z = 0 and at the end of the propagation structure
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = 0.5*(n1+n2); % index value where the index contour shall be generated
options.PowerTrace = 'continuous'; % continuously trace the power
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 50; % display the index distribution every 50 Steps
options.Index3DStep = 50; % take index samples every 50 Steps for the 3D index contour
options.Index3DValues = 0.5*[n1+n2  n2+n3]; % generate two 3D index contours at the specified index values

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Visualize input field
inputplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide(n1,n2,n3)

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1 (multicore fiber with decreasing core pitch)
% This section consists of 3 core rings with 3 different core types in each
% ring. These core types differ in core width and core index to create
% cores surrounded by an index trench.
len = 5000;
coreNumber = {1,6,12}; % number of cores in each core ring
coreWidth = {{[8 8],[10 10],[14 14]},... % core of ring #1 with 3 different core zones defining the widths of inner core and trench
             {[8 8],[10 10],[14 14]},... % core of ring #2
             {[8 8],[10 10],[14 14]}};   % core of ring #3
coreIndex = {{n1,n2,n3},... % core of ring #1 with 3 different core zones defining the indices of inner core and trench
             {n1,n2,n3},... % core of ring #2
             {n1,n2,n3}};   % core of ring #3
claddingIndex = n2;
ringRadius = {0,20,40}; % radius of each core ring at the section begin

options.RingRadiusEnd = {0,5,5}; % radius of each core ring at the section end
options.PowerCenter = 'core';
options.PowerAreaSize = [14 14];

waveguide{1} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);
sectionclear('KeepVariables',commonVariables)

%% Section 2 (multimode singlecore fiber with trench)
len = 1000;

coreWidth = {[18 18],[20 20],[24 24]};
coreIndex = {n1,n2,n3};
claddingIndex = n2;

options.Index3DStep = 100; % decrease the number of 3D index contour samples for a straight waveguide section by taking a sample only every 100 Steps
options.PowerCenter = 'core';
options.PowerAreaSize = [24 24];

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

end
