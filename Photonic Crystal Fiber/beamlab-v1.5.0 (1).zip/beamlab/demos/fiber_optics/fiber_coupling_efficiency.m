function bpmData = fiber_coupling_efficiency
%FIBER_COUPLING_EFFICIENCY - Coupling efficiency of a Gaussian beam to a fiber's fundamental mode
%
%   This BeamLab demo shows the coupling of a Gaussian beam to a multimode
%   fiber and calculates the coupling efficiency to the fiber's three
%   lowest-order modes. The Gaussian beam is laterally offset from the
%   fiber axis by half the fiber's core radius.
%
%   FIBER_COUPLING_EFFICIENCY
%   bpmData = FIBER_COUPLING_EFFICIENCY

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [100 100]; % resolution in x- and y-direction
gridSize = [50 50]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.55; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
width = [10 10]; % width of beam waist in x- and y-direction (unit is defined by optional parameter LengthUnit)
inputOptions.Shift = [3 0 100]; % beam waist is shifted by 3 um in positive x-direction and by 100 um in positive z-direction (i.e., propagation direction)
inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions); % create Gaussian beam

%% Optional parameters
% General optional parameters
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = [0.99*getindex('SiO2',lambda) 0.5*(getindex('SiO2',lambda) + getindex('SiO2',lambda,'Delta',0.68))]; % display index contours at the input plane of the fiber and at the core-cladding interface

% Optional parameters for bpmsolver
options.Sections = 1:2;
options.Step = 1; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.SlicesXY = 100; % display x-y slice distribution at z = 100 and save it in bpmData (needed for evaluation of coupling efficiency)
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit)
options.Monitor = true; % monitor propagating field
options.PlotOutputField = true; % plot output field

% Optional parameters for modesolver
options.ModeSections = 2; % use section 2 of the propagation structure to calculate the fundamental mode
options.ModeNumber = 3; % calculate the three lowest-order modes

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem); % display both 2D and 3D index distributions

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

%% Start mode solver calculation
modeData = modesolver(beamProblem);

%% Calculate coupling efficiency
for k = 1:options.ModeNumber
    % The power coupling efficiency of each mode is given by the squared
    % modulus of the normalized overlap integral of the waveguide mode and
    % the field distribution at the waveguide input plane.
    couplingEfficiency = abs(beamoverlap(modeData.ModeSlicesXY.Modes(k).E,bpmData.SlicesXY.E))^2;
    fprintf('Coupling efficiency to mode %d: %0.1f%%\n',k,100*couplingEfficiency);
end

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
len = 100; % section length
index = 1; % refractive index

waveguide{1} = @(beamProblem) homogeneous(beamProblem,len,index);

%% Section 2
len = 1400; % section length
coreWidth = [12 12]; % core width
coreIndex = getmaterial('SiO2','Delta',0.68); % refractive index of the core
claddingIndex = getmaterial('SiO2'); % refractive index of the cladding

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex);

end
