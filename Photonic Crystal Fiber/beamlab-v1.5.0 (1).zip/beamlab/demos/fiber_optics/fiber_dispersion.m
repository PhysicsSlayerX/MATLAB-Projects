function dispersionData = fiber_dispersion
%FIBER_DISPERSION - Dispersion evaluation of an optical fiber.
%
%   This BeamLab demo calculates the dispersion characteristics of a fiber.
%   The scanning parameter can be either the normalized frequency V or the
%   wavelength lambda. Various curves can be plotted showing, e.g., the
%   effective refractive index, the normalized propagation constant, the
%   differential group delay, the mode field diameter or the dispersion 
%   parameter as a function of the normalized frequency or wavelength.
%
%   FIBER_DISPERSION
%   dispersionData = FIBER_DISPERSION

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [200 200]; % resolution in x- and y-direction
gridSize = [50 50]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_fiberstructure;

%% Optional parameters
options.Sections = 1; % set section number to either 1 or 2 depending on which fiber type should be calculated
options.ModeNumber = 10; % calculate the first 10 modes
options.VectorType = 'semi';
options.SymmetryX = true; % the index distribution in x-direction is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution in y-direction is symmetric with respect to the y-axis
options.LineWidth = 2; % set line width in all output plots
options.DispersionGraphType = {'BvsV','NeffvsV','AeffvsV'}; % plot normalized propagation constant and effective mode area against normalized frequency
options.DispersionScanType = 'normfreq'; % choose to scan normalized frequency according to the scan range given by DispersionScanVector
options.DispersionScanVector = linspace(2,5,16); % scan range

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,options); % create beamProblem

%% Start dispersion calculation
dispersionData = dispersionsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_fiberstructure

coreWidth = [10 10];
coreIndex = getmaterial('SiO2','Delta',0.7);
claddingIndex = getmaterial('SiO2');

options.SmoothingWidth = 1; % smooth index distribution at core-cladding boundary across 1 pixel
options.SmoothingLevel = 5; % use a 5-level gradation in the smoothing region

%% Section 1 - step-index fiber
waveguide{1} = @(beamProblem) singlecore(beamProblem,1,coreWidth,coreIndex,claddingIndex,options);

%% Section 2 - graded-index fiber
options.ProfileExponent = 1.95;
waveguide{2} = @(beamProblem) singlecore(beamProblem,1,coreWidth,coreIndex,claddingIndex,options);

end
