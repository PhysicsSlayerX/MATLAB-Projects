function bpmData = fiber_loop
%FIBER_LOOP - Beam propagation through a fiber loop.
%
%   This BeamLab demo shows propagation of the fundamental mode of a fiber
%   through a fiber loop.
%
%   FIBER_LOOP
%   bpmData = FIBER_LOOP

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [150 100]; % resolution in x- and y-direction
gridSize = [30 20]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 1.55; % wavelength (unit is defined by optional parameter LengthUnit, default unit is um)
indexFunction = get_propstruct; % define propagation structure
inputField = @(beamProblem) modeinput(beamProblem); % define input field (fundamental mode)

%% Optional parameters
% General optional parameters
options.SymmetryX = false; % the index distribution is asymmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.IndexContour = 'all'; % display index contours in all plots

% Optional parameters for bpmsolver
options.Sections = 1:3; % use sections 1 to 3
options.Step = 1; % step size in z-direction (unit is defined by optional parameter LengthUnit)
options.SlicesXZ = 0; % display the intensity distribution of the x-z plane at y = 0 (unit is defined by optional parameter LengthUnit)
options.Monitor = true; % monitor propagating field
options.MonitorStep = 20; % refresh the monitor every 20 Steps
options.PowerTrace = 'continuous'; % continuously trace the power
options.ShowSectionBoundaries = true; % show all section boundaries as dashed lines in x-z slice plots
options.ShowSectionTitles = true; % show section titles in monitor plots
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScanner = false; % do not scan the index distribution (i.e., generate only x-y index slice)
options.Index3D = false; % do not generate 3D index contour
options.IndexSlicesXY = 0; % display x-y index distribution at z = 0

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem); % display x-y index slice

%% Start BPM calculation
[bpmData,~,figureHandles] = bpmsolver(beamProblem);

axes(figureHandles.SlicesXZ.Axes);
text(1.67,-12,'Single fiber loop','Color','white','HorizontalAlignment','center');

end

%% Propagation structure
function waveguide = get_propstruct

% parameters common to all sections
coreIndex = getmaterial('SiO2','Delta',2); % refractive index of the core
claddingIndex = getmaterial('SiO2'); % refractive index of the cladding
coreWidth = [8 8]; % core width
options.Shift = [-5 0]; % shift core center by 5 um in negative x-direction
options.PowerAreaSize = 2*coreWidth; % width of area used for power evaluation

%% Section 1 (straight fiber)
len = 100; % section length
options.SectionTitle = 'straight fiber';

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

%% Section 2 (single fiber loop)
options.BendRadius = 0.5e3; % set bending radius to 0.5 mm
len = 2*pi*options.BendRadius; % section length
options.SectionTitle = 'single fiber loop';

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

%% Section 3 (straight fiber)
len = 1000; % section length
options.BendRadius = Inf; % reset bending radius to infinity
options.SectionTitle = 'straight fiber';

waveguide{3} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

end
