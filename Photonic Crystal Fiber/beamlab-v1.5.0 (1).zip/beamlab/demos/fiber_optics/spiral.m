function bpmData = spiral
%SPIRAL - Beam propagation in a waveguide wrapped around a straight waveguide.
%
%   This BeamLab demo shows the behavior of the mode field when a waveguide
%   that is wrapped around a straight waveguide changes to a parallel
%   waveguide.
%
%   SPIRAL
%   bpmData = SPIRAL

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [120 120]; % resolution in x- and y-direction
gridSize = [60 60]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
width = [10 10]; % width of beam waist in x- and y-direction
inputOptions.Shift = [15 0 0]; % shift of beam waist in x-, y-, and z-direction
inputField = @(beamProblem) gaussinput(beamProblem,width,inputOptions);

%% Optional parameters
% General optional parameters
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = 'tbc'; % use a TBC boundary in y-direction (default)

% Optional parameters for bpmsolver
options.Step = 4; % step size in z-direction
options.SlicesXY = 0; % display x-y distributions at z = 0
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distribution (default)
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXZ = 0; % display the x-z intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.SlicesYZ = 0; % display the y-z intensity distribution at x = 0 and save it in bpmData
options.SlicesYZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all y-z plots
options.SlicesYZRange = [-20 0]; % use a range from -20 to 0 dB for all y-z plots
options.SlicesXZYZStep = 10; % intensity samples are taken every 10 Steps for generating the intensity distribution of the x-z and y-z slices 
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = 'Int2D'; % display the intensity distribution of the propagating field
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.Format = 1; % display distance z with 1 digits after the decimal point
options.IndexContour = 'all'; % display index contours in all plots
options.Video = true; % generate video file
options.VideoFilename = 'spiral_video'; % name of video file (the file is saved in the working directory)
options.VideoProfile = 'MPEG-4'; % video profile
options.VideoFrameRate = 30; % frame rate
options.IndexScannerStep = 250; % display the index distribution every 250 Steps
options.Index3DStep = 50; % take index samples every 50 Steps for the 3D index contour
options.Index3DAspectRatio = [1 1 20];
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Visualize input field
inputplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreWidthBase = [10 10]; % maximum core extensions in x- and y-direction
coreIndexBase = getmaterial('SiO2','Delta',0.35);
claddingIndexBase = getmaterial('SiO2');

%% Section 1
len = 400; % length of section

options.Shift = [15 0]; % amount of core shift in x- and y-direction

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidthBase,coreIndexBase,claddingIndexBase,options);
clear options;

%% Section 2
len = 4100;
coreNumber{1} = 1; % number of cores in ring #1
coreNumber{2} = 1; % number of cores in ring #2
ringRadius{1} = 0; % radius of ring #1 (a radius of 0 denotes the center core)
ringRadius{2} = 15; % radius of ring #2

options.RingAngleOffset{1} = 0; % angular offset of cores in ring #1 from the x-axis (at section begin)
options.RingAngleOffsetEnd{1} = 0; % angular offset of cores in ring #1 from the x-axis at section end
options.RingAngleOffset{2} = 0; % angular offset of cores in ring #2 from the x-axis (at section begin)
options.RingAngleOffsetEnd{2} = 540; % angular offset of cores in ring #2 from the x-axis at section end (if unequal the angular offset at the section begin all cores in this ring will be rotated by this amount)
options.Step = 2; % override corresponding beamProblem option and use a step width of 2 in z-direction
options.IndexScannerStep = 100; % override corresponding beamProblem option and display the index distribution every 100 Steps in this section
options.Index3DStep = 5; % override corresponding beamProblem option and take index samples every 25 Steps for the 3D index contour of this section

waveguide{2} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidthBase,coreIndexBase,claddingIndexBase,ringRadius,options);
clear options;

%% Section 3
len = 3000;
coreNumber{1} = 1;
coreNumber{2} = 1;
ringRadius{1} = 0;
ringRadius{2} = 15;

options.RingAngleOffset{1} = 0;
options.RingAngleOffset{2} = 180;

waveguide{3} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidthBase,coreIndexBase,claddingIndexBase,ringRadius,options);

end

%% For reference purposes, the most compact way of defining the same propagation structure is given below

% function waveguide = get_waveguide
% 
% waveguide{1} = @(beamProblem) singlecore(beamProblem,400,[10 10],1.455,1.45,'Shift',[15 0]);
% waveguide{2} = @(beamProblem) multicore(beamProblem,4100,{1,1},[10 10],1.455,1.45,{0,15},'RingAngleOffset',{0,0},'RingAngleOffsetEnd',{0,540},'Step',2,'IndexScannerStep',100,'Index3DStep',5);
% waveguide{3} = @(beamProblem) multicore(beamProblem,3000,{1,1},[10 10],1.455,1.45,{0,15},'RingAngleOffset',{0,180});
% 
% end
