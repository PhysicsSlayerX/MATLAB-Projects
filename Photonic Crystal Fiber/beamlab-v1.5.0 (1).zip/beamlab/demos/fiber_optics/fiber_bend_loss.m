function bendLoss = fiber_bend_loss
%FIBER_BEND_LOSS - Calculation of the propagation loss in a bent fiber.
%
%   This BeamLab demo calculates the bend loss of the first three
%   eigenmodes of an optical fiber with a bending radius of 10 cm
%   as a function of wavelength.
%
%   FIBER_BEND_LOSS
%   bendLoss = FIBER_BEND_LOSS

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [250 250]; % resolution in x- and y-direction
gridSize = [100 100]; % width in um of calculation area in x- and y-direction
indexFunction = get_waveguide; % define waveguide geometry

%% Optional parameters
options.VectorType = 'semi'; % use the full-vectorial mode solver
options.BoundaryX = 'pml1'; % use a PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a PML boundary in y-direction
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.ModeNumber = 20; % calculate the first 20 modes of the waveguide defined by indexFunction (when calculating the modes of a bent waveguide a sufficiently high mode number needs to be chosen to guarantee inclusion of the propagating modes)
options.ModeSortingOrder = 'imag'; % order the modes according to increasing imaginary part of the effective
options.SuppressPlots = true; % suppress all plots
options.CommandLineVerbosityLevel = 0; % disable all command-line output

%% Initializations
nom = 3; % number of modes to be taken into account
lambdaVector = linspace(1.1,1.15,6);
bendLoss = zeros(nom,length(lambdaVector));

for k = 1:length(lambdaVector)
    lambda = lambdaVector(k);
    disp(['Current evaluation at lambda = ' num2str(lambda) ' um']);
    
    %% Create beamProblem
    beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,options);
    
    %% Start mode solver calculation
    [~,effectiveIndex] = modesolver(beamProblem);
    neff = effectiveIndex{1}(1:nom); % use the first three modes for the loss calculations
    bendLoss(:,k) = -10*log10(exp(-2*pi/lambda*abs(imag(neff))*1e6)); % bend loss in dB/m
end

figure;
plot(lambdaVector,bendLoss.','o-');
grid on;
box on;
title('Bend loss vs wavelength');
xlabel('Wavelength / \mum');
ylabel('Bend loss / dB/m');
legend('Mode 1','Mode 2', 'Mode 3','Location','northwest');

end

%% Propagation structure
function waveguide = get_waveguide

len = 1;
coreWidth = [8 8]; % maximum core extensions in x- and y-direction
coreIndex = getmaterial('SiO2','Delta',0.35); % refractive index of core
claddingIndex = getmaterial('SiO2'); % refractive index of cladding

options.BendRadius = 100e3; % bending radius of the waveguide

waveguide = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

end
