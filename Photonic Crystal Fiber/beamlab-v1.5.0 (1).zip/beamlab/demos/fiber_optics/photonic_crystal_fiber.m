function bpmData = photonic_crystal_fiber
%PHOTONIC_CRYSTAL_FIBER - Beam propagation in a photonic crystal fiber.
%
%   This BeamLab demo shows the beam propagation through a photonic crystal
%   fiber when illuminating its input facet with a Gaussian beam.
%
%   PHOTONIC_CRYSTAL_FIBER
%   bpmData = PHOTONIC_CRYSTAL_FIBER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [300 300]; % resolution in x- and y-direction
gridSize = [60 60]; % width in um of calculation area in x- and y-direction
lambda = 1.55; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
width = [10 10]; % width of beam waist in x- and y-direction
inputField = @(beamProblem) gaussinput(beamProblem,width); % create Gaussian input field

%% Optional parameters
options.Sections = 1;
options.Step = 1; % set step size in z-direction to 1 um
options.VectorType = 'semi'; % use a semi-vectorial BPM or mode solver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = [1.4 1.48]; % display the index contours of core and inner cladding
options.Monitor = true; % monitor propagating field
options.MonitorStep = 20; % refresh the monitor every 20 Steps
options.MonitorGraphType = 'Int2D'; % monitor the 2D intensity distribution
options.SlicesXY = [0 Inf]; % display x-y distributions at z = 0 and of the last slice
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.PowerTrace = 'continuous'; % continuously trace the power
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.LineWidth = 1; % use a line width of 1 for graphs
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScanner = false; % do not scan the index distribution (i.e., generate only x-y index slice and 3D index contour)
options.IndexSlicesXY = 0; % display x-y index distribution at z = 0

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem); % display x-y index slice and generate 3D index contour plot

%% Visualize input field
inputplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

len = 1500; % section length
coreNumber{1} = 6; % number of cores in ring #1
coreNumber{2} = 6; % number of cores in ring #2
coreNumber{3} = 6; % number of cores in ring #3
coreWidth{1} = [4 4]; % core width for all cores in ring #1
coreWidth{2} = [4 4]; % core width for all cores in ring #2
coreWidth{3} = [4 4]; % core width for all cores in ring #3
coreIndex = 1; % refractive index of core
claddingIndex = 1.5; % refractive index of outer cladding
ringRadius{1} = 10; % radius of ring #1 at section begin
ringRadius{2} = 10*sqrt(3); % radius of ring #2 at section begin
ringRadius{3} = 20; % radius of ring #3 at section begin

options.RingAngleOffset{1} = 0; % angular offset from x-axis of cores in ring #1
options.RingAngleOffset{2} = 30; % angular offset from x-axis of cores in ring #2
options.RingAngleOffset{3} = 0; % angular offset from x-axis of cores in ring #3
options.InnerCladdingWidth = [55 55]; % maximum extensions in x- and y-direction of inner cladding
options.InnerCladdingIndex = 1.45; % refractive index of inner cladding
options.PowerAreaSize = [20 20]; % define integration area for power evaluation
options.PowerCenter = 'fixed'; % define center of integration area for power evaluation
options.SmoothingWidth = 2; % smooth index distribution at core-cladding boundary across 2 pixels
options.SmoothingLevel = 5; % use a 5-level gradation in the smoothing region

waveguide = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);

end
