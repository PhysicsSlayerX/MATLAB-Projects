function bpmData = fiber_collimator
%FIBER_COLLIMATOR - Beam propagation between two fiber collimators
%
%   This BeamLab demo shows how the use of GRIN lenses as fiber collimators 
%   can keep the coupling losses between two fibers low even for large
%   lateral offsets of the fiber axes by several core diameters.
%
%   FIBER_COLLIMATOR
%   bpmData = FIBER_COLLIMATOR

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [340 300]; % resolution in x- and y-direction
gridSize = [170 150]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.Sections = 1:9; % use sections 1 to 9
options.VectorType = 'semi'; % use a semi-vectorial modesolver and bpmsolver
options.SymmetryY = true; % the main field component (x-component by default) is symmetric with respect to the y-axis
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = 'tbc'; % use a TBC boundary in y-direction (default)
options.IndexContour = 'all'; % display index contours in all plots
options.IndexContourValues = 1.4525; % generate index contour at average value between core and cladding index

% Optional parameters for bpmsolver
options.Step = 2; % step size in z-direction
options.SlicesXY = [0 1000]; % display x-y distributions at z = 0 and 1 mm
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distribution
options.SlicesXYScale = 'logmax'; % use a logarithmic scale normalized to the maximum intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXZ = 0; % display the x-z intensity distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'logmax'; % use a logarithmic scale normalized to the maximum intensity for all x-z plots
options.SlicesXZRange = [-30 0]; % use a range from -30 to 0 dB for all x-z plots
options.SlicesXZYZStep = 5; % intensity samples are taken every 20 Steps for generating the intensity distribution of all x-z and y-z plots 
options.Monitor = true; % monitor propagating field
options.MonitorStep = 25; % refresh the monitor every 25 Steps
options.MonitorGraphType = 'Int2D'; % display the intensity distribution of the propagating field
options.MonitorScale = 'logmax'; % use a logarithmic scale normalized to the maximum intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.PowerTrace = 'laststep';% calculate the power of last calculation step
options.ShowSectionTitles = true; % show section titles in monitor plots
options.SectionTitlePosition = [0.5 0.8]; % position of section titles in monitor plots
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 50; % display the index distribution every 50 Steps
options.Index3D = false; % do not generate 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Visualize input field
inputplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreWidth = [10 10]; % maximum core extensions in x- and y-direction
coreIndex = getmaterial('SiO2','Delta',0.35);
claddingIndex = getmaterial('SiO2');

%% Section 1
len = 200; % length of section

options.Step = 10; % user larger Step size for calculating the field in sections where the field does not change much
options.Shift = [-10 0]; % amount of core shift in x- and y-direction
options.IndexScannerStep = 10;
options.SectionTitle = 'fiber';

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
clear options;

%% Section 2
len = 10;
lensWidth = [140 140];
innerIndex = 1.5;
gradientConstant = pi/2000;

options.Step = 0.1; % use smaller Step size for calculating the field distribution and index contour in the vicinity of a transition with higher precision
options.OuterIndex = 1;
options.Shift = [-10 0];
options.SectionTitle = 'grinlens';

waveguide{2} = @(beamProblem) grinlens(beamProblem,len,lensWidth,innerIndex,gradientConstant,options);
clear options;

%% Section 3
len = 990;
lensWidth = [140 140];
innerIndex = 1.5;
gradientConstant = pi/2000;

options.OuterIndex = 1;
options.Shift = [-10 0];

waveguide{3} = @(beamProblem) grinlens(beamProblem,len,lensWidth,innerIndex,gradientConstant,options);
clear options;

%% Section 4
len = 10; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

options.Step = 0.1;
options.PowerAreaSize = [140 140];
options.SectionTitle = 'free space';

waveguide{4} = @(beamProblem) homogeneous(beamProblem,len,index,options); % homogeneous section
clear options;

%% Section 5
len = 990; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

options.Step = 8;
options.PowerAreaSize = [140 140];
options.SectionTitle = 'free space';

waveguide{5} = @(beamProblem) homogeneous(beamProblem,len,index,options); % homogeneous section
clear options;

%% Section 6
len = 10;
lensWidth = [140 140];
innerIndex = 1.5;
gradientConstant = pi/2000;

options.Step = 0.1;
options.OuterIndex = 1;
options.Shift = [10 0];
options.SectionTitle = 'grinlens';

waveguide{6} = @(beamProblem) grinlens(beamProblem,len,lensWidth,innerIndex,gradientConstant,options);
clear options;

%% Section 7
len = 990;
lensWidth = [140 140];
innerIndex = 1.5;
gradientConstant = pi/2000;

options.OuterIndex = 1;
options.Shift = [10 0];
options.SectionTitle = 'grinlens';

waveguide{7} = @(beamProblem) grinlens(beamProblem,len,lensWidth,innerIndex,gradientConstant,options);
clear options;

%% Section 8
len = 10; % length of section

options.Step = 0.1;
options.Shift = [10 0]; % amount of core shift in x- and y-direction
options.SectionTitle = 'fiber';

waveguide{8} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
clear options;

%% Section 9
len = 990; % length of section

options.Shift = [10 0]; % amount of core shift in x- and y-direction
options.PowerAreaSize = 2*coreWidth;
options.PowerAreaType = 'elliptical';
options.SectionTitle = 'fiber';

waveguide{9} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);

end
