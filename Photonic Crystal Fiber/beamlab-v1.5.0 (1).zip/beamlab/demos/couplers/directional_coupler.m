function bpmData = directional_coupler
%DIRECTIONAL_COUPLER - Beam propagation in a co-directional waveguide coupler.
%
%   This BeamLab demo shows the coupling between the LP01 mode of a
%   single-mode circular waveguide to the LP11 mode of a multi-mode
%   circular waveguide. First, the LP01 mode of the single-mode waveguide
%   is calculated and used as input for the following BPM simulation.
%   During the beam propagation the LP01 mode of the single-mode waveguide
%   couples to the LP11 mode of an adjacent multi-mode waveguide.
%
%   DIRECTIONAL_COUPLER
%   bpmData = DIRECTIONAL_COUPLER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [160 80]; % resolution in x- and y-direction
gridSize = [80 40]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputOptions.ModeCore = 1; % use waveguide core 1 for the eigenmode calculation of the input field distribution
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.VectorType = 'semi'; % use a semi-vectorial mode- and bpmsolver
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distribution in all x-y slice plots
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXYStacked = 6; % display 6 x-y distributions equidistantly spaced between z = 0 and waveguide end as stacked plots in a separate figure
options.IndexContour = 'all'; % display index contours in all plots
options.LineColor = [0.5 0 0.5]; % use purple as line color in figures with a single graph
options.LineWidth = 1; % use a line width of 1 for graphs

% Optional parameters for bpmsolver
options.Step = 5; % set step size in z-direction to 5 um
options.Monitor = true; % monitor propagating field
options.MonitorStep = 10; % refresh the monitor every 10 Steps, i.e., every 50 um
options.MonitorGraphType = {'Int3D','Int1Dx0'}; % monitor the 3D intensity distribution and 1D intensity distribution at x = 0
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for monitor plots
options.SlicesXZ = 0; % display x-z slice distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.SlicesXZYZStep = 10; % for x-z and y-z plots take intensity samples every 10 Steps
options.PowerTrace = 'continuous'; % trace power continuously
options.PowerTraceStep = 2; % take power samples every 2 Steps
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 20; % display the index distribution every 20 Steps
options.Index3DStep = 2; % take index samples every 2 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreNumber = 2; % number of cores
coreWidthBase = [7.8 7.8]; % maximum core extensions in x- and y-direction
coreWidth{1} = coreWidthBase; % width of core 1
coreWidth{2} = 2*coreWidthBase; % width of core 2
coreIndex = 1.4541; % core index
claddingIndex = 1.45; % cladding index

options.CoreShapeFactor = 2; % use elliptical (circular) cores
options.PowerAreaSize = {2*coreWidthBase,3*coreWidthBase};% define maximum extensions in x- and y-direction for power evaluation
options.PowerAreaType = 'elliptical'; % use a circular area with a diameter of 16 um surrounding the core for power evaluation
options.PowerCenter = 'core'; % define center of integration area for power evaluation

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 100;

options.Shift{1} = [20 0]; % lateral shift of core 1 at section begin
options.Shift{2} = [-20 0]; % lateral shift of core 2 at section begin

waveguide{1} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 2
len = 1500;

options.Shift{1} = [20 0]; % lateral shift of core 1 at section begin
options.Shift{2} = [-20 0]; % lateral shift of core 2 at section begin
options.ShiftEnd{1} = [-2 0]; % lateral shift of core 1 at section end
options.ShiftEnd{2} = [-20 0]; % lateral shift of core 2 at section end

waveguide{2} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 4000;

options.Shift{1} = [-2 0];
options.Shift{2} = [-20 0];
options.IndexScannerStep = 100; % override corresponding beamProblem option and display the index distribution every 100 Steps in this section
options.Index3DStep = 100; % override corresponding beamProblem option and take index samples every 100 Steps for generating the 3D index contour of this section

waveguide{3} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 4
len = 1500;

options.Shift{1} = [-2 0];
options.Shift{2} = [-20 0];
options.ShiftEnd{1} = [20 0];
options.ShiftEnd{2} = [-20 0];

waveguide{4} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 5
len = 200;

options.Shift{1} = [20 0];
options.Shift{2} = [-20 0];

waveguide{5} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);

end

%% For reference purposes, the most compact way of defining the same propagation structure is given below

% function waveguide = get_waveguide
% 
% waveguide{1} = @(beamProblem) plc(beamProblem, 100,2,{[7.8 7.8],[15.6 15.6]},1.4541,1.45,'CoreShapeFactor',2,'PowerAreaSize',{2*[7.8 7.8],3*[7.8 7.8]},'Shift',{[20 0],[-20 0]});
% waveguide{2} = @(beamProblem) plc(beamProblem,1500,2,{[7.8 7.8],[15.6 15.6]},1.4541,1.45,'CoreShapeFactor',2,'PowerAreaSize',{2*[7.8 7.8],3*[7.8 7.8]},'Shift',{[20 0],[-20 0]},'ShiftEnd',{[-2 0],[-20 0]});
% waveguide{3} = @(beamProblem) plc(beamProblem,4000,2,{[7.8 7.8],[15.6 15.6]},1.4541,1.45,'CoreShapeFactor',2,'PowerAreaSize',{2*[7.8 7.8],3*[7.8 7.8]},'Shift',{[-2 0],[-20 0]},'IndexScannerStep',100,'Index3DStep',100);
% waveguide{4} = @(beamProblem) plc(beamProblem,1500,2,{[7.8 7.8],[15.6 15.6]},1.4541,1.45,'CoreShapeFactor',2,'PowerAreaSize',{2*[7.8 7.8],3*[7.8 7.8]},'Shift',{[-2 0],[-20 0]},'ShiftEnd',{[20 0],[-20 0]});
% waveguide{5} = @(beamProblem) plc(beamProblem, 200,2,{[7.8 7.8],[15.6 15.6]},1.4541,1.45,'CoreShapeFactor',2,'PowerAreaSize',{2*[7.8 7.8],3*[7.8 7.8]},'Shift',{[20 0],[-20 0]});
% 
% end
