function [optimalWaveguideParameters,outputPower] = mmi_coupler_2d_optim
%MMI_COUPLER_2D_OPTIM - Beam propagation in a 2D MMI coupler with optimization.
%
%   This BeamLab demo shows how to solve a simple optimization problem
%   using the MATLAB function fminsearch in conjunction with a BPM
%   calculation. The LP01 mode of the input single-mode waveguide is used
%   as input for the beam propagation simulation. During the beam
%   propagation the LP01 mode spreads into the multimode waveguide
%   structure and starts to interfere with its reflection from the
%   waveguide boundaries. The function fminsearch simultaneously searches
%   for the optimum length of the multimode waveguide structure and optimum
%   core distance of the two output waveguides for which the power coupled
%   into each output waveguide is maximized.
%
%   MMI_COUPLER_2D_OPTIM
%   [optimalWaveguideParameters,outputPower] = MMI_COUPLER_2D_OPTIM

%   Copyright 2017-2018 CodeSeeder

close all;

%% Default values of parameters to be optimized
defaultLengthOfSection2 = 5100; % default value of the first parameter to be optimized
defaultRingRadiusOfSection3 = 26; % default value of the second parameter to be optimized

%% Required parameters
gridPoints = [240 1]; % resolution in x- and y-direction (for a 2D calculation the resolution in y-direction is set to 1)
gridSize = [120 1]; % width in um of calculation area in x- and y-direction (for a 2D calculation the width in y-direction is set to 1)
lambda = 1.55; % wavelength in um

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % 1 mW input power
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.Sections = 1:3; % use sections 1 to 3 as propagation structure
options.VectorType = 'semi'; % use the semi-vectorial mode solver
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = 'tbc'; % use a TBC boundary in y-direction (default)
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis

% Optional parameters for bpmsolver
options.Step = 2; % set step size in z-direction to 2 um
options.PowerTrace = 'laststep'; % calculate and display the power of the final simulation step only
options.CommandLineVerbosityLevel = 0; % disable all command-line output

%% Start parameter sweep in conjunction with BPM calculation
initialGuess = [defaultLengthOfSection2 defaultRingRadiusOfSection3]; % start point of optimization
optimizationOptions = optimset('MaxIter',10,...
    'Display','iter');

% The MATLAB function fminsearch finds the minimum of a function. Since we
% are interested in the maximum of the output power (returned by the
% objective function get_output_power), we need to add a minus sign in
% front of get_output_power.
[optimalWaveguideParameters,outputPower] = ...
    fminsearch(@(x) -get_output_power(x,gridPoints,gridSize,lambda,inputField,options),...
    initialGuess,...
    optimizationOptions);

outputPower = -outputPower; % The sign of the output power need to be changed back, see comment above.

fprintf('Optimal waveguide length of section 2: %g mm\n',optimalWaveguideParameters(1)/1000);
fprintf('Optimal ring radius of section 3: %g um\n',optimalWaveguideParameters(2));
fprintf('Maximum output power at optimal waveguide length: %g mW\n',outputPower*1000);

end

%% Propagation structure
function waveguide = get_waveguide(lengthOfSection2,ringRadiusOfSection3)

%% Waveguide parameters common to all sections
claddingIndex = 1.45;
coreIndex = 1.455;

options.CoreShapeFactor = Inf; % use rectangular (square) cores
options.PowerAreaSize = [16 1]; % define integration area for power evaluation
options.PowerCenter = 'core'; % define integration center for power evaluation

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 300;
coreWidth = [10 10];

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 2
len = lengthOfSection2; % length of section (to be optimized)
coreWidth = [100 10];

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 1000;
coreNumber = 2; % number of cores in first core ring
coreWidth = [10 10]; % maximum core extensions in x- and y-direction of all cores in first core ring
ringRadius{1} = ringRadiusOfSection3; % ring radius of first core ring (to be optimized)

waveguide{3} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);

end

%% Objective function
function outputPower = get_output_power(optimizationParameters,gridPoints,gridSize,lambda,inputField,options)

indexFunction = get_waveguide(optimizationParameters(1),optimizationParameters(2)); % define waveguide geometry with parameters to be optimized
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options); % create beamProblem
bpmData = bpmsolver(beamProblem); % start BPM calculation

outputPower = bpmData.Power.Values; % return output power at end of waveguide

end
