function bpmData = tapered_coupler
%TAPERED_COUPLER - Beam propagation in a tapered mode-selective coupler.
%
%   This BeamLab demo shows the coupling of the LP11 mode of a multi-mode 
%   waveguide to the LP01 mode of a single-mode waveguide by using 
%   counter-tapered waveguides.
%
%   TAPERED_COUPLER
%   bpmData = TAPERED_COUPLER

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [150 100]; % resolution in x- and y-direction
gridSize = [30 20]; % width of calculation area in x- and y-direction
lambda = 1.55; % wavelength
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % set input power to 1 mW
inputOptions.ModeSelect = 3; % use the third mode (LP11 mode)
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first-order mode as input field

%% Optional parameters
% General optional parameters
options.Sections = 1:4; % use sections 1 to 4 as propagation structure
options.VectorType = 'semi'; % use a semi-vectorial mode or BPM solver
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.BoundaryX = 'pml1'; % use a 1st order PML boundary in x-direction
options.BoundaryY = 'pml1'; % use a 1st order PML boundary in y-direction
options.IndexContour = 'all'; % display index contours in all plots

% Optional parameters for bpmsolver
options.Step = 2; % step size in z-direction
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = 'Int2D'; % display the 2D intensity distribution during monitoring
options.MonitorRange = 20; % use a range of 20 dB for all monitor plots
options.SlicesXY = [0 Inf]; % display the x-y distributions at z = 0 and at the waveguide end
options.SlicesXYGraphType = 'Int2D'; % display the 2D intensity distributions in all x-y-slice plots
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all intensity x-y plots
options.SlicesXYRange = 20; % use a range of 20 dB for all x-y plots
options.SlicesXZ = 0; % display x-z slice intensity distribution at y = 0
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-z plots
options.SlicesXZRange = 20; % use a range of 20 dB for all x-z plots
options.SlicesXZYZStep = 10; % for the x-z distribution take intensity samples every 10 Steps
options.PowerTrace = 'continuous'; % continuously trace the power
options.PowerTraceScale = 'lininput'; % display the power on a linear scale normalized to the power at the input
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.Output = true; % save output data to a mat file
options.OutputFilename = 'tapered_coupler_output'; % name of the file to which all input and output parameters are saved to
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 50; % display the index distribution every 50 Steps
options.Index3DStep = 20; % take index samples every 20 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreWidthBase = [4 4]; % maximum core extensions in x- and y-direction
coreIndex = 1.475; % core index
claddingIndex = 1.45; % cladding index

options.CoreShapeFactor = 4;
options.TaperTransition = 'linear'; % use a linear core taper
options.PowerCenter = 'core'; % define center of integration area for power evaluation (default)
options.PowerAreaTransition = 'linear'; % use a linear power transition
options.SmoothingWidth = 1; % smooth index distribution at core-cladding boundary across 1 pixel
options.SmoothingLevel = 5; % use a 5-level gradation in the smoothing region

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 200; % section length
coreNumber = 1; % number of cores
coreWidth = 2*coreWidthBase; % width of core 1

options.Shift = [5.2 0]; % lateral shift of core 1
options.PowerAreaSize = 1.2*coreWidth; % define integration area for power evaluation

waveguide{1} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 2
len = 3000; % section length
coreNumber = 2; % number of cores
coreWidth{1} = 2*coreWidthBase; % width of core 1 at section begin
coreWidth{2} = [0 0]; % width of core 2 at section begin

options.Shift{1} = [5.2 0];% lateral shift of core 1 at section begin
options.Shift{2} = [0 0];% lateral shift of core 2 at section begin
options.CoreWidthEnd{1} = 1.25*coreWidthBase; % width of core 1 at section end
options.CoreWidthEnd{2} = 0.75*coreWidthBase; % width of core 2 at section end
options.PowerAreaSize{1} = 1.2*coreWidth{1}; % define first integration area for power evaluation at section begin to be 20% larger than the core width
options.PowerAreaSize{2} = 2*coreWidth{2}; % define second integration area for power evaluation at section begin to be twice as large as the core width
options.PowerAreaSizeEnd{1} = 1.2*options.CoreWidthEnd{1}; % define first integration area for power evaluation at section end
options.PowerAreaSizeEnd{2} = 2*options.CoreWidthEnd{2}; % define second integration area for power evaluation at section end
options.Index3DStep = 5; % override corresponding beamProblem option and take index samples every 5 Steps for generating the 3D index contour of this section (finer resolution due to core bend)

waveguide{2} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 2000;
coreNumber = 2;
coreWidth{1} = 1.25*coreWidthBase;
coreWidth{2} = 0.75*coreWidthBase;

options.Shift{1} = [5.2 0];
options.Shift{2} = [0 0];
options.ShiftEnd{1} = [5.2 0];
options.ShiftEnd{2} = [-7.4 0];
options.CoreWidthEnd{1} = 0.75*coreWidthBase;
options.CoreWidthEnd{2} = 0.75*coreWidthBase;
options.PowerAreaSize{1} = 1.2*coreWidth{1}; % define first integration area for power evaluation at section begin
options.PowerAreaSize{2} = 2*coreWidth{2}; % define second integration area for power evaluation at section begin
options.PowerAreaSizeEnd{1} = 1.2*options.CoreWidthEnd{1}; % define first integration area for power evaluation at section end
options.PowerAreaSizeEnd{2} = 2*options.CoreWidthEnd{2}; % define second integration area for power evaluation at section end
options.Index3DStep = 5;

waveguide{3} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 4
len = 200;
coreNumber = 2;
coreWidth{1} = 0.75*coreWidthBase;
coreWidth{2} = 0.75*coreWidthBase;

options.Shift{1} = [5.2 0];
options.Shift{2} = [-7.4 0];
options.PowerAreaSize{1} = 1.2*coreWidth{1}; % define first integration area for power evaluation at section begin
options.PowerAreaSize{2} = 2*coreWidth{2}; % define second integration area for power evaluation at section begin

waveguide{4} = @(beamProblem) plc(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,options);

end
