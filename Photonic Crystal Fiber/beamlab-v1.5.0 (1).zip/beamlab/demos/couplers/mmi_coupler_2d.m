function bpmData = mmi_coupler_2d
%MMI_COUPLER_2D - Beam propagation in a 2D MMI coupler.
%
%   This BeamLab demo shows how a multimode interference coupler uniformly
%   distributes the light of a single-mode input waveguide to two output
%   waveguides. First, the exact LP01 mode of the input single-mode
%   waveguide is calculated and used as input for the beam propagation
%   simulation. During the beam propagation the LP01 mode spreads into a
%   multimode waveguide structure. The length of the multimode waveguide
%   structure is adjusted to maximize light coupling through the
%   self-imaging effect into the two output waveguides.
%
%   MMI_COUPLER_2D
%   bpmData = MMI_COUPLER_2D

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [240 1]; % resolution in x- and y-direction (for a 2D calculation the resolution in y-direction is set to 1)
gridSize = [120 1]; % width in um of calculation area in x- and y-direction (for a 2D calculation the width in y-direction is set to 1)
lambda = 1.55; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % 1 mW input power
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.Sections = 1:3; % use as propagation structure the sections in the order of 1 to 3
options.VectorType = 'semi'; % use a semi-vectorial BPM or mode solver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.IndexContour = 'all'; % display index contours in all plots
options.LineWidth = 1; % use a line width of 1 for all graphs

% Optional parameters for bpmsolver
options.Step = 1; % set step size in z-direction to 1 um
options.SlicesXY = [0 Inf]; % display the x-y distributions at z = 0 and the end of waveguide
options.SlicesXYGraphType = {'Int2D','Int1Dx0'}; % display the 2D intensity distribution and 1D intensity distribution at x = 0
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all x-y plots
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXZ = 0; % display the x-z slice distribution at y = 0 and save it in bpmData
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.SlicesXZYZStep = 20; % for the x-z plot take intensity samples every 20 Steps
options.Monitor = true; % monitor propagating field
options.MonitorStep = 50; % refresh the monitor every 50 Steps
options.MonitorGraphType = {'Int2D','Int1Dx0'}; % monitor the 2D intensity distribution and 1D intensity distribution at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots.
options.PowerTrace = 'continuous'; % continuously trace the power
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.Output = true; % save output data to a mat file
options.OutputFilename = 'mmi_coupler_2d_output'; % name of the file to which the output data is saved to
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScanner = true; % display the index distribution before mode calculation
options.IndexScannerStep = 200; % display the index distribution every 1000 Steps
options.Index3D = false; % do not generate 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreIndex = 1.455;
claddingIndex = 1.45;

options.CoreShapeFactor = Inf; % use rectangular (square) cores
options.PowerAreaSize = [16 1]; % define integration area for power evaluation
options.PowerCenter = 'core'; % define integration center for power evaluation

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 300; % length of section
coreWidth = [10 10]; % maximum core extensions in x- and y-direction

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 2
len = 5143;
coreWidth = [100 10];

options.IndexScannerStep = 500;

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 1000;
coreNumber = 2; % number of cores in first core ring
coreWidth = [10 10]; % maximum core extensions in x- and y-direction of all cores in first core ring
ringRadius = 26; % radius of first core ring

waveguide{3} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);
sectionclear('KeepVariables',commonVariables);

end
