function bpmData = mmi_coupler_3d
%MMI_COUPLER_3D - Beam propagation in a 3D MMI coupler.
%
%   This BeamLab demo shows how a multimode interference coupler uniformly
%   distributes the light of a single-mode input waveguide to two single-
%   mode output waveguides. First, the exact LP01 mode of the input
%   single-mode waveguide is calculated and used as input for the beam
%   propagation simulation. During the beam propagation the LP01 mode then
%   spreads into the multimode waveguide. At a certain distance the
%   multimode waveguide efficiently couples light into the two output
%   waveguides by means of interference with the light reflected from the
%   waveguide boundary.
%
%   MMI_COUPLER_3D
%   bpmData = MMI_COUPLER_3D

%   Copyright 2017-2018 CodeSeeder

close all;

%% Performance mode
% The parameter settings of this demo are not optimized for speed but
% rather for making it as easy as possible for you to learn how to use
% BeamLab. The following parameter performanceMode is a switch for
% optimizing the performance of a beam propagation simulation. When set to
% true, the refractive index scan and field monitor functions will be
% turned off all together independent of the settings in the parameters
% IndexScanner, Index3D, and Monitor. Further guidelines how to optimize
% the simulation performance can be found in the BeamLab documentation by
% executing "beamlabdoc simulation_performance" in the command-line
% interface.
performanceMode = false;

%% Required parameters
gridPoints = [240 80]; % resolution in x- and y-direction
gridSize = [120 40]; % width in um of calculation area in x- and y-direction
lambda = 1.55; % wavelength in um
indexFunction = get_waveguide; % define waveguide geometry

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % 1 mW input power
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.VectorType = 'semi'; % use a semi-vectorial BPM or mode solver
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SymmetryY = true; % the index distribution is symmetric with respect to the y-axis
options.LineWidth = 1; % use a line width of 1 for all graphs

% Optional parameters for bpmsolver
options.Sections = 1:3; % use sections 1 to 3 as propagation structure
options.Step = 2; % set step size in z-direction to 2 um
options.SlicesXY = 0; % display the x-y slice distribution at z = 0
options.SlicesXYGraphType = {'Int2D','Int1Dx0'}; % display the 2D intensity distribution and 1D intensity distribution at x = 0
options.SlicesXYScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity
options.SlicesXYRange = [-20 0]; % use a range from -20 to 0 dB for all x-y plots
options.SlicesXZ = 0; % display the x-z slice distribution at y = 0
options.SlicesXZScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity
options.SlicesXZRange = [-20 0]; % use a range from -20 to 0 dB for all x-z plots
options.SlicesXZYZStep = 20; % for the x-z plot take intensity samples every 20 Steps
options.Monitor = true; % monitor field changes during propagation
options.MonitorStep = 25; % refresh the monitor every 25 Steps
options.MonitorGraphType = {'Int2D','Int1Dx0'}; % display the 2D intensity distribution and 1D intensity distribution at x = 0
options.MonitorScale = 'loginput'; % use a logarithmic scale normalized to the maximum input intensity for all monitor plots
options.MonitorRange = [-20 0]; % use a range from -20 to 0 dB for all monitor plots
options.PowerTrace = 'continuous'; % continuously trace the power
options.PowerTraceStep = 5; % take power samples every 5 Steps
options.IndexContour = 'all'; % display index contours in all slice plots
options.IndexContourLineColor = [0 0 0];% use black index contour lines
options.IntensityContour = 'all'; % display intensity contours in all slice plots
options.IntensityContourOnly = true; % display only intensity contours
options.PerformanceMode = performanceMode; % switch for optimizing the performance of the BPM simulation (turns off refractive index scan and field monitor)

% Optional parameters for indexplot
options.IndexScannerStep = 50; % display the index distribution at every 50 Steps
options.Index3DStep = 50; % take index samples every 50 Steps for the 3D index contour

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem);

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_waveguide

%% Waveguide parameters common to all sections
coreIndex = 1.455;
claddingIndex = 1.45;

options.CoreShapeFactor = Inf; % use rectangular (square) cores
options.PowerAreaSize = [16 16]; % define integration area for power evaluation
options.PowerCenter = 'core'; % define integration center for power evaluation

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 300; % length of section
coreWidth = [10 10]; % maximum core extensions in x- and y-direction

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 2
len = 5150;
coreWidth = [100 10];

options.IndexScannerStep = 100;
options.Index3DStep = 100;

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables); % clear all variables except for commonVariables

%% Section 3
len = 1050;
coreNumber = 2; % number of cores in first core ring
coreWidth = [10 10]; % maximum core extensions in x- and y-direction of all cores in first core ring
ringRadius = 26; % ring radius of first core ring

waveguide{3} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);

end
