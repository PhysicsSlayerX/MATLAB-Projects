function powerData = mmi_coupler_2d_sweep_parallel
%MMI_COUPLER_2D_SWEEP_PARALLEL - Beam propagation in a 2D MMI coupler with parameter sweep.
%
%   This BeamLab demo shows how to do a simple parameter sweep in
%   conjunction with a BPM calculation. The MATLAB Parallel Computing
%   Toolbox is used for executing the parameter sweep in parallel. The LP01
%   mode of the input single-mode waveguide is used as input for the beam
%   propagation simulation. During the beam propagation the LP01 mode
%   spreads into the multimode waveguide structure and starts to interfere
%   with its reflection from the waveguide boundaries. The length of the
%   multimode waveguide structure is varied to find the optimum length for
%   maximum light coupling into the two output waveguides.
%
%   This demo requires the MATLAB Parallel Computing Toolbox.
%
%   MMI_COUPLER_2D_SWEEP_PARALLEL
%   powerData = MMI_COUPLER_2D_SWEEP_PARALLEL

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = [240 1]; % resolution in x- and y-direction (for a 2D calculation the resolution in y-direction is set to 1)
gridSize = [120 1]; % width in um of calculation area in x- and y-direction (for a 2D calculation the width in y-direction is set to 1)
lambda = 1.55; % wavelength in um

%% Input field for bpmsolver
inputOptions.Power = 1e-3; % 1 mW input power
inputField = @(beamProblem) modeinput(beamProblem,inputOptions); % use the first waveguide eigenmode as input field

%% Optional parameters
% General optional parameters
options.VectorType = 'semi'; % use the semi-vectorial mode solver
options.BoundaryX = 'tbc'; % use a TBC boundary in x-direction (default)
options.BoundaryY = 'tbc'; % use a TBC boundary in y-direction (default)
options.SymmetryX = true; % the index distribution is symmetric with respect to the x-axis
options.SuppressPlots = true; % suppress all plots

% Optional parameters for bpmsolver
options.Sections = 1:3; % use sections 1 to 3 as propagation structure
options.Step = 2; % set step size in z-direction to 2 um
options.PowerTrace = 'laststep'; % calculate and display the power of the final simulation step only
options.CommandLineVerbosityLevel = 0; % disable all command-line output

%% Start parameter sweep in conjunction with the BPM calculation
lengthValues = 5100:10:5200;

parfor k = 1:length(lengthValues)
    waveguideLength = lengthValues(k);
    
    indexFunction = get_waveguide(waveguideLength); % define waveguide geometry with parameter to be swept
    beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options); % create beamProblem
    bpmData = bpmsolver(beamProblem); % start BPM calculation
    
    powerValues(:,k) = bpmData.Power.Values;
    
    fprintf('waveguideLength = %g mm\n',waveguideLength/1000);
end

powerData.Length = lengthValues;
powerData.Values = powerValues;

figure;
plot(powerData.Length/1000,powerData.Values*1000,'o-'); % draw a figure showing the power as a function of waveguideLength
grid on;
box on;
xlim([lengthValues(1) lengthValues(end)]/1000);
xlabel('Length / mm');
ylabel('Coupling power / mW');

end

%% Propagation structure
function waveguide = get_waveguide(lengthOfSection2)

%% Waveguide parameters common to all sections
claddingIndex = 1.45;
coreIndex = 1.455;

options.CoreShapeFactor = Inf; % use rectangular (square) cores
options.PowerAreaSize = [16 1]; % define integration area for power evaluation
options.PowerCenter = 'core'; % define integration center for power evaluation

commonVariables = getcommonvars; % define variables which should not be cleared by sectionclear

%% Section 1
len = 300;
coreWidth = [10 10]; % maximum core extensions in x- and y-direction

waveguide{1} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 2
len = lengthOfSection2; % length of section (to be changed during parameter sweep)
coreWidth = [100 10];

waveguide{2} = @(beamProblem) singlecore(beamProblem,len,coreWidth,coreIndex,claddingIndex,options);
sectionclear('KeepVariables',commonVariables);

%% Section 3
len = 1000;
coreNumber{1} = 2; % number of cores in first core ring
coreWidth{1} = [10 10]; % maximum core extensions in x- and y-direction of all cores of first core ring
ringRadius{1} = 26; % ring radius of first core ring

waveguide{3} = @(beamProblem) multicore(beamProblem,len,coreNumber,coreWidth,coreIndex,claddingIndex,ringRadius,options);

end
