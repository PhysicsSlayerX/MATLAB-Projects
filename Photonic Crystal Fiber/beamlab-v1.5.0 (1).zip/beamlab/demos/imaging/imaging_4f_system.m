function bpmData = imaging_4f_system(filterType)
%IMAGING_4F_SYSTEM - Imaging through a two-lens system (4f optical system).
%
%   This BeamLab function is a BPM demo showing the imaging of an object
%   through a 4f optical system. The input parameter filterType allows one
%   to introduce two types of filter functions in the Fourier plane of this
%   system located at z = 2f according to the following scalars:
%   0: no filter
%   1: low-pass filter (high-frequency blocking by an aperture stop)
%   2: high-pass filter (low-frequency blocking by an opaque mask)
%
%   IMAGING_4F_SYSTEM
%   IMAGING_4F_SYSTEM(filterType)
%   bpmData = IMAGING_4F_SYSTEM(___)

%   Copyright 2017-2018 CodeSeeder

close all;

if nargin ~= 1
    filterType = 0; % no filter is used by default
end

%% Required parameters
gridPoints = 600*[1 1]; % resolution in x- and y-direction
gridSize = 600*[1 1]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 0.633; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct(filterType); % define propagation structure

%% Input field for bpmsolver
inputOptions.Rotation = 180; % rotate image by 180 degrees
inputField = @(beamProblem) imageinput(beamProblem,'wolf.png',inputOptions); % generate input field from image file

%% Optional parameters
options.Sections = [1 2 1 3 1 2 1]; % use as propagation structure the sections in the order of 1 -> 2 -> 1 -> 3 -> 1 -> 2 -> 1
options.SlicesXYStacked = 5; % display 5 x-y distributions equidistantly spaced between z = 0 and 8 mm as stacked plots in a single figure
options.SlicesXYScale = 'lininput'; % use a (non-normalized) linear scale
options.SlicesXYRange = [0 1]; % use a range from 0 to 1 for all x-y plots
options.Colormap = gray(256); % use a gray colormap
options.Shading2D = 'flat'; % use flat shading for all x-y plots

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem,'IndexScanner',false,'Index3D',false); % display x-y transmittance slice of thinaperture

%% Start BPM calculation
[bpmData,~,figureHandles] = bpmsolver(beamProblem);

view(figureHandles.SlicesXYStacked.Axes,[55 15]); % change viewpoint of stacked slices plot

end

%% Propagation structure
function waveguide = get_propstruct(filterType)

%% Section 1
len = 2000; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide{1} = @(beamProblem) fasthomogeneous(beamProblem,len,index); % create homogeneous section

%% Section 2
focalLength = len; % focal length (unit is defined by optional parameter LengthUnit)

waveguide{2} = @(beamProblem) thinlens(beamProblem,focalLength); % create lens of zero thickness

%% Section 3
switch filterType
    case 0
        apertureWidth = 600*[1 1]; % aperture width is the same as GridSize
        options.ApertureShapeFactor = Inf; % use a rectangular aperture
    case 1
        apertureWidth = 50*[1 1]; % width of aperture
        options.TransmittanceSlicesXY = true; % plot thinaperture transmittance
    case 2
        apertureWidth = 4*[1 1]; % width of aperture
        options.ApertureShapeFactor = Inf; % use a rectangular aperture
        options.ApertureInverse = true; % convert aperture into opaque mask
        options.TransmittanceSlicesXY = true; % plot thinaperture transmittance
    otherwise
        error('Wrong filterType value.');
end

waveguide{3} = @(beamProblem) thinaperture(beamProblem,apertureWidth,options); % aperture of zero thickness

end
