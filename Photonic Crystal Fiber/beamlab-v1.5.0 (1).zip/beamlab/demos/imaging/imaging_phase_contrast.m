function bpmData = imaging_phase_contrast
%IMAGING_PHASE_CONTRAST - Imaging based on the principle of phase contrast microscopy.
%
%   This BeamLab function is a BPM demo showing the imaging of a pure phase
%   object through a 4f optical system using the principle of phase
%   contrast microscopy. By modulating the DC (zero) frequency component in
%   the Fourier plane at z = 2f with a quarter wave phase plate, the
%   inherently invisible phase distribution in the object plane can be
%   converted to a visible intensity distribution in the image plane.
%
%   IMAGING_PHASE_CONTRAST
%   bpmData = IMAGING_PHASE_CONTRAST

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = 1000*[1 1]; % resolution in x- and y-direction
gridSize = 1000*[1 1]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 0.633; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
field = myinputfield; % get custom input field matrix from subfunction myinputfield 
inputField = @(beamProblem) custominput(beamProblem,field); % generate custom input field ready for a BPM calculation

%% Optional parameters
options.Sections = [1 2 1 3 1 2 1]; % use as propagation structure the sections in the order of 1 -> 2 -> 1 -> 3 -> 1 -> 2 -> 1
options.SlicesXY = [0 Inf]; % display the x-y distributions at z = 0 and at the end of the propagation structure
options.SlicesXYGraphType = {'Int2D','Phase(Ex)2D'};
options.SlicesXYScale = 'lininput'; % use a (non-normalized) linear scale
options.Colormap = gray(256); % use a gray colormap
options.Shading2D = 'flat'; % use flat shading for all x-y plots
options.DisplaySize = 600*[1 1]; % display only an area with a width of 600 um

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem,'IndexScanner',false,'Index3D',false); % display x-y transmittance slice

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

%% Section 1
len = 2000; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide{1} = @(beamProblem) fasthomogeneous(beamProblem,len,index); % create homogeneous section

%% Section 2
focalLength = len; % focal length (unit is defined by optional parameter LengthUnit)

waveguide{2} = @(beamProblem) thinlens(beamProblem,focalLength); % create lens of zero thickness

%% Section 3
mediumFunction = @(x,y) myphaseplate(x,y);

waveguide{3} = @(beamProblem) thincustommedium(beamProblem,mediumFunction);

end

function out = myinputfield

out = ones(1000);
out1 = imread('wolf.png'); % load the input image from a PNG file
out1 = rot90(sqrt(double(out1)/255),1); % normalize and rotate input image to have it oriented upside down
out(201:800,201:800) = exp(-1i*pi/5*out1); % use a phase modulation with a maximum of pi/5

[x,y] = ndgrid(linspace(-499.5,499.5,1000));
rad = 300;
out(abs(x/rad).^2 + abs(y/rad).^2 > 1) = 0; % generate a circular aperture around the input image to avoid diffraction effects from the calculation edges

end

function out = myphaseplate(x,~)

[M,N] = size(x);
out = ones(M,N);
out(M/2:M/2+1,N/2:N/2+1) = 1i*ones(2);

end
