function bpmData = imaging_single_lens_aberration
%IMAGING_SINGLE_LENS_ABERRATION - Imaging through a single lens with aberrations.
%
%   This BeamLab function is a BPM demo showing the imaging of an object
%   through a single lens with aberrations defined via a Zernike phase
%   screen.
%
%   IMAGING_SINGLE_LENS_ABERRATION
%   bpmData = IMAGING_SINGLE_LENS_ABERRATION(___)

%   Copyright 2017-2018 CodeSeeder

close all;

%% Required parameters
gridPoints = 600*[1 1]; % resolution in x- and y-direction
gridSize = 600*[1 1]; % width of calculation area in x- and y-direction (unit is defined by optional parameter LengthUnit)
lambda = 0.633; % wavelength (unit is defined by optional parameter LengthUnit)
indexFunction = get_propstruct; % define propagation structure

%% Input field for bpmsolver
inputOptions.Rotation = 180; % rotate image by 180 degrees
inputField = @(beamProblem) imageinput(beamProblem,'wolf.png',inputOptions); % generate input field from image file

%% Optional parameters
options.Sections = [1 2 3 4]; % use as propagation structure the sections 1 to 4
options.SlicesXY = [0 Inf]; % display the x-y distributions at z = 0 and at the end of the propagation structure
options.SlicesXYScale = 'lininput'; % use a (non-normalized) linear scale
options.Colormap = gray(256); % use a gray colormap
options.Shading2D = 'flat'; % use flat shading for all x-y plots

%% Create beamProblem
beamProblem = beamset(gridPoints,gridSize,lambda,indexFunction,inputField,options);

%% Visualize index distribution
indexplot(beamProblem,'IndexScanner',false,'Index3D',false); % display x-y transmittance slice

%% Start BPM calculation
bpmData = bpmsolver(beamProblem);

end

%% Propagation structure
function waveguide = get_propstruct

focalLength = 2000; % focal length (unit is defined by optional parameter LengthUnit)

%% Section 1
len = focalLength*2; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide{1} = @(beamProblem) fasthomogeneous(beamProblem,len,index); % create homogeneous section

%% Section 2
waveguide{2} = @(beamProblem) thinlens(beamProblem,focalLength); % create lens of zero thickness

%% Section 3
coefficients = [0 0 0 0 2 0 -1 1 2]; % coefficients of the Zernike polynomials
options.TransmittanceSlicesXY = true; % plot thinzernike transfer function

waveguide{3} = @(beamProblem) thinzernike(beamProblem,coefficients,options);

%% Section 4
len = focalLength*2; % section length (unit is defined by optional parameter LengthUnit)
index = 1; % refractive index

waveguide{4} = @(beamProblem) fasthomogeneous(beamProblem,len,index); % create homogeneous section

end
