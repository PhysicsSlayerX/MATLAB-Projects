%BPMPLOT - Recreate output of a previous bpmsolver simulation.
%
%   This BeamLab function recreates the same output as a previous bpmsolver
%   calculation using the parameters given in bpmData. The parameter
%   bpmData can either be a structure returned by bpmsolver or the 
%   filename of a MATLAB formatted binary output file (MAT-file) generated
%   by bpmsolver. In addition, some options can be adjusted to display the
%   output differently.
%
%   BPMPLOT(bpmData)
%   BPMPLOT(___,options)
%   BPMPLOT(___,'param1',value1,'param2',value2,...)
%   figureHandles = BPMPLOT(___)
%
%   Reference list of all adjustable options with their default values:
% 
%   options.Colormap = bpmData.BeamProblem.Options.Colormap;
%   options.DisplayCenter = bpmData.BeamProblem.Options.DisplayCenter;
%   options.DisplaySize = bpmData.BeamProblem.Options.DisplaySize;
%   options.FigureBackgroundColor = bpmData.BeamProblem.Options.FigureBackgroundColor;
%   options.FigureLabels = bpmData.BeamProblem.Options.FigureLabels;
%   options.FontName = bpmData.BeamProblem.Options.FontName;
%   options.FontSizeAxes = bpmData.BeamProblem.Options.FontSizeAxes;
%   options.FontSizeLabels = bpmData.BeamProblem.Options.FontSizeLabels;
%   options.FontSizeTitle = bpmData.BeamProblem.Options.FontSizeTitle;
%   options.Format = bpmData.BeamProblem.Options.Format;
%   options.IndexContour = bpmData.BeamProblem.Options.IndexContour;
%   options.IndexContourLineColor = bpmData.BeamProblem.Options.IndexContourLineColor;
%   options.IndexContourLineWidth = bpmData.BeamProblem.Options.IndexContourLineWidth;
%   options.IndexContourSmooth = bpmData.BeamProblem.Options.IndexContourSmooth;
%   options.IndexContourValues = bpmData.BeamProblem.Options.IndexContourValues;
%   options.IntensityContour = bpmData.BeamProblem.Options.IntensityContour;
%   options.IntensityContourLineColor = bpmData.BeamProblem.Options.IntensityContourLineColor;
%   options.IntensityContourLineWidth = bpmData.BeamProblem.Options.IntensityContourLineWidth;
%   options.IntensityContourOnly = bpmData.BeamProblem.Options.IntensityContourOnly;
%   options.IntensityContourValues = bpmData.BeamProblem.Options.IntensityContourValues;
%   options.LineColor = bpmData.BeamProblem.Options.LineColor;
%   options.LineWidth = bpmData.BeamProblem.Options.LineWidth;
%   options.PlotOutputField = bpmData.BeamProblem.Options.PlotOutputField;
%   options.PowerTraceScale = bpmData.BeamProblem.Options.PowerTraceScale;
%   options.Quiver = bpmData.BeamProblem.Options.Quiver;
%   options.QuiverColor = bpmData.BeamProblem.Options.QuiverColor;
%   options.QuiverLength = bpmData.BeamProblem.Options.QuiverLength;
%   options.QuiverLineWidth = bpmData.BeamProblem.Options.QuiverLineWidth;
%   options.QuiverPeriod = bpmData.BeamProblem.Options.QuiverPeriod;
%   options.Shading2D = bpmData.BeamProblem.Options.Shading2D;
%   options.Shading3D = bpmData.BeamProblem.Options.Shading3D;
%   options.ShowSectionBoundaries = bpmData.BeamProblem.Options.ShowSectionBoundaries;
%   options.SlicesXYGraphType = bpmData.BeamProblem.Options.SlicesXYGraphType;
%   options.SlicesXYRange = bpmData.BeamProblem.Options.SlicesXYRange;
%   options.SlicesXYScale = bpmData.BeamProblem.Options.SlicesXYScale;
%   options.SlicesXYView = bpmData.BeamProblem.Options.SlicesXYView;
%   options.SlicesXZGraphType = bpmData.BeamProblem.Options.SlicesXZGraphType;
%   options.SlicesXZRange = bpmData.BeamProblem.Options.SlicesXZRange;
%   options.SlicesXZScale = bpmData.BeamProblem.Options.SlicesXZScale;
%   options.SlicesXZYZPlotXYStep = bpmData.BeamProblem.Options.SlicesXZYZPlotXYStep;
%   options.SlicesYZGraphType = bpmData.BeamProblem.Options.SlicesYZGraphType;
%   options.SlicesYZRange = bpmData.BeamProblem.Options.SlicesYZRange;
%   options.SlicesYZScale = bpmData.BeamProblem.Options.SlicesYZScale;
%   options.StackedSlicesAlpha = bpmData.BeamProblem.Options.StackedSlicesAlpha;
%
%   <a href="matlab:beamlabdoc bpmplot">Reference page for bpmplot</a>
%
%   See also BPMSOLVER, BEAMSET.

%   Copyright 2017-2018 CodeSeeder
