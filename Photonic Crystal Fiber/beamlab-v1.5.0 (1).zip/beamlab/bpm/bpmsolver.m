%BPMSOLVER - Calculate a 2D or 3D beam propagation.
%
%   This BeamLab function calculates a 2D or 3D beam propagation of a
%   beamProblem defined with beamset and an input field defined in
%   inputField.
%
%   BPMSOLVER(beamProblem)
%   BPMSOLVER(beamProblem,inputField)
%   [outputData,outputField,figureHandles] = BPMSOLVER(___)
%
%   <a href="matlab:beamlabdoc bpmsolver">Reference page for bpmsolver</a>
%
%   See also BEAMSET, BPMPLOT.

%   Copyright 2017-2018 CodeSeeder

