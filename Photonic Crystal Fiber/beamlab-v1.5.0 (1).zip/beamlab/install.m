%INSTALL - Install BeamLab.
%
%   This BeamLab function adds all required BeamLab directories to the
%   MATLAB search path, builds the documentation search database, and
%   checks if a valid license file is located in the 'licenses' directory.
%
%   INSTALL
%
%   <a href="matlab:beamlabdoc install">Reference page for install</a>
%
%   See also BPMSOLVER, MODESOLVER.

%   Copyright 2017-2018 CodeSeeder
